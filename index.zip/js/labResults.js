/**
 * DialysisCare AI Assistant — js/labResults.js
 * =============================================
 * "Understand Your Lab Results" feature.
 *
 * WHAT THIS MODULE DOES
 * ─────────────────────
 * 1. Renders a row-based entry form (test name, value, unit,
 *    reference range low/high, date).
 * 2. Accepts an attached image or PDF as a visual reference —
 *    shown in-browser only, never transmitted.
 * 3. On "Explain", generates a plain-language explanation for
 *    each entered result:
 *    • What the test measures (from built-in knowledge)
 *    • Whether the value is within the user's own printed range
 *    • Questions to ask the dialysis team
 * 4. Trend view: when multiple dated entries for the same test
 *    exist in localStorage, shows a simple SVG sparkline.
 * 5. Storage opt-in: nothing is saved until the user explicitly
 *    clicks "Save this report" after reviewing.
 *
 * SAFETY PRINCIPLES
 * ─────────────────
 * • We NEVER compare against population/general reference ranges
 *   as if they were the user's personal target.
 * • If the user's reference range is missing, we say so and do
 *   not guess.
 * • We NEVER diagnose, suggest medication changes, or give diet
 *   instructions based on lab values.
 * • We flag when a value is outside the user's printed range and
 *   recommend they discuss it with their care team — nothing more.
 * • No data leaves the browser at any point.
 */

/* global escapeHtml */

var LabResults = (function () {
  'use strict';

  var STORAGE_KEY = 'dialysiscare_lab_history';

  // ── BUILT-IN TEST KNOWLEDGE ───────────────────────────────────────────────
  // Maps common test names (lowercase, normalised) to educational content.
  // "questions" are things the user might ask their care team.
  // We deliberately do NOT embed reference ranges here — we only use the
  // range the user copies from their own printed report.

  var _TEST_INFO = {
    // Electrolytes / Minerals
    'potassium': {
      full_name: 'Potassium (K)',
      what_it_measures: 'The level of potassium in your blood. Potassium is a mineral that helps nerves and muscles — including your heart — work properly.',
      why_dialysis_cares: 'When kidneys fail, potassium can build up between dialysis sessions. Very high levels can cause dangerous changes to your heart rhythm.',
      questions: ['Is my potassium level a concern at this reading?', 'Should I make any changes to what I eat before my next session?', 'What are the warning signs of high potassium I should know about?']
    },
    'sodium': {
      full_name: 'Sodium (Na)',
      what_it_measures: 'The level of sodium (salt) in your blood. Sodium helps control fluid balance and blood pressure.',
      why_dialysis_cares: 'Too much sodium can cause thirst, fluid retention, high blood pressure, and extra strain on your heart.',
      questions: ['What does this sodium level mean for my fluid and salt intake?', 'Is my blood pressure related to this result?']
    },
    'phosphorus': {
      full_name: 'Phosphorus (Phos)',
      what_it_measures: 'The level of phosphorus in your blood. Phosphorus is a mineral important for bones and teeth.',
      why_dialysis_cares: 'Failing kidneys cannot remove excess phosphorus. High levels weaken bones and can damage blood vessels over time.',
      questions: ['Should I be taking phosphate binders with my meals?', 'Are there foods I should limit to help bring this down?', 'Is my phosphorus being managed well by dialysis?']
    },
    'phosphate': {
      full_name: 'Phosphate',
      what_it_measures: 'Another name for phosphorus in the blood. See "Phosphorus" above.',
      why_dialysis_cares: 'Same as phosphorus — high levels weaken bones and affect blood vessels.',
      questions: ['Is my phosphate level within the target range my team has set?', 'Do I need to adjust my phosphate binders?']
    },
    'calcium': {
      full_name: 'Calcium (Ca)',
      what_it_measures: 'The level of calcium in your blood. Calcium is essential for bones, nerve signals, and muscle contractions.',
      why_dialysis_cares: 'Both high and low calcium can cause problems in kidney disease — including bone disease and heart rhythm issues. Dialysis and medications affect this balance.',
      questions: ['Is my calcium level affected by my phosphorus or PTH level?', 'Does my vitamin D or phosphate binder affect this result?']
    },
    'bicarbonate': {
      full_name: 'Bicarbonate (HCO₃ / CO₂)',
      what_it_measures: 'A measure of the acid–base balance of your blood. Bicarbonate acts as a buffer to keep your blood from becoming too acidic.',
      why_dialysis_cares: 'Low bicarbonate (called metabolic acidosis) is very common in kidney disease. It can cause muscle wasting, bone loss, and fatigue.',
      questions: ['Is my bicarbonate low enough to need treatment?', 'Would sodium bicarbonate tablets help in my situation?']
    },
    'co2': {
      full_name: 'Carbon Dioxide / CO₂ (bicarbonate)',
      what_it_measures: 'On blood panels, the CO₂ value usually represents bicarbonate — the acid–base buffer in your blood.',
      why_dialysis_cares: 'Low CO₂/bicarbonate suggests your blood is too acidic (metabolic acidosis), which is common in kidney disease.',
      questions: ['Is my acid–base balance being corrected by dialysis?', 'Should this number be higher?']
    },
    // Blood counts
    'haemoglobin': {
      full_name: 'Haemoglobin (Hb / Hemoglobin)',
      what_it_measures: 'The protein in red blood cells that carries oxygen around your body.',
      why_dialysis_cares: 'Anaemia (low haemoglobin) is very common in kidney disease because the kidneys make a hormone (EPO) that tells the body to produce red blood cells. When kidneys fail, less EPO is made.',
      questions: ['Is my haemoglobin low enough to need EPO injections or iron treatment?', 'Is fatigue I am feeling related to this level?', 'What is the target haemoglobin my care team is aiming for?']
    },
    'hemoglobin': {
      full_name: 'Hemoglobin (Hb)',
      what_it_measures: 'The protein in red blood cells that carries oxygen around your body.',
      why_dialysis_cares: 'Anaemia (low haemoglobin) is very common in kidney disease because the kidneys make EPO, the hormone that drives red blood cell production.',
      questions: ['Am I anaemic at this level?', 'Do I need EPO, iron, or other treatment?', 'What target is my care team aiming for?']
    },
    'hgb': {
      full_name: 'Haemoglobin (Hgb)',
      what_it_measures: 'The oxygen-carrying protein in red blood cells.',
      why_dialysis_cares: 'Low Hgb causes anaemia — a very common complication of kidney disease.',
      questions: ['Is anaemia treatment (EPO, iron) needed at this level?']
    },
    'hematocrit': {
      full_name: 'Haematocrit (HCT / PCV)',
      what_it_measures: 'The percentage of your blood that is made up of red blood cells.',
      why_dialysis_cares: 'A low haematocrit means anaemia. It moves in the same direction as haemoglobin.',
      questions: ['How does this relate to my haemoglobin result?', 'Is my anaemia being managed well?']
    },
    // Kidney markers
    'creatinine': {
      full_name: 'Creatinine',
      what_it_measures: 'A waste product produced by muscle activity. Healthy kidneys filter it out; failing kidneys allow it to build up.',
      why_dialysis_cares: 'Creatinine is used to track how well your kidneys (or dialysis) are clearing waste. On dialysis, pre-dialysis creatinine can be high — your team monitors the trend over time.',
      questions: ['Is my creatinine trending in the right direction?', 'What does this pre-dialysis level mean for how well my dialysis is working?']
    },
    'urea': {
      full_name: 'Urea (BUN — Blood Urea Nitrogen)',
      what_it_measures: 'A waste product formed when your body breaks down protein. Kidneys normally filter it out.',
      why_dialysis_cares: 'High urea causes symptoms like nausea, fatigue, and confusion. Dialysis removes urea — the amount removed (Kt/V) measures dialysis adequacy.',
      questions: ['Is my urea being cleared well enough by dialysis?', 'Does this result affect my Kt/V or dialysis adequacy score?']
    },
    'bun': {
      full_name: 'BUN (Blood Urea Nitrogen)',
      what_it_measures: 'The amount of urea nitrogen in your blood — a measure of how much waste product is in your blood.',
      why_dialysis_cares: 'BUN goes up when kidneys cannot clear waste. Dialysis removes BUN — your pre- and post-dialysis BUN values are used to calculate dialysis adequacy (Kt/V).',
      questions: ['What is my pre- vs post-dialysis BUN trend?', 'Is my dialysis adequacy (Kt/V) being affected?']
    },
    'egfr': {
      full_name: 'eGFR (Estimated Glomerular Filtration Rate)',
      what_it_measures: 'An estimate of how much blood your kidneys filter per minute. It measures remaining kidney function.',
      why_dialysis_cares: 'Once eGFR is very low (usually under 15), dialysis is typically needed. On dialysis, residual kidney function (any eGFR remaining) is important to preserve.',
      questions: ['Do I have any remaining kidney function?', 'Is my residual function being monitored and preserved?']
    },
    // Other common tests
    'albumin': {
      full_name: 'Albumin',
      what_it_measures: 'A protein made by your liver. It is a marker of nutrition and overall health.',
      why_dialysis_cares: 'Low albumin on dialysis is associated with higher risk of complications. It can reflect poor nutrition, inflammation, or protein loss during dialysis.',
      questions: ['Is my albumin level a concern?', 'Do I need to increase my protein intake?', 'Could inflammation be affecting this result?']
    },
    'ferritin': {
      full_name: 'Ferritin',
      what_it_measures: 'A protein that stores iron. Blood ferritin reflects your body\'s iron stores.',
      why_dialysis_cares: 'Iron is needed to make red blood cells. Low ferritin means low iron stores, which can worsen anaemia. Very high ferritin can indicate inflammation or iron overload.',
      questions: ['Do I need IV iron treatment?', 'Is this ferritin level in the target range for dialysis patients?']
    },
    'iron': {
      full_name: 'Serum Iron',
      what_it_measures: 'The amount of iron currently circulating in your blood.',
      why_dialysis_cares: 'Iron is needed to make haemoglobin. Low iron contributes to anaemia. Dialysis patients often need supplemental iron (oral or IV).',
      questions: ['Should I be on iron supplements or IV iron?', 'How does this compare to my ferritin and TSAT?']
    },
    'transferrin saturation': {
      full_name: 'Transferrin Saturation (TSAT)',
      what_it_measures: 'The percentage of transferrin (an iron-carrying protein) that is currently loaded with iron. Reflects how available iron is for red blood cell production.',
      why_dialysis_cares: 'A low TSAT suggests iron deficiency even if ferritin is normal. Used alongside ferritin to guide iron therapy decisions.',
      questions: ['Is my TSAT low enough to need iron treatment?', 'How do my TSAT and ferritin results together guide my treatment?']
    },
    'tsat': {
      full_name: 'Transferrin Saturation (TSAT)',
      what_it_measures: 'The percentage of transferrin currently bound to iron — a measure of iron availability.',
      why_dialysis_cares: 'Low TSAT alongside low ferritin strongly suggests iron deficiency. Guides IV iron decisions.',
      questions: ['Is my TSAT in the range my team targets for dialysis patients?']
    },
    'pth': {
      full_name: 'PTH (Parathyroid Hormone / Intact PTH)',
      what_it_measures: 'A hormone made by four small glands behind your thyroid. PTH controls calcium and phosphorus levels.',
      why_dialysis_cares: 'In kidney disease, PTH often rises very high (secondary hyperparathyroidism). This weakens bones and can calcify blood vessels over time.',
      questions: ['Is my PTH at a level that needs treatment?', 'Should I be taking vitamin D (calcitriol/paricalcitol) or cinacalcet for this?']
    },
    'ipth': {
      full_name: 'Intact PTH (iPTH)',
      what_it_measures: 'The active form of parathyroid hormone. Controls calcium/phosphorus balance.',
      why_dialysis_cares: 'Very high iPTH indicates secondary hyperparathyroidism — bones are being broken down to release calcium. Requires treatment in dialysis patients.',
      questions: ['What is the target iPTH range for dialysis patients?', 'What treatments are available to lower it?']
    },
    'kt/v': {
      full_name: 'Kt/V (Dialysis Adequacy)',
      what_it_measures: 'A measure of how much waste (urea) was removed during a dialysis session. K = clearance, t = time, V = volume of body water.',
      why_dialysis_cares: 'Kt/V tells you if your dialysis is working well enough. Guidelines generally target Kt/V ≥ 1.2 per session for haemodialysis.',
      questions: ['Is my Kt/V meeting the recommended target?', 'If it is below target, what changes could improve it — longer sessions, more sessions, or a different dialyser?']
    },
    'ktv': {
      full_name: 'Kt/V (Dialysis Adequacy)',
      what_it_measures: 'A measure of dialysis dose — how much urea was removed relative to your body size.',
      why_dialysis_cares: 'Low Kt/V means dialysis may not be removing enough waste. This is an important quality measure.',
      questions: ['What is my current Kt/V and is it at or above the guideline target?']
    },
    'glucose': {
      full_name: 'Glucose (Blood Sugar)',
      what_it_measures: 'The level of sugar in your blood.',
      why_dialysis_cares: 'Diabetes is the leading cause of kidney failure worldwide. Blood glucose control remains important on dialysis to protect remaining health.',
      questions: ['Is my blood sugar well controlled?', 'Has my diabetes management changed now that I am on dialysis?']
    },
    'hba1c': {
      full_name: 'HbA1c (Glycated Haemoglobin)',
      what_it_measures: 'The percentage of haemoglobin with sugar attached — reflects average blood sugar over the past 2–3 months.',
      why_dialysis_cares: 'HbA1c can be less reliable in dialysis patients because anaemia and blood transfusions affect it. Your team may use other measures alongside it.',
      questions: ['Is HbA1c an accurate reflection of my glucose control given my anaemia?', 'What is the target range my team recommends for me?']
    },
    'white blood cells': {
      full_name: 'White Blood Cells (WBC)',
      what_it_measures: 'Counts the cells that fight infection. A high level may suggest infection or inflammation; a low level may mean the immune system is suppressed.',
      why_dialysis_cares: 'Dialysis patients are at higher risk of infection (especially with catheters and exit sites). An abnormal WBC should always be discussed with the care team.',
      questions: ['Could this WBC result indicate an infection related to my dialysis access?', 'Should any further tests be done?']
    },
    'wbc': {
      full_name: 'WBC (White Blood Cell Count)',
      what_it_measures: 'Counts the infection-fighting white blood cells in your blood.',
      why_dialysis_cares: 'An elevated WBC may indicate infection — a serious risk for dialysis patients, especially those with catheters.',
      questions: ['Is there any sign of infection from this WBC result?']
    },
    'platelets': {
      full_name: 'Platelets (PLT)',
      what_it_measures: 'Tiny blood cells that help form clots to stop bleeding.',
      why_dialysis_cares: 'Some kidney conditions and medications can affect platelet counts. Heparin used during dialysis can rarely reduce platelets.',
      questions: ['Is my platelet count in a safe range?', 'Could heparin be affecting this result?']
    },
    'cholesterol': {
      full_name: 'Total Cholesterol',
      what_it_measures: 'A measure of the total amount of cholesterol (fatty substance) in your blood.',
      why_dialysis_cares: 'Heart disease is the leading cause of death in dialysis patients. Cholesterol management remains important.',
      questions: ['Is my cholesterol being managed appropriately given my dialysis and overall heart risk?']
    },
    'ldl': {
      full_name: 'LDL Cholesterol ("Bad" Cholesterol)',
      what_it_measures: 'Low-density lipoprotein — the type of cholesterol linked to hardening of arteries.',
      why_dialysis_cares: 'High LDL contributes to cardiovascular disease, which is a major cause of death in kidney failure.',
      questions: ['Should I be on a statin or other cholesterol-lowering medication?']
    },
    'hdl': {
      full_name: 'HDL Cholesterol ("Good" Cholesterol)',
      what_it_measures: 'High-density lipoprotein — helps remove cholesterol from arteries.',
      why_dialysis_cares: 'Low HDL is a risk factor for heart disease, which is very common in dialysis patients.',
      questions: ['What can I do to maintain or improve my HDL level?']
    },
    'triglycerides': {
      full_name: 'Triglycerides',
      what_it_measures: 'A type of fat in your blood. High levels are linked to heart and metabolic disease.',
      why_dialysis_cares: 'High triglycerides are common in kidney disease. Diet, activity, and sometimes medication can help.',
      questions: ['Are my triglycerides high enough to need treatment?']
    }
  };

  // ── ROW TEMPLATE ──────────────────────────────────────────────────────────

  var _rowIndex = 0;

  function _buildRow(idx) {
    return '<div class="lr-row" id="lr-row-' + idx + '" data-row-idx="' + idx + '">' +
      '<div class="lr-row-fields">' +
        '<div class="lr-field lr-field-name">' +
          '<label for="lr-name-' + idx + '">Test name</label>' +
          '<input type="text" id="lr-name-' + idx + '" class="lr-input lr-row-name" ' +
            'placeholder="e.g. Potassium" autocomplete="off" list="lr-test-suggestions" />' +
        '</div>' +
        '<div class="lr-field lr-field-value">' +
          '<label for="lr-value-' + idx + '">Result</label>' +
          '<input type="text" id="lr-value-' + idx + '" class="lr-input lr-row-value" ' +
            'placeholder="e.g. 5.1" inputmode="decimal" />' +
        '</div>' +
        '<div class="lr-field lr-field-unit">' +
          '<label for="lr-unit-' + idx + '">Unit</label>' +
          '<input type="text" id="lr-unit-' + idx + '" class="lr-input lr-row-unit" ' +
            'placeholder="e.g. mmol/L" />' +
        '</div>' +
        '<div class="lr-field lr-field-range">' +
          '<label>Reference range (from your report)</label>' +
          '<div class="lr-range-row">' +
            '<input type="text" id="lr-low-' + idx + '" class="lr-input lr-row-low" ' +
              'placeholder="Low" inputmode="decimal" aria-label="Range low" />' +
            '<span class="lr-range-sep">–</span>' +
            '<input type="text" id="lr-high-' + idx + '" class="lr-input lr-row-high" ' +
              'placeholder="High" inputmode="decimal" aria-label="Range high" />' +
          '</div>' +
        '</div>' +
        '<div class="lr-field lr-field-date">' +
          '<label for="lr-row-date-' + idx + '">Test date</label>' +
          '<input type="date" id="lr-row-date-' + idx + '" class="lr-input lr-row-date" />' +
        '</div>' +
      '</div>' +
      '<button class="lr-btn-remove-row" data-remove-idx="' + idx + '" aria-label="Remove this row" title="Remove">✕</button>' +
    '</div>';
  }

  // Datalist of common test names for autocomplete
  var _DATALIST_HTML = '<datalist id="lr-test-suggestions">' +
    ['Potassium','Sodium','Phosphorus','Calcium','Bicarbonate','CO2',
     'Haemoglobin','Hemoglobin','Hematocrit','Creatinine','Urea','BUN','eGFR',
     'Albumin','Ferritin','Iron','Transferrin Saturation','TSAT',
     'PTH','iPTH','Kt/V','Glucose','HbA1c',
     'White Blood Cells','WBC','Platelets',
     'Cholesterol','LDL','HDL','Triglycerides'
    ].map(function(n) { return '<option value="' + n + '">'; }).join('') +
    '</datalist>';

  // ── VALUE PARSING ─────────────────────────────────────────────────────────

  function _parseNum(str) {
    if (!str) return null;
    var n = parseFloat(String(str).replace(/,/g, '.').trim());
    return isNaN(n) ? null : n;
  }

  // ── RANGE STATUS ──────────────────────────────────────────────────────────

  function _rangeStatus(value, low, high) {
    // Returns: 'low' | 'normal' | 'high' | 'unknown'
    var v = _parseNum(value);
    var lo = _parseNum(low);
    var hi = _parseNum(high);
    if (v === null) return 'unknown';
    if (lo !== null && v < lo) return 'low';
    if (hi !== null && v > hi) return 'high';
    if (lo !== null || hi !== null) return 'normal';
    return 'unknown';
  }

  // ── EXPLANATION BUILDER ───────────────────────────────────────────────────

  function _escH(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  function _lookupInfo(name) {
    var key = String(name).toLowerCase().trim()
      .replace(/\s*\(.*?\)/g, '') // strip parenthetical abbreviations
      .replace(/[^a-z0-9/\s]/g, '')
      .trim();
    return _TEST_INFO[key] || null;
  }

  function _buildExplanationCard(result, reportDate, reportLab) {
    // result = { name, value, unit, low, high, date }
    var info     = _lookupInfo(result.name);
    var status   = _rangeStatus(result.value, result.low, result.high);
    var hasRange = (_parseNum(result.low) !== null || _parseNum(result.high) !== null);
    var hasValue = (_parseNum(result.value) !== null);

    // Status badge
    var statusBadge = '';
    var statusClass = '';
    if (!hasValue) {
      statusBadge = '<span class="lr-status lr-status-unknown">— No value entered</span>';
      statusClass = 'lr-card-unknown';
    } else if (!hasRange) {
      statusBadge = '<span class="lr-status lr-status-unknown">📋 No reference range supplied</span>';
      statusClass = 'lr-card-unknown';
    } else if (status === 'normal') {
      statusBadge = '<span class="lr-status lr-status-normal">✅ Within your report\'s reference range</span>';
      statusClass = 'lr-card-normal';
    } else if (status === 'low') {
      statusBadge = '<span class="lr-status lr-status-low">⬇️ Below your report\'s reference range</span>';
      statusClass = 'lr-card-abnormal';
    } else if (status === 'high') {
      statusBadge = '<span class="lr-status lr-status-high">⬆️ Above your report\'s reference range</span>';
      statusClass = 'lr-card-abnormal';
    }

    // Value display
    var valueDisplay = hasValue
      ? ('<strong>' + _escH(result.value) + '</strong>' + (result.unit ? ' ' + _escH(result.unit) : ''))
      : '<em class="text-muted">Not entered</em>';

    var rangeDisplay = hasRange
      ? (_escH(result.low || '?') + ' – ' + _escH(result.high || '?') + (result.unit ? ' ' + _escH(result.unit) : ''))
      : '<em class="text-muted">Not provided</em>';

    var dateDisplay = result.date
      ? ('<span class="lr-card-date">Test date: ' + _escH(result.date) + '</span>')
      : '';

    // No-range notice
    var noRangeNote = '';
    if (hasValue && !hasRange) {
      noRangeNote = '<div class="lr-no-range-notice">' +
        '📋 <strong>No reference range was entered for this test.</strong> ' +
        'We can\'t tell you whether this value is inside or outside the range your lab printed ' +
        'because we don\'t have that information. Please check your paper report or ask your ' +
        'dialysis team what the target range is for you personally.' +
      '</div>';
    }

    // Status detail
    var statusDetail = '';
    if (hasValue && hasRange && status !== 'unknown') {
      var rangeStr = (_parseNum(result.low) !== null ? result.low : '') +
        (_parseNum(result.low) !== null && _parseNum(result.high) !== null ? ' – ' : '') +
        (_parseNum(result.high) !== null ? result.high : '');
      if (status === 'normal') {
        statusDetail = '<p>Your result of <strong>' + _escH(result.value) + ' ' + _escH(result.unit || '') + '</strong> falls within the reference range printed on your report (' + _escH(rangeStr) + ' ' + _escH(result.unit || '') + '). This means it is in the range your lab considers typical.</p>';
      } else {
        var direction = status === 'high' ? 'above' : 'below';
        statusDetail = '<p>Your result of <strong>' + _escH(result.value) + ' ' + _escH(result.unit || '') + '</strong> is <strong>' + direction + '</strong> the reference range printed on your report (' + _escH(rangeStr) + ' ' + _escH(result.unit || '') + '). ' +
          '<strong>This does not mean you are in immediate danger</strong> — a single result needs to be reviewed in the context of your full history and health by your care team. ' +
          'Please bring this result to your next appointment or contact your dialysis unit if you are concerned.</p>';
      }
    }

    // Disclaimer for all abnormal or unknown
    var disclaimer = '';
    if (status === 'low' || status === 'high') {
      disclaimer = '<div class="lr-disclaimer">' +
        '⚕️ This explanation does not diagnose a condition, recommend a medication change, or ' +
        'tell you to change your diet. Only your nephrologist or dialysis nurse can interpret ' +
        'this result in the context of your full medical history.' +
      '</div>';
    }

    // Knowledge section
    var knowledgeSection = '';
    if (info) {
      knowledgeSection = '<div class="lr-knowledge">' +
        '<h4>About this test</h4>' +
        '<p>' + _escH(info.what_it_measures) + '</p>' +
        '<p><strong>Why it matters for dialysis patients:</strong> ' + _escH(info.why_dialysis_cares) + '</p>' +
        '</div>';
    } else {
      knowledgeSection = '<div class="lr-knowledge">' +
        '<h4>About this test</h4>' +
        '<p class="text-muted">We don\'t have specific educational content for "<em>' + _escH(result.name) + '</em>" in our knowledge base. ' +
        'Your dialysis nurse or nephrologist can explain what this test measures and what it means for you.</p>' +
        '</div>';
    }

    // Questions section
    var questionsSection = '';
    if (info && info.questions && info.questions.length) {
      questionsSection = '<div class="lr-questions">' +
        '<h4>💬 Questions to ask your care team</h4>' +
        '<ul>' +
        info.questions.map(function(q) { return '<li>' + _escH(q) + '</li>'; }).join('') +
        '</ul>' +
        '</div>';
    }

    return '<div class="lr-card ' + statusClass + '">' +
      '<div class="lr-card-header">' +
        '<div class="lr-card-title-row">' +
          '<span class="lr-card-name">' + _escH(info ? info.full_name : result.name) + '</span>' +
          statusBadge +
        '</div>' +
        '<div class="lr-card-values">' +
          '<span class="lr-card-value-label">Your result:</span> ' + valueDisplay +
          ' &nbsp;|&nbsp; ' +
          '<span class="lr-card-value-label">Reference range:</span> ' + rangeDisplay +
          (dateDisplay ? ' &nbsp;|&nbsp; ' + dateDisplay : '') +
        '</div>' +
      '</div>' +
      '<div class="lr-card-body">' +
        noRangeNote +
        statusDetail +
        knowledgeSection +
        questionsSection +
        disclaimer +
      '</div>' +
    '</div>';
  }

  // ── TREND (SVG SPARKLINE) ─────────────────────────────────────────────────

  function _buildTrend(testName, currentValue, currentDate) {
    var history = _loadHistory();
    var key = testName.toLowerCase().trim();

    // Collect all points for this test from saved history
    var points = [];
    history.forEach(function(report) {
      report.results.forEach(function(r) {
        if (r.name.toLowerCase().trim() === key && _parseNum(r.value) !== null && r.date) {
          points.push({ date: r.date, value: _parseNum(r.value) });
        }
      });
    });

    // Add the current (unsaved) point if it has a date
    if (_parseNum(currentValue) !== null && currentDate) {
      var alreadyPresent = points.some(function(p) { return p.date === currentDate && p.value === _parseNum(currentValue); });
      if (!alreadyPresent) {
        points.push({ date: currentDate, value: _parseNum(currentValue), current: true });
      }
    }

    // Need at least 2 points to draw a trend
    if (points.length < 2) return '';

    points.sort(function(a, b) { return a.date < b.date ? -1 : 1; });

    // SVG sparkline
    var W = 280, H = 60, PAD = 8;
    var vals = points.map(function(p) { return p.value; });
    var min = Math.min.apply(null, vals);
    var max = Math.max.apply(null, vals);
    var range = max - min || 1;

    function px(i) { return PAD + (i / (points.length - 1)) * (W - PAD * 2); }
    function py(v) { return H - PAD - ((v - min) / range) * (H - PAD * 2); }

    var polyline = points.map(function(p, i) { return px(i) + ',' + py(p.value); }).join(' ');

    var dots = points.map(function(p, i) {
      var col = p.current ? '#3b82d4' : '#94a3b8';
      return '<circle cx="' + px(i) + '" cy="' + py(p.value) + '" r="3" fill="' + col + '" />' +
        '<title>' + _escH(p.date) + ': ' + p.value + '</title>';
    }).join('');

    var svg = '<svg class="lr-sparkline" width="' + W + '" height="' + H + '" viewBox="0 0 ' + W + ' ' + H + '" aria-hidden="true">' +
      '<polyline points="' + polyline + '" fill="none" stroke="#94a3b8" stroke-width="1.5" />' +
      dots +
      '</svg>';

    var dateLabels = '<div class="lr-trend-labels">' +
      '<span class="text-xs text-muted">' + _escH(points[0].date) + '</span>' +
      '<span class="text-xs text-muted">' + _escH(points[points.length - 1].date) + '</span>' +
      '</div>';

    return '<div class="lr-trend">' +
      '<h5 class="lr-trend-title">Trend (' + points.length + ' results)</h5>' +
      svg + dateLabels +
    '</div>';
  }

  // ── HISTORY / STORAGE ─────────────────────────────────────────────────────

  function _loadHistory() {
    try {
      var raw = localStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function _saveReport(report) {
    try {
      var history = _loadHistory();
      history.unshift(report); // newest first
      if (history.length > 50) history = history.slice(0, 50);
      localStorage.setItem(STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
      console.warn('LabResults: Could not save to localStorage.', e);
    }
  }

  function _clearHistory() {
    try { localStorage.removeItem(STORAGE_KEY); } catch (e) {}
  }

  function _buildHistoryPanel() {
    var history = _loadHistory();
    if (!history.length) {
      return '<p class="text-muted" style="padding:var(--space-lg) 0;">No saved results yet. After explaining a report, you will be offered the option to save it here on this device.</p>' +
        '<p class="text-muted text-sm">Saved data is stored only in your browser\'s local storage — not in any cloud or server.</p>';
    }

    var html = '<p class="text-muted text-sm" style="margin-bottom:var(--space-md);">' +
      history.length + ' saved report' + (history.length !== 1 ? 's' : '') +
      ' — stored on this device only. ' +
      '<button class="lr-btn-clear-history" id="lr-btn-clear-history" style="margin-left:0.5rem;">🗑 Clear all saved results</button>' +
      '</p>';

    history.forEach(function(report, idx) {
      var label = (report.reportDate || 'No date') + (report.reportLab ? ' — ' + report.reportLab : '');
      html += '<div class="lr-history-report">' +
        '<div class="lr-history-report-header">' +
          '<span class="lr-history-label">📋 ' + _escH(label) + '</span>' +
          '<button class="lr-btn-load-report btn-outline" data-report-idx="' + idx + '">Load into form</button>' +
        '</div>' +
        '<div class="lr-history-results-mini">' +
        report.results.map(function(r) {
          var st = _rangeStatus(r.value, r.low, r.high);
          var icon = st === 'normal' ? '✅' : (st === 'low' ? '⬇️' : (st === 'high' ? '⬆️' : '📋'));
          return '<span class="lr-mini-result">' + icon + ' ' + _escH(r.name) +
            (r.value ? ': ' + _escH(r.value) + (r.unit ? ' ' + _escH(r.unit) : '') : '') + '</span>';
        }).join('') +
        '</div>' +
      '</div>';
    });

    return html;
  }

  // ── COLLECT FORM ROWS ────────────────────────────────────────────────────

  function _collectRows(containerSelector, dateSel, labSel) {
    var container = document.querySelector(containerSelector);
    if (!container) return { results: [], reportDate: '', reportLab: '' };

    var reportDate = document.querySelector(dateSel) ? document.querySelector(dateSel).value : '';
    var reportLab  = document.querySelector(labSel)  ? document.querySelector(labSel).value  : '';

    var rows = container.querySelectorAll('.lr-row');
    var results = [];
    rows.forEach(function(row) {
      var name  = (row.querySelector('.lr-row-name')  || {}).value || '';
      var value = (row.querySelector('.lr-row-value') || {}).value || '';
      var unit  = (row.querySelector('.lr-row-unit')  || {}).value || '';
      var low   = (row.querySelector('.lr-row-low')   || {}).value || '';
      var high  = (row.querySelector('.lr-row-high')  || {}).value || '';
      var date  = (row.querySelector('.lr-row-date')  || {}).value || '';
      if (name.trim()) {
        results.push({ name: name.trim(), value: value.trim(), unit: unit.trim(), low: low.trim(), high: high.trim(), date: date.trim() });
      }
    });
    return { results: results, reportDate: reportDate, reportLab: reportLab };
  }

  // ── EXPLANATION RENDER ────────────────────────────────────────────────────

  function _renderExplanation(collected) {
    var el = document.getElementById('lr-explanation');
    if (!el) return;

    if (!collected.results.length) {
      el.innerHTML = '<div class="notice notice-warning"><span class="notice-icon">⚠️</span><div class="notice-body">Please enter at least one test name before explaining.</div></div>';
      el.classList.remove('hidden');
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      return;
    }

    var headerHtml = '<div class="lr-explanation-header">' +
      '<h2>Your Results — Explained</h2>' +
      (collected.reportDate || collected.reportLab
        ? '<p class="text-muted text-sm">' +
          (collected.reportDate ? 'Report date: <strong>' + _escH(collected.reportDate) + '</strong>' : '') +
          (collected.reportDate && collected.reportLab ? ' &nbsp;·&nbsp; ' : '') +
          (collected.reportLab ? 'Lab: <strong>' + _escH(collected.reportLab) + '</strong>' : '') +
          '</p>'
        : '') +
      '<div class="notice notice-warning" style="margin:var(--space-md) 0 0;">' +
        '<span class="notice-icon">⚕️</span>' +
        '<div class="notice-body">These explanations are for education only. We use only the reference range from your own report — not a general population target. Always discuss your results with your nephrologist or dialysis nurse before making any changes.</div>' +
      '</div>' +
    '</div>';

    var cardsHtml = collected.results.map(function(r) {
      var card = _buildExplanationCard(r, collected.reportDate, collected.reportLab);
      var trend = _buildTrend(r.name, r.value, r.date || collected.reportDate);
      return card + trend;
    }).join('');

    // Save offer
    var saveOfferHtml = '<div class="lr-save-offer" id="lr-save-offer">' +
      '<p><strong>Would you like to save this report on this device?</strong></p>' +
      '<p class="text-muted text-sm">Saved results are stored only in your browser\'s local storage — not in any cloud, server, or account. You can delete them at any time from the "Saved results" tab.</p>' +
      '<div class="lr-save-offer-buttons">' +
        '<button class="btn-primary" id="lr-btn-save-confirm">💾 Yes, save to this device</button>' +
        '<button class="btn-outline"  id="lr-btn-save-decline">No thanks</button>' +
      '</div>' +
    '</div>';

    el.innerHTML = headerHtml + '<div class="lr-cards">' + cardsHtml + '</div>' + saveOfferHtml;
    el.classList.remove('hidden');
    el.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Wire save buttons
    var saveBtn = document.getElementById('lr-btn-save-confirm');
    var declineBtn = document.getElementById('lr-btn-save-decline');
    var saveOffer = document.getElementById('lr-save-offer');

    if (saveBtn) {
      saveBtn.addEventListener('click', function() {
        _saveReport(collected);
        if (saveOffer) {
          saveOffer.innerHTML = '<p class="text-muted"><span style="color:var(--color-success)">✅ Saved.</span> You can view and delete this from the <strong>Saved results</strong> tab.</p>';
        }
      });
    }
    if (declineBtn) {
      declineBtn.addEventListener('click', function() {
        if (saveOffer) saveOffer.innerHTML = '<p class="text-muted text-sm">Not saved. This report will be cleared when you leave this page.</p>';
      });
    }
  }

  // ── FILE ATTACH ───────────────────────────────────────────────────────────

  function _handleFile(file) {
    var preview  = document.getElementById('lr-file-preview');
    var formArea = document.getElementById('lr-attach-form');
    if (!preview || !formArea) return;

    if (file.type === 'application/pdf') {
      preview.innerHTML = '<div class="lr-pdf-notice">' +
        '<span class="lr-drop-icon">📄</span>' +
        '<p><strong>' + _escH(file.name) + '</strong></p>' +
        '<p class="text-muted text-sm">PDF attached. Use the form below to enter the values you can read from the PDF. ' +
        'PDF content cannot be read automatically — please type each result manually.</p>' +
      '</div>';
    } else {
      var reader = new FileReader();
      reader.onload = function(e) {
        preview.innerHTML = '<div class="lr-image-wrapper">' +
          '<img src="' + e.target.result + '" class="lr-preview-img" alt="Lab report preview" />' +
          '<p class="text-muted text-sm" style="margin-top:0.5rem;">Read the values from your report and enter them in the form below.</p>' +
        '</div>';
      };
      reader.readAsDataURL(file);
    }

    preview.classList.remove('hidden');
    formArea.classList.remove('hidden');
    _ensureOneRow('#lr-rows-container-att');
  }

  // ── ROW MANAGEMENT ────────────────────────────────────────────────────────

  function _ensureOneRow(containerSel) {
    var c = document.querySelector(containerSel);
    if (!c) return;
    if (!c.querySelector('.lr-row')) {
      _rowIndex++;
      c.insertAdjacentHTML('beforeend', _buildRow(_rowIndex));
    }
  }

  function _addRow(containerSel) {
    var c = document.querySelector(containerSel);
    if (!c) return;
    _rowIndex++;
    c.insertAdjacentHTML('beforeend', _buildRow(_rowIndex));
    // Focus the new row's name input
    var rows = c.querySelectorAll('.lr-row');
    var last = rows[rows.length - 1];
    if (last) {
      var inp = last.querySelector('.lr-row-name');
      if (inp) setTimeout(function() { inp.focus(); }, 50);
    }
  }

  function _removeRow(idx) {
    var row = document.getElementById('lr-row-' + idx);
    if (row) row.remove();
  }

  // ── TAB SWITCHING ─────────────────────────────────────────────────────────

  function _initTabs() {
    var tabs = document.querySelectorAll('.lr-tab[data-lr-tab]');
    tabs.forEach(function(tab) {
      tab.addEventListener('click', function() {
        tabs.forEach(function(t) {
          t.classList.remove('active');
          t.setAttribute('aria-selected', 'false');
        });
        document.querySelectorAll('.lr-panel').forEach(function(p) {
          p.classList.remove('active');
        });
        tab.classList.add('active');
        tab.setAttribute('aria-selected', 'true');
        var panelId = 'lr-panel-' + tab.dataset.lrTab;
        var panel = document.getElementById(panelId);
        if (panel) panel.classList.add('active');

        // Populate history panel on click
        if (tab.dataset.lrTab === 'history') {
          var hc = document.getElementById('lr-history-content');
          if (hc) {
            hc.innerHTML = _buildHistoryPanel();
            _bindHistoryActions();
          }
        }
      });
    });
  }

  function _bindHistoryActions() {
    // Clear all
    var clearBtn = document.getElementById('lr-btn-clear-history');
    if (clearBtn) {
      clearBtn.addEventListener('click', function() {
        if (window.confirm('Delete all saved lab results from this device?')) {
          _clearHistory();
          var hc = document.getElementById('lr-history-content');
          if (hc) hc.innerHTML = _buildHistoryPanel();
        }
      });
    }
    // Load report into form
    document.querySelectorAll('.lr-btn-load-report').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var idx = parseInt(btn.dataset.reportIdx, 10);
        var history = _loadHistory();
        var report = history[idx];
        if (!report) return;

        // Switch to manual tab
        var manualTab = document.querySelector('.lr-tab[data-lr-tab="manual"]');
        if (manualTab) manualTab.click();

        // Populate date/lab
        var dateIn = document.getElementById('lr-report-date');
        var labIn  = document.getElementById('lr-report-lab');
        if (dateIn) dateIn.value = report.reportDate || '';
        if (labIn)  labIn.value  = report.reportLab  || '';

        // Populate rows
        var container = document.getElementById('lr-rows-container');
        if (!container) return;
        container.innerHTML = '';
        (report.results || []).forEach(function(r) {
          _rowIndex++;
          container.insertAdjacentHTML('beforeend', _buildRow(_rowIndex));
          var row = container.querySelector('#lr-row-' + _rowIndex);
          if (!row) return;
          row.querySelector('.lr-row-name').value  = r.name  || '';
          row.querySelector('.lr-row-value').value = r.value || '';
          row.querySelector('.lr-row-unit').value  = r.unit  || '';
          row.querySelector('.lr-row-low').value   = r.low   || '';
          row.querySelector('.lr-row-high').value  = r.high  || '';
          row.querySelector('.lr-row-date').value  = r.date  || '';
        });
        if (!container.querySelector('.lr-row')) _addRow('#lr-rows-container');
      });
    });
  }

  // ── PUBLIC init() ─────────────────────────────────────────────────────────

  function init() {
    // Inject datalist into the document once
    if (!document.getElementById('lr-test-suggestions')) {
      document.body.insertAdjacentHTML('beforeend', _DATALIST_HTML);
    }

    // Start with one empty row (manual panel)
    var container = document.getElementById('lr-rows-container');
    if (container) {
      container.innerHTML = '';
      _rowIndex++;
      container.insertAdjacentHTML('beforeend', _buildRow(_rowIndex));
    }

    _initTabs();

    // ── Manual panel ──────────────────────────────────────────────────────
    var addRowBtn = document.getElementById('lr-btn-add-row');
    if (addRowBtn) addRowBtn.addEventListener('click', function() { _addRow('#lr-rows-container'); });

    var explainBtn = document.getElementById('lr-btn-explain');
    if (explainBtn) explainBtn.addEventListener('click', function() {
      var data = _collectRows('#lr-rows-container', '#lr-report-date', '#lr-report-lab');
      _renderExplanation(data);
    });

    var clearBtn = document.getElementById('lr-btn-clear-form');
    if (clearBtn) clearBtn.addEventListener('click', function() {
      var c = document.getElementById('lr-rows-container');
      if (c) c.innerHTML = '';
      var dateIn = document.getElementById('lr-report-date');
      var labIn  = document.getElementById('lr-report-lab');
      if (dateIn) dateIn.value = '';
      if (labIn)  labIn.value  = '';
      _rowIndex++;
      if (c) c.insertAdjacentHTML('beforeend', _buildRow(_rowIndex));
      var ex = document.getElementById('lr-explanation');
      if (ex) { ex.innerHTML = ''; ex.classList.add('hidden'); }
    });

    // Remove-row delegation (manual panel)
    var manualPanel = document.getElementById('lr-panel-manual');
    if (manualPanel) {
      manualPanel.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-remove-idx]');
        if (!btn) return;
        var idx = btn.dataset.removeIdx;
        var c = document.getElementById('lr-rows-container');
        // Keep at least one row
        if (c && c.querySelectorAll('.lr-row').length > 1) _removeRow(idx);
      });
    }

    // ── Attach panel ──────────────────────────────────────────────────────
    var dropZone  = document.getElementById('lr-drop-zone');
    var fileInput = document.getElementById('lr-file-input');

    if (dropZone && fileInput) {
      dropZone.addEventListener('click', function() { fileInput.click(); });
      dropZone.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); }
      });
      fileInput.addEventListener('change', function() {
        if (fileInput.files && fileInput.files[0]) _handleFile(fileInput.files[0]);
      });
      dropZone.addEventListener('dragover', function(e) {
        e.preventDefault();
        dropZone.classList.add('lr-drop-zone-active');
      });
      dropZone.addEventListener('dragleave', function() {
        dropZone.classList.remove('lr-drop-zone-active');
      });
      dropZone.addEventListener('drop', function(e) {
        e.preventDefault();
        dropZone.classList.remove('lr-drop-zone-active');
        var file = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (file) _handleFile(file);
      });
    }

    var addRowBtnAtt = document.getElementById('lr-btn-add-row-att');
    if (addRowBtnAtt) addRowBtnAtt.addEventListener('click', function() { _addRow('#lr-rows-container-att'); });

    var explainBtnAtt = document.getElementById('lr-btn-explain-att');
    if (explainBtnAtt) explainBtnAtt.addEventListener('click', function() {
      var data = _collectRows('#lr-rows-container-att', '#lr-report-date-att', '#lr-report-lab-att');
      _renderExplanation(data);
    });

    var clearBtnAtt = document.getElementById('lr-btn-clear-form-att');
    if (clearBtnAtt) clearBtnAtt.addEventListener('click', function() {
      var c = document.getElementById('lr-rows-container-att');
      if (c) c.innerHTML = '';
      var dateIn = document.getElementById('lr-report-date-att');
      var labIn  = document.getElementById('lr-report-lab-att');
      if (dateIn) dateIn.value = '';
      if (labIn)  labIn.value  = '';
      var preview  = document.getElementById('lr-file-preview');
      var formArea = document.getElementById('lr-attach-form');
      if (preview)  { preview.innerHTML = '';  preview.classList.add('hidden'); }
      if (formArea) formArea.classList.add('hidden');
      if (fileInput) fileInput.value = '';
      var ex = document.getElementById('lr-explanation');
      if (ex) { ex.innerHTML = ''; ex.classList.add('hidden'); }
    });

    // Remove-row delegation (attach panel)
    var attachPanel = document.getElementById('lr-panel-attach');
    if (attachPanel) {
      attachPanel.addEventListener('click', function(e) {
        var btn = e.target.closest('[data-remove-idx]');
        if (!btn) return;
        var idx = btn.dataset.removeIdx;
        var c = document.getElementById('lr-rows-container-att');
        if (c && c.querySelectorAll('.lr-row').length > 1) _removeRow(idx);
      });
    }
  }

  // ── PUBLIC API ────────────────────────────────────────────────────────────
  return { init: init };

}());
