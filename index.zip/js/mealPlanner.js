/**
 * DialysisCare AI Assistant — js/mealPlanner.js
 * ===============================================
 * Generates the 3-day meal plan view for a given culture + dialysis type.
 * All 18 meal plans are embedded inline — no XHR, works on file:// protocol.
 *
 * SAFETY: All plans are labelled as educational samples only.
 * Individual plans must be reviewed with a renal dietitian.
 */

var MealPlanner = (function () {

  // ── INLINE MEAL PLAN DATA ────────────────────────────────────────────────
  // Source: data/meal-plans.json (embedded to avoid XHR/file:// restriction)

  var _PLANS = [
    {
      "culture": "general", "dialysis_type": "hd",
      "label": "General / International — Hemodialysis",
      "disclaimer": "Sample plan only. Your individual limits for potassium, phosphorus, sodium, fluid, and protein are set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "Scrambled egg whites (3) on white toast (1 slice) with a small portion of grapes", "notes": "Egg whites are a great low-phosphorus protein." },
          "lunch":     { "meal": "Grilled chicken breast with white rice and boiled green beans", "notes": "Avoid adding salt. Use herbs and lemon for flavour." },
          "dinner":    { "meal": "Baked white fish with cauliflower mash and steamed cabbage", "notes": "Cauliflower mash is a kidney-friendly potato substitute." },
          "snack":     { "meal": "Apple slices or fresh strawberries", "notes": "Low-potassium fruits." } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread toast with unsalted butter and a small portion of blueberries", "notes": "Avoid jam — can be high in potassium." },
          "lunch":     { "meal": "Pasta (white) with lean ground beef and a small amount of fresh tomato (1 tbsp sauce only)", "notes": "Keep tomato portions very small." },
          "dinner":    { "meal": "Grilled chicken with white rice and boiled carrots (leached)", "notes": "Leach carrots before cooking." },
          "snack":     { "meal": "Rice cakes (unsalted) with a small amount of cream cheese", "notes": "Check cream cheese sodium on label." } },
        { "day": "Day 3",
          "breakfast": { "meal": "Omelette with egg whites and finely chopped onion and bell pepper", "notes": "Bell pepper in small amounts is acceptable." },
          "lunch":     { "meal": "Grilled white fish with white bread and cucumber slices", "notes": "Use lemon and dill rather than salt." },
          "dinner":    { "meal": "Lean pork loin with white rice and boiled green beans", "notes": "Choose unprocessed, fresh pork rather than cured." },
          "snack":     { "meal": "Watermelon (small slice)", "notes": "Low potassium but counts toward fluid allowance." } }
      ]
    },
    {
      "culture": "general", "dialysis_type": "pd",
      "label": "General / International — Peritoneal Dialysis",
      "disclaimer": "PD patients may have slightly different nutrient targets than HD patients. Your plan is set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "Scrambled eggs (1 whole + 2 whites) on white toast with fresh strawberries", "notes": "PD patients often have a slightly higher potassium allowance than HD — confirm with your dietitian." },
          "lunch":     { "meal": "Grilled chicken with white rice, boiled green beans and a side salad (cucumber, iceberg lettuce)", "notes": "Iceberg lettuce is low in potassium." },
          "dinner":    { "meal": "White fish with boiled carrots (leached) and white pasta", "notes": "Leach carrots." },
          "snack":     { "meal": "Grapes or apple slices", "notes": "Low-potassium fruit options." } },
        { "day": "Day 2",
          "breakfast": { "meal": "White toast with unsalted butter and a boiled egg", "notes": "1 whole egg is acceptable for many PD patients — confirm portion with dietitian." },
          "lunch":     { "meal": "Lean beef stir-fry with white rice and cabbage", "notes": "Use minimal low-sodium soy sauce (½ tsp)." },
          "dinner":    { "meal": "Baked chicken thigh (skinless) with boiled white rice and steamed broccoli (moderate portion)", "notes": "Broccoli in moderate amounts only." },
          "snack":     { "meal": "Rice cakes with small amount of low-fat cream cheese", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Egg white omelette with onion and bell pepper on white toast", "notes": "" },
          "lunch":     { "meal": "Grilled white fish with white bread, iceberg lettuce and cucumber", "notes": "" },
          "dinner":    { "meal": "Chicken and white rice soup (homemade, low-sodium stock)", "notes": "Avoid commercial stock cubes — very high sodium." },
          "snack":     { "meal": "Fresh pineapple (small portion)", "notes": "Low potassium tropical fruit." } }
      ]
    },
    {
      "culture": "south-asian", "dialysis_type": "hd",
      "label": "South Asian — Hemodialysis",
      "disclaimer": "Adapted for South Asian food traditions. Your individual limits are set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White bread or plain white paratha (small, made with white flour) with a plain egg omelette", "notes": "Avoid whole wheat chapati — higher phosphorus." },
          "lunch":     { "meal": "Gobi (cauliflower) curry (without potato) with white basmati rice", "notes": "Cauliflower is naturally kidney-friendly. Use minimal salt." },
          "dinner":    { "meal": "Chicken curry (leaner cuts, small gravy portion) with white rice", "notes": "Season with cumin, coriander, turmeric — no added salt." },
          "snack":     { "meal": "Apple slices or pineapple chunks", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "Plain white rice with a small portion of egg curry (2 egg whites, 1 yolk)", "notes": "" },
          "lunch":     { "meal": "Cabbage sabzi (stir-fried cabbage with cumin and turmeric) with white basmati rice", "notes": "Very kidney-friendly combination." },
          "dinner":    { "meal": "Fish curry (white fish) with white rice and boiled green beans", "notes": "Use fresh tomatoes minimally in the curry base." },
          "snack":     { "meal": "Grapes or strawberries", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Semolina upma (made with minimal salt, with peas in small amount)", "notes": "Peas in moderate amount only." },
          "lunch":     { "meal": "Chicken tikka (grilled, no sauce) with white rice and cucumber raita (small amount)", "notes": "Plain yogurt in very small amount (2 tbsp) for raita." },
          "dinner":    { "meal": "Aloo gobi — use leached potato (soak overnight) and cauliflower with white rice", "notes": "Always leach potato before cooking." },
          "snack":     { "meal": "Plain rice cakes or cream crackers", "notes": "" } }
      ]
    },
    {
      "culture": "south-asian", "dialysis_type": "pd",
      "label": "South Asian — Peritoneal Dialysis",
      "disclaimer": "Adapted for South Asian food traditions. PD nutrient targets may differ from HD. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "Plain white paratha (small) with egg whites scrambled", "notes": "" },
          "lunch":     { "meal": "Gobi matar (cauliflower and small amount of peas) with white rice", "notes": "Peas in moderate amounts only." },
          "dinner":    { "meal": "Chicken curry with white rice", "notes": "Season with spices — minimal salt." },
          "snack":     { "meal": "Fresh mango (small portion — moderate potassium)", "notes": "Discuss mango portion with your dietitian — moderate potassium." } },
        { "day": "Day 2",
          "breakfast": { "meal": "White toast with a boiled egg and apple slices", "notes": "" },
          "lunch":     { "meal": "Dal (small portion, red lentils only, well-rinsed) with white basmati rice", "notes": "Lentils are higher in potassium — confirm portion with dietitian." },
          "dinner":    { "meal": "Fish masala (white fish) with white rice and cabbage sabzi", "notes": "" },
          "snack":     { "meal": "Plain rice cakes or biscuits", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Semolina porridge (suji) made with water, light sweetened", "notes": "" },
          "lunch":     { "meal": "Grilled chicken tikka with naan (white) and small fresh salad (cucumber, iceberg)", "notes": "" },
          "dinner":    { "meal": "Chicken and vegetable broth with white rice (homemade, no stock cubes)", "notes": "" },
          "snack":     { "meal": "Strawberries or blueberries", "notes": "" } }
      ]
    },
    {
      "culture": "east-asian", "dialysis_type": "hd",
      "label": "East Asian — Hemodialysis",
      "disclaimer": "Adapted for East Asian food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "Plain white congee (rice porridge) with a small amount of chicken and ginger", "notes": "Make with water, not commercial stock." },
          "lunch":     { "meal": "Steamed white rice with stir-fried chicken and bok choy (cabbage variety — low potassium)", "notes": "Use minimal low-sodium soy sauce (½ tsp)." },
          "dinner":    { "meal": "Steamed white fish with white rice and steamed cabbage", "notes": "" },
          "snack":     { "meal": "Fresh pineapple or grapes", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White rice with a plain fried egg (1 whole egg)", "notes": "" },
          "lunch":     { "meal": "Chicken and white rice noodle soup (homemade broth, low sodium)", "notes": "Avoid instant noodles — very high sodium." },
          "dinner":    { "meal": "Baked white fish with stir-fried white cabbage and white rice", "notes": "" },
          "snack":     { "meal": "Apple slices", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White rice porridge with egg whites and thin-sliced chicken", "notes": "" },
          "lunch":     { "meal": "Lean beef and white rice with boiled green beans", "notes": "Minimal sauce, season with ginger and scallion." },
          "dinner":    { "meal": "Steamed tofu (small portion) with white rice and bok choy", "notes": "Tofu moderate in phosphorus — small portions only." },
          "snack":     { "meal": "Watermelon (small slice)", "notes": "Counts toward fluid." } }
      ]
    },
    {
      "culture": "east-asian", "dialysis_type": "pd",
      "label": "East Asian — Peritoneal Dialysis",
      "disclaimer": "Adapted for East Asian food traditions. PD nutrient targets may differ. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White congee with shredded chicken and ginger", "notes": "" },
          "lunch":     { "meal": "White rice with steamed fish and bok choy stir-fry", "notes": "Season with a small amount of low-sodium soy sauce." },
          "dinner":    { "meal": "White rice noodles with chicken broth (homemade) and cabbage", "notes": "" },
          "snack":     { "meal": "Grapes or strawberries", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White toast with scrambled egg whites and fresh cucumber slices", "notes": "" },
          "lunch":     { "meal": "Chicken and white rice bowl with lightly sautéed green beans", "notes": "" },
          "dinner":    { "meal": "Steamed white fish with white rice and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Fresh pineapple chunks", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Plain white rice with a fried egg and small cucumber salad", "notes": "" },
          "lunch":     { "meal": "Lean pork with white rice and stir-fried cabbage", "notes": "Minimal oil and salt." },
          "dinner":    { "meal": "White fish congee with ginger and scallion", "notes": "" },
          "snack":     { "meal": "Apple slices or blueberries", "notes": "" } }
      ]
    },
    {
      "culture": "west-african", "dialysis_type": "hd",
      "label": "West African — Hemodialysis",
      "disclaimer": "Adapted for West African food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White bread with a plain egg omelette and a small portion of fresh papaya", "notes": "" },
          "lunch":     { "meal": "White rice with grilled chicken and boiled cabbage", "notes": "Season with fresh tomatoes (small amount), onion, and garlic — no stock cubes." },
          "dinner":    { "meal": "Boiled white rice with fish stew (white fish, small tomato, onion)", "notes": "Avoid heavy tomato-based stews — limit fresh tomato." },
          "snack":     { "meal": "Grapes or apple slices", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "Garri (cassava flour porridge) with a small boiled egg", "notes": "Garri is low in potassium and phosphorus — a good staple." },
          "lunch":     { "meal": "Jollof rice (made with minimal tomato paste, no stock cubes) with grilled chicken", "notes": "Use fresh tomatoes sparingly, season with thyme and bay leaf." },
          "dinner":    { "meal": "Boiled yam (leached, moderate portion) with egg stew", "notes": "Leach yam before boiling." },
          "snack":     { "meal": "Watermelon (small portion)", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White bread with scrambled eggs and cucumber slices", "notes": "" },
          "lunch":     { "meal": "Fried rice (white rice, egg, cabbage, minimal soy sauce) with grilled white fish", "notes": "" },
          "dinner":    { "meal": "Pepper soup (light, with chicken or fish, no excessive salt)", "notes": "Use fresh herbs and spices instead of stock cubes." },
          "snack":     { "meal": "Pineapple chunks or blueberries", "notes": "" } }
      ]
    },
    {
      "culture": "west-african", "dialysis_type": "pd",
      "label": "West African — Peritoneal Dialysis",
      "disclaimer": "Adapted for West African food traditions. PD targets may differ from HD. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "Garri with a boiled egg and apple slices", "notes": "" },
          "lunch":     { "meal": "White rice with chicken stew (fresh tomato, onion, minimal salt)", "notes": "" },
          "dinner":    { "meal": "Boiled white fish with boiled yam (leached) and green salad (cucumber, iceberg)", "notes": "" },
          "snack":     { "meal": "Fresh papaya (small portion)", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with egg omelette and grapes", "notes": "" },
          "lunch":     { "meal": "Jollof rice (minimal tomato paste) with grilled fish", "notes": "" },
          "dinner":    { "meal": "Chicken and vegetable soup (cabbage, carrot — leached, onion, garlic) with white bread", "notes": "" },
          "snack":     { "meal": "Watermelon (small slice)", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White semolina porridge (ogi/pap) lightly sweetened with sugar", "notes": "Avoid flavoured sachet versions — high sodium." },
          "lunch":     { "meal": "White rice with grilled chicken and boiled cabbage", "notes": "" },
          "dinner":    { "meal": "Light egusi soup (small portion of egusi with leafy green — leached) with white rice", "notes": "Small portion of egusi only. Consult dietitian for approval." },
          "snack":     { "meal": "Apple or pineapple", "notes": "" } }
      ]
    },
    {
      "culture": "caribbean", "dialysis_type": "hd",
      "label": "Caribbean — Hemodialysis",
      "disclaimer": "Adapted for Caribbean food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White bread toast with scrambled eggs and a small portion of watermelon", "notes": "" },
          "lunch":     { "meal": "Grilled jerk chicken (low-salt seasoning) with white rice and boiled green beans", "notes": "Use jerk spice without added salt. No jerk sauce — high sodium." },
          "dinner":    { "meal": "Steamed white fish with white rice and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Grapes or strawberries", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "Cornmeal porridge (light, low sugar, made with water not milk)", "notes": "Made with water — avoid full milk." },
          "lunch":     { "meal": "Brown stew chicken (fresh tomatoes, small amount, onion, thyme, allspice) with white rice", "notes": "Avoid browning sauce — very high sodium." },
          "dinner":    { "meal": "Baked fish with white rice and steamed cabbage", "notes": "" },
          "snack":     { "meal": "Pineapple chunks or apple slices", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White dumplings (boiled, not fried) with a small egg omelette", "notes": "Boiled dumplings are lower in fat." },
          "lunch":     { "meal": "Rice and peas (white rice, very well-rinsed kidney beans — small portion only)", "notes": "Kidney beans are high in potassium/phosphorus — rinse thoroughly and use a very small portion. Confirm with dietitian." },
          "dinner":    { "meal": "Grilled chicken with white rice and boiled leached plantain (small amount)", "notes": "Leach plantain by soaking 2+ hours before cooking." },
          "snack":     { "meal": "Fresh mango (small portion — moderate potassium, discuss with dietitian)", "notes": "" } }
      ]
    },
    {
      "culture": "caribbean", "dialysis_type": "pd",
      "label": "Caribbean — Peritoneal Dialysis",
      "disclaimer": "Adapted for Caribbean food traditions. PD targets may differ from HD. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White toast with ackee and egg (ackee in small portion only)", "notes": "Traditional ackee and saltfish must have salt fish thoroughly desalted. Use ackee with egg as alternative." },
          "lunch":     { "meal": "Grilled chicken with white rice and boiled green beans", "notes": "" },
          "dinner":    { "meal": "Steamed fish with white rice and cabbage", "notes": "" },
          "snack":     { "meal": "Watermelon or grapes", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "Cornmeal porridge (water-based, light sugar) with a boiled egg", "notes": "" },
          "lunch":     { "meal": "Chicken soup (homemade, low-sodium) with white dumplings and cho cho (chayote)", "notes": "Cho cho is low in potassium." },
          "dinner":    { "meal": "Brown stew chicken with white rice and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Apple or pineapple", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Egg omelette with white bread and fresh strawberries", "notes": "" },
          "lunch":     { "meal": "White rice with baked fish and stir-fried cabbage and onion", "notes": "" },
          "dinner":    { "meal": "Chicken and vegetable broth (cabbage, cho cho, onion) with white rice", "notes": "" },
          "snack":     { "meal": "Blueberries or grapes", "notes": "" } }
      ]
    },
    {
      "culture": "latin-american", "dialysis_type": "hd",
      "label": "Latin American — Hemodialysis",
      "disclaimer": "Adapted for Latin American food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White corn tortillas (2) with scrambled egg whites and fresh salsa (very small amount — 1 tbsp)", "notes": "" },
          "lunch":     { "meal": "Arroz con pollo (chicken with white rice, minimal tomato, herbs)", "notes": "Avoid heavy tomato base." },
          "dinner":    { "meal": "Grilled white fish with white rice and boiled green beans", "notes": "" },
          "snack":     { "meal": "Apple slices or pineapple", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with plain scrambled eggs and fresh cucumber", "notes": "" },
          "lunch":     { "meal": "Chicken and white rice soup (caldo de pollo — homemade, low sodium)", "notes": "No commercial stock cubes." },
          "dinner":    { "meal": "Grilled chicken thighs with white rice and boiled cabbage", "notes": "Season with cumin, lime, and garlic — no added salt." },
          "snack":     { "meal": "Grapes or blueberries", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White corn tortillas with egg white omelette and small cucumber-onion salad", "notes": "" },
          "lunch":     { "meal": "White rice with well-rinsed black beans (very small portion, ¼ cup) and grilled chicken", "notes": "Rinse canned beans thoroughly. Small portion only." },
          "dinner":    { "meal": "Baked fish with white rice and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Watermelon (small slice)", "notes": "" } }
      ]
    },
    {
      "culture": "latin-american", "dialysis_type": "pd",
      "label": "Latin American — Peritoneal Dialysis",
      "disclaimer": "Adapted for Latin American food traditions. PD targets may differ. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White tortillas with scrambled eggs and cucumber slices", "notes": "" },
          "lunch":     { "meal": "Grilled chicken with white rice and sautéed cabbage with garlic", "notes": "" },
          "dinner":    { "meal": "White fish ceviche (lime-marinated, fresh — no added salt) with white rice", "notes": "Traditional ceviche preparation without excessive salt." },
          "snack":     { "meal": "Fresh pineapple or strawberries", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with a boiled egg and apple", "notes": "" },
          "lunch":     { "meal": "Chicken and rice soup (sopa de pollo, homemade) with cabbage", "notes": "" },
          "dinner":    { "meal": "Lean beef with white rice and boiled green beans", "notes": "" },
          "snack":     { "meal": "Grapes or watermelon (small)", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Egg white omelette with white corn tortillas and salsa (1 tbsp)", "notes": "" },
          "lunch":     { "meal": "Grilled fish tacos (corn tortillas, white fish, cabbage slaw — no sour cream)", "notes": "" },
          "dinner":    { "meal": "Chicken with white rice and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Apple slices or blueberries", "notes": "" } }
      ]
    },
    {
      "culture": "middle-eastern", "dialysis_type": "hd",
      "label": "Middle Eastern — Hemodialysis",
      "disclaimer": "Adapted for Middle Eastern food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White pita bread with labneh (strained yogurt, 2 tbsp) and fresh cucumber and tomato (small amount)", "notes": "Small portion of labneh — moderate phosphorus." },
          "lunch":     { "meal": "Grilled chicken shish taouk with white rice and small cucumber salad", "notes": "Season with lemon, garlic, cumin — no added salt." },
          "dinner":    { "meal": "Baked white fish with white rice and steamed cabbage", "notes": "" },
          "snack":     { "meal": "Apple or grapes", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with white cheese (small amount, e.g. mild low-salt white cheese) and cucumber", "notes": "" },
          "lunch":     { "meal": "Chicken and rice (roz bel djaj style — minimal spice, no heavy tomato)", "notes": "" },
          "dinner":    { "meal": "Grilled lamb kebab (small portion) with white rice and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Watermelon (small portion)", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White pita with egg and cucumber omelette wrap", "notes": "" },
          "lunch":     { "meal": "Chicken shawarma (no garlic sauce, minimal salt) with white rice and iceberg salad", "notes": "" },
          "dinner":    { "meal": "White fish tagine (light, with leached carrots and onion) with white couscous", "notes": "White couscous is low in potassium." },
          "snack":     { "meal": "Fresh pineapple or blueberries", "notes": "" } }
      ]
    },
    {
      "culture": "middle-eastern", "dialysis_type": "pd",
      "label": "Middle Eastern — Peritoneal Dialysis",
      "disclaimer": "Adapted for Middle Eastern food traditions. PD targets may differ. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White pita with labneh (2 tbsp) and cucumber", "notes": "" },
          "lunch":     { "meal": "Grilled chicken with white couscous and boiled green beans", "notes": "" },
          "dinner":    { "meal": "Baked fish with white rice and steamed cabbage", "notes": "" },
          "snack":     { "meal": "Grapes or apple", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with scrambled eggs and tomato (small, fresh — ½ small tomato)", "notes": "" },
          "lunch":     { "meal": "Chicken and rice dish (lightly spiced) with small cucumber salad", "notes": "" },
          "dinner":    { "meal": "Grilled white fish with white rice and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Watermelon or blueberries", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White pita with egg omelette and fresh cucumber", "notes": "" },
          "lunch":     { "meal": "Lamb and vegetable soup (light, homemade stock) with white bread", "notes": "" },
          "dinner":    { "meal": "Chicken with white couscous and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Apple slices or strawberries", "notes": "" } }
      ]
    },
    {
      "culture": "east-african", "dialysis_type": "hd",
      "label": "East African — Hemodialysis",
      "disclaimer": "Adapted for East African food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White injera (small piece) or white bread with a plain egg omelette", "notes": "White injera (if available) or substitute with white bread." },
          "lunch":     { "meal": "Grilled chicken tibs (cubed chicken, onion, green chilli — minimal salt) with white rice", "notes": "" },
          "dinner":    { "meal": "White fish with white rice and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Apple or grapes", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White bread with scrambled egg whites and fresh cucumber", "notes": "" },
          "lunch":     { "meal": "Doro wat (chicken stew — small portion, no excessive berbere/salt) with white rice", "notes": "Use minimal berbere and no extra salt." },
          "dinner":    { "meal": "Baked white fish with white rice and boiled leached green beans", "notes": "" },
          "snack":     { "meal": "Watermelon or pineapple", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "Porridge made with white semolina and light sugar (no salt)", "notes": "" },
          "lunch":     { "meal": "Grilled lean beef with white rice and leached cabbage and carrot", "notes": "" },
          "dinner":    { "meal": "Chicken and white rice soup (shiro-free, homemade broth)", "notes": "Avoid shiro — high in potassium and phosphorus." },
          "snack":     { "meal": "Blueberries or fresh papaya (small portion)", "notes": "" } }
      ]
    },
    {
      "culture": "east-african", "dialysis_type": "pd",
      "label": "East African — Peritoneal Dialysis",
      "disclaimer": "Adapted for East African food traditions. PD targets may differ. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White injera or white bread with egg omelette", "notes": "" },
          "lunch":     { "meal": "Chicken tibs with white rice and stir-fried cabbage", "notes": "" },
          "dinner":    { "meal": "White fish with white rice and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Grapes or apple", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White semolina porridge with a boiled egg", "notes": "" },
          "lunch":     { "meal": "Lean beef stew (light, with onion, tomato — small, fresh) with white rice", "notes": "" },
          "dinner":    { "meal": "Baked chicken with white rice and boiled green beans", "notes": "" },
          "snack":     { "meal": "Pineapple or watermelon (small portion)", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White bread with scrambled eggs and cucumber", "notes": "" },
          "lunch":     { "meal": "Fish tilapia with white rice and leached cabbage", "notes": "" },
          "dinner":    { "meal": "Homemade chicken soup with white rice and small side of boiled leached carrots", "notes": "" },
          "snack":     { "meal": "Blueberries or strawberries", "notes": "" } }
      ]
    },
    {
      "culture": "european", "dialysis_type": "hd",
      "label": "European — Hemodialysis",
      "disclaimer": "Adapted for European food traditions. Individual limits set by your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White toast with unsalted butter and poached eggs (2 whites, 1 yolk)", "notes": "" },
          "lunch":     { "meal": "Grilled chicken breast with white rice and steamed green beans", "notes": "" },
          "dinner":    { "meal": "Baked cod fillet with white pasta and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Apple or pear", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "White cereal (e.g. cornflakes — low phosphorus) with a small amount of milk (½ cup max)", "notes": "Cornflakes are a better choice than bran or wholegrain cereals." },
          "lunch":     { "meal": "Chicken and white rice salad with cucumber, lettuce, and lemon dressing", "notes": "" },
          "dinner":    { "meal": "Roast chicken (no skin) with leached roast potatoes (small portion, thoroughly leached) and boiled cabbage", "notes": "Leach potatoes thoroughly before roasting." },
          "snack":     { "meal": "Grapes or blueberries", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White toast with a small amount of unsalted peanut butter (1 tsp — check with dietitian)", "notes": "Peanut butter moderate in phosphorus — small amount only." },
          "lunch":     { "meal": "White bread sandwich with sliced chicken breast, iceberg lettuce and cucumber", "notes": "Avoid cured/processed deli meats." },
          "dinner":    { "meal": "Grilled salmon (small portion — moderate phosphorus) with white rice and boiled carrots (leached)", "notes": "Salmon is higher in phosphorus than white fish — confirm portion with dietitian." },
          "snack":     { "meal": "Watermelon or strawberries", "notes": "" } }
      ]
    },
    {
      "culture": "european", "dialysis_type": "pd",
      "label": "European — Peritoneal Dialysis",
      "disclaimer": "Adapted for European food traditions. PD targets may differ. Consult your renal dietitian.",
      "days": [
        { "day": "Day 1",
          "breakfast": { "meal": "White toast with poached egg and fresh cucumber", "notes": "" },
          "lunch":     { "meal": "Chicken and white pasta salad with cucumber and iceberg lettuce", "notes": "" },
          "dinner":    { "meal": "Baked white fish with leached boiled potatoes (small) and steamed green beans", "notes": "" },
          "snack":     { "meal": "Apple or pear", "notes": "" } },
        { "day": "Day 2",
          "breakfast": { "meal": "Cornflakes with a small amount of milk (½ cup) and strawberries", "notes": "" },
          "lunch":     { "meal": "Grilled chicken with white bread and a small salad (iceberg, cucumber)", "notes": "" },
          "dinner":    { "meal": "Roast chicken (no skin) with white rice and boiled cabbage", "notes": "" },
          "snack":     { "meal": "Grapes or blueberries", "notes": "" } },
        { "day": "Day 3",
          "breakfast": { "meal": "White toast with scrambled egg whites and a small portion of fresh tomato (½ small)", "notes": "" },
          "lunch":     { "meal": "White bread sandwich with chicken, lettuce and cucumber", "notes": "" },
          "dinner":    { "meal": "Grilled white fish with white pasta and boiled carrots (leached)", "notes": "" },
          "snack":     { "meal": "Watermelon (small) or apple", "notes": "" } }
      ]
    }
  ];

  // ── LOOKUP ────────────────────────────────────────────────────────────────

  function _findPlan(culture, dialysisType) {
    var c = (culture || 'general').toLowerCase();
    var t = (dialysisType || 'hd').toLowerCase();
    for (var i = 0; i < _PLANS.length; i++) {
      if (_PLANS[i].culture === c && _PLANS[i].dialysis_type === t) {
        return _PLANS[i];
      }
    }
    // Fallback to general
    for (var j = 0; j < _PLANS.length; j++) {
      if (_PLANS[j].culture === 'general' && _PLANS[j].dialysis_type === t) {
        return _PLANS[j];
      }
    }
    return null;
  }

  // ── RENDER ────────────────────────────────────────────────────────────────

  function buildPlanHTML(culture, dialysisType) {
    var plan = _findPlan(culture, dialysisType);

    if (!plan) {
      return '<div class="notice notice-warning">' +
        '<span class="notice-icon">⚠️</span>' +
        '<div class="notice-body">Meal plan not found for this combination. ' +
        'Please consult your renal dietitian for a personalised plan.</div></div>';
    }

    var typeLabel = dialysisType === 'hd' ? 'Hemodialysis (HD)' : 'Peritoneal Dialysis (PD)';

    var html = '<div class="notice notice-danger" style="margin-bottom:1.5rem;">' +
      '<span class="notice-icon">⚕️</span>' +
      '<div class="notice-body"><strong>Educational Sample Only</strong><br>' +
      _esc(plan.disclaimer) + '</div></div>';

    html += '<div class="notice notice-info" style="margin-bottom:1.5rem;">' +
      '<span class="notice-icon">🍽️</span>' +
      '<div class="notice-body"><strong>' + _esc(plan.label) + '</strong><br>' +
      'Dialysis type: <strong>' + _esc(typeLabel) + '</strong></div></div>';

    plan.days.forEach(function(day) {
      html += '<div class="meal-plan-day">';
      html += '<h3 class="meal-day-header">' + _esc(day.day) + '</h3>';
      html += '<div class="meal-grid">';
      html += _mealRow('🌅', 'Breakfast', day.breakfast);
      html += _mealRow('☀️',  'Lunch',     day.lunch);
      html += _mealRow('🌙', 'Dinner',    day.dinner);
      html += _mealRow('🍎', 'Snack',     day.snack);
      html += '</div>';
      html += '</div>';
    });

    html += '<div class="notice notice-success" style="margin-top:1.5rem;">' +
      '<span class="notice-icon">👩‍⚕️</span>' +
      '<div class="notice-body"><strong>Next Step: Review with Your Renal Dietitian</strong><br>' +
      'This sample plan is a starting point only. Your dietitian will adjust it based on your ' +
      'blood results, fluid allowance, residual kidney function, and personal food preferences.</div></div>';

    return html;
  }

  function _mealRow(icon, label, mealObj) {
    if (!mealObj) return '';
    var noteHtml = mealObj.notes
      ? '<div class="meal-note">💡 ' + _esc(mealObj.notes) + '</div>'
      : '';
    return '<div class="meal-row">' +
      '<div class="meal-label">' + icon + ' <strong>' + _esc(label) + '</strong></div>' +
      '<div class="meal-content">' +
      '<div class="meal-text">' + _esc(mealObj.meal) + '</div>' +
      noteHtml +
      '</div>' +
      '</div>';
  }

  function _esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── PUBLIC API ────────────────────────────────────────────────────────────
  return {
    buildPlanHTML: buildPlanHTML,
    findPlan:      _findPlan
  };

}());
