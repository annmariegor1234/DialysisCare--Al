/**
 * DialysisCare AI Assistant — js/app.js
 * =========================================
 * Stage 1: UI Shell & Navigation ONLY.
 *
 * Loaded as a plain <script> (no type="module") so the app works
 * by double-clicking index.html — no local server required.
 *
 * What this file does:
 *  - Renders static placeholder views for each section
 *  - Handles sidebar navigation (active state, view switching)
 *  - Handles the disclaimer modal
 *  - Handles mobile sidebar toggle
 *  - Renders a placeholder chat interface (non-functional in Stage 1)
 *  - Renders a placeholder Safety Review queue (non-functional in Stage 1)
 *
 * What this file does NOT do (reserved for later stages):
 *  - No AI or NLP logic
 *  - No medical knowledge base
 *  - No patient data of any kind
 *  - No real safety review submission/approval workflow
 *  - No nutrition/meal data lookups
 */

// ─────────────────────────────────────────────────────────────────────────────
// SECTION VIEWS — static HTML templates, one per navigation item
// ─────────────────────────────────────────────────────────────────────────────

const VIEWS = {

  // ── HOME ──────────────────────────────────────────────────────────────────
  home: () => `
    <div class="view-header">
      <span class="view-badge" style="background:#eff6ff;color:#3b82d4;border:1px solid #bfdbfe;">
        🏠 Welcome
      </span>
      <h1>DialysisCare AI Assistant</h1>
      <p class="view-subtitle">
        A safe, educational companion for hemodialysis and peritoneal dialysis patients
        and their caregivers. Always consult your healthcare team for personalised medical advice.
      </p>
    </div>

    <div class="notice notice-danger">
      <span class="notice-icon">🚨</span>
      <div class="notice-body">
        <strong>Medical Emergency?</strong>
        This tool is not for emergencies. Call emergency services (911 / 999 / 112) immediately
        if you or someone is in danger.
      </div>
    </div>

    <div class="notice notice-info">
      <span class="notice-icon">ℹ️</span>
      <div class="notice-body">
        <strong>Educational Tool Only</strong>
        This assistant provides general education about dialysis and kidney-friendly nutrition.
        It does not diagnose conditions, prescribe medications, or replace your care team's advice.
        High-risk medical questions are <em>held for review by a qualified healthcare professional</em>
        before any response is shown.
      </div>
    </div>

    <div class="card-grid">
      <div class="card card-hd">
        <span class="card-icon">💉</span>
        <h3>Hemodialysis</h3>
        <p>Learn how HD works, what to expect during treatment, and how to care for your access site.</p>
        <button class="card-link" data-nav="hemodialysis">Explore HD →</button>
      </div>
      <div class="card card-pd">
        <span class="card-icon">🫁</span>
        <h3>Peritoneal Dialysis</h3>
        <p>Understand PD exchanges, CAPD vs APD, and how to manage treatment at home.</p>
        <button class="card-link" data-nav="peritoneal">Explore PD →</button>
      </div>
      <div class="card card-nut">
        <span class="card-icon">🥗</span>
        <h3>Nutrition & Meal Planning</h3>
        <p>Discover kidney-friendly foods, cultural meal adaptations, and personalised plan guides.</p>
        <button class="card-link" data-nav="nutrition">Explore Nutrition →</button>
      </div>
      <div class="card" style="border-top:3px solid #b45309;">
        <span class="card-icon">📚</span>
        <h3>Education Library</h3>
        <p>Browse all articles on HD, PD, and kidney-friendly nutrition without the AI — always available.</p>
        <button class="card-link" data-nav="library">Browse Library →</button>
      </div>
      <div class="card card-saf">
        <span class="card-icon">🛡️</span>
        <h3>Safety Review Process</h3>
        <p>Understand how high-risk medical questions are flagged and reviewed by qualified clinicians.</p>
        <button class="card-link" data-nav="safety">Learn More →</button>
      </div>
      <div class="card card-ast">
        <span class="card-icon">💬</span>
        <h3>AI Assistant</h3>
        <p>Ask general questions about dialysis and kidney-friendly living. All responses are safety-screened.</p>
        <button class="card-link" data-nav="assistant">Open Chat →</button>
      </div>
      <div class="card" style="border-top:4px solid #0369a1;">
        <span class="card-icon">🔬</span>
        <h3>Understand Lab Results</h3>
        <p>Enter or attach your lab report. Get plain-language explanations and questions to ask your care team.</p>
        <button class="card-link" data-nav="labResults">Open Lab Results →</button>
      </div>
      <div class="card" style="border-top:4px solid #7c3aed;">
        <span class="card-icon">📅</span>
        <h3>Schedule &amp; Reminders</h3>
        <p>Track dialysis appointments, lab tests, and tasks. Save your clinic and taxi contacts for one-tap calling.</p>
        <button class="card-link" data-nav="schedule">Open Schedule →</button>
      </div>
    </div>

    <div class="content-block">
      <h2>How to Use This Tool</h2>
      <ol>
        <li><strong>Choose a section</strong> from the sidebar to read educational content.</li>
        <li><strong>Select your cultural background</strong> in Nutrition &amp; Meals for tailored food guidance.</li>
        <li><strong>Use the Assistant</strong> to ask general questions — responses are screened for safety.</li>
        <li><strong>Any high-risk question</strong> (medications, symptoms, lab values) is held and only shown after a qualified clinician has reviewed it.</li>
        <li><strong>Always follow up</strong> with your nephrologist, dialysis nurse, or dietitian.</li>
      </ol>
    </div>
  `,

  // ── HEMODIALYSIS (real content from hd-content.json) ──────────────────────
  hemodialysis: function() {
    function topicBlock(id) {
      var t = KnowledgeBase.isLoaded() ? KnowledgeBase.getTopic(id) : null;
      if (!t) return '<p class="text-muted"><em>Loading content…</em></p>';
      var pts = (t.key_points || []).map(function(p){ return '<li>' + escapeHtml(p) + '</li>'; }).join('');
      return '<p>' + escapeHtml(t.content) + '</p>' +
        (pts ? '<ul style="margin-top:0.75rem;">' + pts + '</ul>' : '') +
        (t.disclaimer ? '<div class="notice notice-info" style="margin-top:1rem;"><span class="notice-icon">⚕️</span><div class="notice-body">' + escapeHtml(t.disclaimer) + '</div></div>' : '');
    }
    return `
    <div class="view-header">
      <span class="view-badge" style="background:#eff6ff;color:#3b82d4;border:1px solid #bfdbfe;">💉 Hemodialysis Education</span>
      <h1>Understanding Hemodialysis</h1>
      <p class="view-subtitle">General educational information for HD patients and caregivers. No individualised medical advice.</p>
    </div>
    <div class="notice notice-danger">
      <span class="notice-icon">🚨</span>
      <div class="notice-body"><strong>Emergency?</strong> Call 911 / 999 / 112 immediately. Do not use this tool in emergencies.</div>
    </div>
    <div class="tabs" role="tablist" aria-label="Hemodialysis topics">
      <button class="tab-btn active" role="tab" aria-selected="true" data-tab="hd-overview">What is HD?</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="hd-access">Access Care</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="hd-session">During Treatment</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="hd-fluid">Fluid Management</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="hd-home">Home HD</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="hd-caregiver">For Caregivers</button>
    </div>
    <div id="hd-overview" class="tab-panel active">
      <div class="content-block"><h2>What is Hemodialysis?</h2>${topicBlock('hd-what-is')}</div>
      <div class="content-block"><h2>Common Side Effects</h2>${topicBlock('hd-common-side-effects')}</div>
    </div>
    <div id="hd-access" class="tab-panel">
      <div class="content-block"><h2>AV Fistula</h2>${topicBlock('hd-access-fistula')}</div>
      <div class="content-block"><h2>AV Graft</h2>${topicBlock('hd-access-graft')}</div>
      <div class="content-block"><h2>Central Venous Catheter (CVC)</h2>${topicBlock('hd-access-catheter')}</div>
    </div>
    <div id="hd-session" class="tab-panel">
      <div class="content-block"><h2>What to Expect During a Session</h2>${topicBlock('hd-what-to-expect')}</div>
    </div>
    <div id="hd-fluid" class="tab-panel">
      <div class="content-block"><h2>Fluid Management Between Sessions</h2>${topicBlock('hd-fluid-management')}</div>
    </div>
    <div id="hd-home" class="tab-panel">
      <div class="content-block"><h2>Home Hemodialysis</h2>${topicBlock('hd-home-dialysis')}</div>
    </div>
    <div id="hd-caregiver" class="tab-panel">
      <div class="content-block"><h2>Information for Caregivers</h2>${topicBlock('hd-caregiver')}</div>
    </div>`;
  },

  // ── PERITONEAL DIALYSIS (real content from pd-content.json) ──────────────
  peritoneal: function() {
    function topicBlock(id) {
      var t = KnowledgeBase.isLoaded() ? KnowledgeBase.getTopic(id) : null;
      if (!t) return '<p class="text-muted"><em>Loading content…</em></p>';
      var pts = (t.key_points || []).map(function(p){ return '<li>' + escapeHtml(p) + '</li>'; }).join('');
      return '<p>' + escapeHtml(t.content) + '</p>' +
        (pts ? '<ul style="margin-top:0.75rem;">' + pts + '</ul>' : '') +
        (t.disclaimer ? '<div class="notice notice-info" style="margin-top:1rem;"><span class="notice-icon">⚕️</span><div class="notice-body">' + escapeHtml(t.disclaimer) + '</div></div>' : '');
    }
    return `
    <div class="view-header">
      <span class="view-badge" style="background:#f5f0ff;color:#7c5cd8;border:1px solid #ddd6fe;">🫁 Peritoneal Dialysis Education</span>
      <h1>Understanding Peritoneal Dialysis</h1>
      <p class="view-subtitle">General educational information for PD patients and caregivers. No individualised medical advice.</p>
    </div>
    <div class="notice notice-danger">
      <span class="notice-icon">🚨</span>
      <div class="notice-body"><strong>Emergency?</strong> Cloudy dialysate or severe abdominal pain → call your PD unit immediately. For life-threatening emergencies call 911 / 999 / 112.</div>
    </div>
    <div class="tabs" role="tablist" aria-label="Peritoneal dialysis topics">
      <button class="tab-btn active" role="tab" aria-selected="true" data-tab="pd-overview">What is PD?</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-types">CAPD vs APD</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-catheter">Catheter & Exit Site</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-exchange">Exchanges</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-complications">Peritonitis</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-travel">Travel</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="pd-caregiver">For Caregivers</button>
    </div>
    <div id="pd-overview" class="tab-panel active">
      <div class="content-block"><h2>What is Peritoneal Dialysis?</h2>${topicBlock('pd-what-is')}</div>
    </div>
    <div id="pd-types" class="tab-panel">
      <div class="content-block"><h2>CAPD vs APD</h2>${topicBlock('pd-capd-vs-apd')}</div>
    </div>
    <div id="pd-catheter" class="tab-panel">
      <div class="content-block"><h2>The PD Catheter</h2>${topicBlock('pd-catheter')}</div>
      <div class="content-block"><h2>Exit Site Care</h2>${topicBlock('pd-exit-site-care')}</div>
    </div>
    <div id="pd-exchange" class="tab-panel">
      <div class="content-block"><h2>How to Do a PD Exchange</h2>${topicBlock('pd-exchange-process')}</div>
    </div>
    <div id="pd-complications" class="tab-panel">
      <div class="content-block"><h2>Recognising Peritonitis</h2>${topicBlock('pd-peritonitis-awareness')}</div>
    </div>
    <div id="pd-travel" class="tab-panel">
      <div class="content-block"><h2>Travelling on PD</h2>${topicBlock('pd-travelling')}</div>
    </div>
    <div id="pd-caregiver" class="tab-panel">
      <div class="content-block"><h2>Information for Caregivers</h2>${topicBlock('pd-caregiver')}</div>
    </div>`;
  },

  // ── NUTRITION & MEAL PLANNING (live — powered by knowledgeBase.js) ────────
  nutrition: () => `
    <div class="view-header">
      <span class="view-badge" style="background:#f0fdf4;color:#16a34a;border:1px solid #bbf7d0;">🥗 Nutrition & Meal Planning</span>
      <h1>Kidney-Friendly Nutrition</h1>
      <p class="view-subtitle">Culturally tailored meal guidance for dialysis patients. General education only — individual limits set by your renal dietitian.</p>
    </div>

    <div class="notice notice-info">
      <span class="notice-icon">👩‍⚕️</span>
      <div class="notice-body"><strong>Dietitian Review Required</strong>
        All meal plans and food guides are for general education only. Your individual potassium, phosphorus, sodium, fluid, and protein limits must be set by your renal dietitian.</div>
    </div>

    <div class="tabs" role="tablist" aria-label="Nutrition topics">
      <button class="tab-btn active" role="tab" aria-selected="true" data-tab="nut-foods">Food Guide</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="nut-nutrients">Key Nutrients</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="nut-cultural">Cultural Tips</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="nut-cooking">Cooking Tips</button>
      <button class="tab-btn" role="tab" aria-selected="false" data-tab="nut-mealplan">3-Day Meal Plan</button>
    </div>

    <div id="nut-foods" class="tab-panel active">
      <div class="content-block">
        <h2>Food Traffic-Light Guide</h2>
        ${typeof NutritionGuide !== 'undefined' ? NutritionGuide.buildTrafficLightSummaryHTML() : ''}
        <h3 style="margin-top:1.5rem;">Search a Food</h3>
        <div class="food-search-row">
          <input type="text" class="food-search-input" id="food-search-input" placeholder="e.g. banana, potato, chicken…" aria-label="Search for a food" />
          <button class="food-search-btn" id="food-search-btn">Search</button>
        </div>
        <div id="food-results"></div>
      </div>
    </div>

    <div id="nut-nutrients" class="tab-panel">
      <div class="content-block">
        <h2>Key Nutrients in the Dialysis Diet</h2>
        <div class="tabs" role="tablist" style="margin-bottom:1.5rem;">
          <button class="tab-btn active" data-nutrient-tab="potassium">Potassium</button>
          <button class="tab-btn" data-nutrient-tab="phosphorus">Phosphorus</button>
          <button class="tab-btn" data-nutrient-tab="sodium">Sodium</button>
          <button class="tab-btn" data-nutrient-tab="fluid">Fluid</button>
          <button class="tab-btn" data-nutrient-tab="protein">Protein</button>
        </div>
        <div id="nutrient-detail">
          ${typeof NutritionGuide !== 'undefined' ? NutritionGuide.buildNutrientHTML('potassium') : ''}
        </div>
      </div>
    </div>

    <div id="nut-cultural" class="tab-panel">
      <div class="content-block">
        <h2>Cultural Food Tips</h2>
        <p class="text-muted" style="margin-bottom:1rem;">Select your cultural background to see kidney-friendly swaps for familiar foods.</p>
        <div class="culture-selector" id="culture-selector-nut" role="group" aria-label="Select cultural background">
          <button class="culture-btn selected" data-culture="general">🌍 General</button>
          <button class="culture-btn" data-culture="south-asian">🇮🇳 South Asian</button>
          <button class="culture-btn" data-culture="east-asian">🥢 East Asian</button>
          <button class="culture-btn" data-culture="west-african">🌍 West African</button>
          <button class="culture-btn" data-culture="caribbean">🌴 Caribbean</button>
          <button class="culture-btn" data-culture="latin-american">🌮 Latin American</button>
          <button class="culture-btn" data-culture="middle-eastern">🫓 Middle Eastern</button>
          <button class="culture-btn" data-culture="east-african">☕ East African</button>
          <button class="culture-btn" data-culture="european">🥖 European</button>
        </div>
        <div id="cultural-tips-output" style="margin-top:1.5rem;">
          ${typeof NutritionGuide !== 'undefined' ? NutritionGuide.buildCulturalHTML('general') : ''}
        </div>
      </div>
    </div>

    <div id="nut-cooking" class="tab-panel">
      <div class="content-block">
        <h2>Kidney-Friendly Cooking Tips</h2>
        ${typeof NutritionGuide !== 'undefined' ? NutritionGuide.buildCookingTipsHTML() : ''}
      </div>
    </div>

    <div id="nut-mealplan" class="tab-panel">
      <div class="content-block">
        <h2>3-Day Sample Meal Plan</h2>
        <div class="plan-selector-row">
          <div>
            <label for="plan-culture">Cultural Background:</label>
            <select class="plan-select" id="plan-culture">
              <option value="general">General / International</option>
              <option value="south-asian">South Asian</option>
              <option value="east-asian">East Asian</option>
              <option value="west-african">West African</option>
              <option value="caribbean">Caribbean</option>
              <option value="latin-american">Latin American</option>
              <option value="middle-eastern">Middle Eastern</option>
              <option value="east-african">East African</option>
              <option value="european">European</option>
            </select>
          </div>
          <div>
            <label for="plan-type">Dialysis Type:</label>
            <select class="plan-select" id="plan-type">
              <option value="hd">Hemodialysis (HD)</option>
              <option value="pd">Peritoneal Dialysis (PD)</option>
            </select>
          </div>
          <button class="btn-primary" id="btn-generate-plan">Show Meal Plan</button>
        </div>
        <div id="meal-plan-output">
          ${typeof MealPlanner !== 'undefined' ? MealPlanner.buildPlanHTML('general', 'hd') : ''}
        </div>
      </div>
    </div>
  `,

  // ── SAFETY REVIEW PROCESS (LIVE — powered by safetyGuard.js) ─────────────
  safety: () => {
    var stats = (typeof SafetyGuard !== 'undefined') ? SafetyGuard.getQueueStats() : { pending: 0, reviewed: 0, referred: 0, total: 0 };
    return `
    <div class="view-header">
      <span class="view-badge" style="background:#fef2f2;color:#dc2626;border:1px solid #fecaca;">
        🛡️ Patient Safety
      </span>
      <h1>Safety Review Process</h1>
      <p class="view-subtitle">
        Live review queue for flagged questions. High-risk and emergency questions are never
        answered automatically — a qualified clinician must act on each item.
      </p>
    </div>

    <div class="notice notice-danger">
      <span class="notice-icon">🚨</span>
      <div class="notice-body">
        <strong>Policy:</strong>
        Emergency questions → 911 guidance shown immediately.
        High-risk questions → general safety guidance + care-team referral + added to this queue.
        No individualised medical instructions are ever given by the AI.
        No patient data is stored.
      </div>
    </div>

    <div class="content-block">
      <h2>Four-Tier Safety Model</h2>
      <ul style="margin-top:0.5rem;">
        <li>🚨 <strong>Emergency</strong> — 911/emergency services shown immediately. Flagged for review.</li>
        <li>⚠️ <strong>High-Risk</strong> — General safety guidance + nephrologist referral. Flagged for review.</li>
        <li>⚠️ <strong>Caution</strong> — Educational answer with prominent warning + care-team referral.</li>
        <li>✅ <strong>Safe</strong> — Full educational answer with standard disclaimer.</li>
      </ul>
    </div>

    <div class="safety-review-panel">
      <h2>🛡️ Live Review Queue</h2>
      <p class="text-muted" style="margin-bottom:1.5rem;">
        Items below are real flags generated when you test the chat. No patient data is stored —
        only a sanitised topic label, risk level, and timestamp.
      </p>

      <div class="queue-stat-grid">
        <div class="queue-stat-card stat-pending">
          <div class="queue-stat-number" id="stat-pending">${stats.pending}</div>
          <div class="queue-stat-label">⏳ Pending Review</div>
        </div>
        <div class="queue-stat-card stat-reviewed">
          <div class="queue-stat-number" id="stat-reviewed">${stats.reviewed}</div>
          <div class="queue-stat-label">✓ Reviewed</div>
        </div>
        <div class="queue-stat-card stat-referred">
          <div class="queue-stat-number" id="stat-referred">${stats.referred}</div>
          <div class="queue-stat-label">🚫 Referred to Care Team</div>
        </div>
      </div>

      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:0.75rem;">
        <h3>Flagged Items</h3>
        <div style="display:flex;gap:0.5rem;">
          <button class="btn-outline" style="font-size:0.8rem;padding:5px 12px;" id="btn-refresh-queue">↻ Refresh</button>
          <button class="btn-outline" style="font-size:0.8rem;padding:5px 12px;color:var(--color-danger);border-color:var(--color-danger);" id="btn-clear-resolved">Clear Resolved</button>
        </div>
      </div>

      <ul class="live-review-queue" id="live-review-queue">
        <!-- Rendered by renderReviewQueue() -->
      </ul>
    </div>
  `},

  // ── EDUCATIONAL LIBRARY (static, browsable without AI) ───────────────────
  library: function() {

    function topicCard(id, icon) {
      var t = (typeof KnowledgeBase !== 'undefined' && KnowledgeBase.isLoaded()) ? KnowledgeBase.getTopic(id) : null;
      if (!t) return '';
      var pts = (t.key_points || []).slice(0, 3).map(function(p){
        return '<li>' + escapeHtml(p) + '</li>';
      }).join('');
      return '<div class="lib-card">' +
        '<div class="lib-card-icon">' + (icon || '📄') + '</div>' +
        '<div class="lib-card-body">' +
        '<h3 class="lib-card-title">' + escapeHtml(t.title) + '</h3>' +
        '<p class="lib-card-desc">' + escapeHtml(t.content.substring(0, 160)) + (t.content.length > 160 ? '…' : '') + '</p>' +
        (pts ? '<ul class="lib-card-points">' + pts + '</ul>' : '') +
        (t.disclaimer ? '<div class="lib-card-note">⚕️ ' + escapeHtml(t.disclaimer) + '</div>' : '') +
        '</div>' +
        '</div>';
    }

    return `
    <div class="view-header">
      <span class="view-badge" style="background:#fffbeb;color:#b45309;border:1px solid #fde68a;">📚 Educational Library</span>
      <h1>Dialysis Education Library</h1>
      <p class="view-subtitle">Browse all educational articles about hemodialysis, peritoneal dialysis,
        and kidney-friendly nutrition. No login required — content is always available.</p>
    </div>

    <div class="notice notice-danger">
      <span class="notice-icon">🚨</span>
      <div class="notice-body"><strong>Emergency?</strong> Call 911 / 999 / 112 immediately. This library is for education only — not for emergencies.</div>
    </div>

    <div class="notice notice-info">
      <span class="notice-icon">ℹ️</span>
      <div class="notice-body"><strong>Educational Content Only.</strong>
        All articles are general education based on National Kidney Foundation, NIDDK, and KDIGO guidelines.
        They do not replace advice from your nephrologist, dialysis nurse, or renal dietitian.</div>
    </div>

    <div class="lib-section">
      <h2 class="lib-section-title">💉 Hemodialysis</h2>
      <div class="lib-grid">
        ${topicCard('hd-what-is', '💉')}
        ${topicCard('hd-access-fistula', '🩺')}
        ${topicCard('hd-access-graft', '🩺')}
        ${topicCard('hd-access-catheter', '🩺')}
        ${topicCard('hd-what-to-expect', '🏥')}
        ${topicCard('hd-fluid-management', '💧')}
        ${topicCard('hd-common-side-effects', '⚠️')}
        ${topicCard('hd-home-dialysis', '🏠')}
        ${topicCard('hd-caregiver', '🤝')}
      </div>
    </div>

    <div class="lib-section">
      <h2 class="lib-section-title">🫁 Peritoneal Dialysis</h2>
      <div class="lib-grid">
        ${topicCard('pd-what-is', '🫁')}
        ${topicCard('pd-capd-vs-apd', '⚙️')}
        ${topicCard('pd-catheter', '🩺')}
        ${topicCard('pd-exit-site-care', '🧼')}
        ${topicCard('pd-exchange-process', '🔄')}
        ${topicCard('pd-peritonitis-awareness', '🚨')}
        ${topicCard('pd-travelling', '✈️')}
        ${topicCard('pd-caregiver', '🤝')}
      </div>
    </div>

    <div class="lib-section">
      <h2 class="lib-section-title">🥗 Kidney-Friendly Nutrition</h2>
      <div class="lib-grid">
        ${(typeof NutritionGuide !== 'undefined') ? NutritionGuide.buildLibraryCards() : ''}
      </div>
    </div>

    <div class="notice notice-success" style="margin-top:2rem;">
      <span class="notice-icon">💬</span>
      <div class="notice-body"><strong>Have a question?</strong>
        Use the <strong>AI Assistant</strong> in the sidebar to ask questions about anything in this library.
        All responses are safety-screened before display.</div>
    </div>
    `;
  },

  // ── LAB RESULTS SCANNER ───────────────────────────────────────────────────
  labResults: () => `
    <div class="view-header">
      <span class="view-badge" style="background:#f0f9ff;color:#0369a1;border:1px solid #bae6fd;">
        🔬 Lab Results
      </span>
      <h1>Understand Your Lab Results</h1>
      <p class="view-subtitle">
        Enter your test results manually or attach a photo or PDF of your lab report.
        We'll explain what each test measures in plain language and help you prepare questions for your care team.
      </p>
    </div>

    <div class="notice notice-warning" id="lr-data-notice">
      <span class="notice-icon">🔒</span>
      <div class="notice-body">
        <strong>Your privacy — please read before uploading</strong>
        <ul style="margin:0.4rem 0 0;padding-left:1.3em;">
          <li>Attached images and PDFs are read <strong>only inside your browser</strong>. They are never sent to any server.</li>
          <li>If you choose to save results, they are stored in <strong>your browser's local storage only</strong> — on this device, not in a cloud.</li>
          <li>Results are <strong>not saved by default</strong>. You will be asked before anything is stored.</li>
          <li>To remove any saved data, use the <strong>Clear saved results</strong> button at the bottom of this page.</li>
        </ul>
      </div>
    </div>

    <div class="notice notice-danger">
      <span class="notice-icon">⚠️</span>
      <div class="notice-body">
        <strong>This is not a diagnostic tool.</strong>
        Explanations here are for education only. We will only compare your result against
        the <em>reference range printed on your own report</em> — never against a general
        population range presented as your personal target. Always discuss your results with
        your nephrologist or dialysis nurse.
      </div>
    </div>

    <!-- ── ENTRY TABS ── -->
    <div class="lr-tabs" id="lr-tabs" role="tablist" aria-label="Entry method">
      <button class="lr-tab active" role="tab" aria-selected="true"  aria-controls="lr-panel-manual"  id="lr-tab-manual"  data-lr-tab="manual">✏️ Enter manually</button>
      <button class="lr-tab"        role="tab" aria-selected="false" aria-controls="lr-panel-attach"  id="lr-tab-attach"  data-lr-tab="attach">📎 Attach a file</button>
      <button class="lr-tab"        role="tab" aria-selected="false" aria-controls="lr-panel-history" id="lr-tab-history" data-lr-tab="history">📋 Saved results</button>
    </div>

    <!-- ── PANEL: MANUAL ENTRY ── -->
    <div class="lr-panel active" id="lr-panel-manual" role="tabpanel" aria-labelledby="lr-tab-manual">

      <div class="lr-form-header">
        <div class="lr-form-row lr-form-row-2">
          <div class="lr-field">
            <label for="lr-report-date">Report date (optional)</label>
            <input type="date" id="lr-report-date" class="lr-input" />
          </div>
          <div class="lr-field">
            <label for="lr-report-lab">Lab or hospital name (optional)</label>
            <input type="text" id="lr-report-lab" class="lr-input" placeholder="e.g. City General Hospital" />
          </div>
        </div>
      </div>

      <div id="lr-rows-container">
        <!-- Result rows inserted here by JS -->
      </div>

      <div class="lr-add-row-bar">
        <button class="lr-btn-add-row" id="lr-btn-add-row">+ Add another test</button>
      </div>

      <div class="lr-action-bar">
        <button class="btn-primary" id="lr-btn-explain">Explain my results</button>
        <button class="btn-outline"  id="lr-btn-clear-form">Clear form</button>
      </div>
    </div>

    <!-- ── PANEL: FILE ATTACH ── -->
    <div class="lr-panel" id="lr-panel-attach" role="tabpanel" aria-labelledby="lr-tab-attach">
      <div class="lr-drop-zone" id="lr-drop-zone" tabindex="0" role="button" aria-label="Click or drag a file here">
        <span class="lr-drop-icon">📄</span>
        <p class="lr-drop-text"><strong>Click to choose a file</strong> or drag and drop it here</p>
        <p class="lr-drop-hint">Accepted: JPG, PNG, PDF — read inside your browser only, never uploaded</p>
        <input type="file" id="lr-file-input" accept="image/*,.pdf" class="lr-file-input-hidden" aria-hidden="true" />
      </div>
      <div id="lr-file-preview" class="lr-file-preview hidden"></div>
      <div class="notice notice-info" style="margin-top:1rem;">
        <span class="notice-icon">ℹ️</span>
        <div class="notice-body">
          <strong>After attaching your file</strong>, use the form below to enter the values you can read on the report.
          The file is shown only as a reference — your entries drive the explanation.
        </div>
      </div>
      <div id="lr-attach-form" class="lr-attach-form-area hidden">
        <div class="lr-form-header">
          <div class="lr-form-row lr-form-row-2">
            <div class="lr-field">
              <label for="lr-report-date-att">Report date (optional)</label>
              <input type="date" id="lr-report-date-att" class="lr-input" />
            </div>
            <div class="lr-field">
              <label for="lr-report-lab-att">Lab or hospital name (optional)</label>
              <input type="text" id="lr-report-lab-att" class="lr-input" placeholder="e.g. City General Hospital" />
            </div>
          </div>
        </div>
        <div id="lr-rows-container-att"></div>
        <div class="lr-add-row-bar">
          <button class="lr-btn-add-row" id="lr-btn-add-row-att">+ Add another test</button>
        </div>
        <div class="lr-action-bar">
          <button class="btn-primary" id="lr-btn-explain-att">Explain my results</button>
          <button class="btn-outline"  id="lr-btn-clear-form-att">Clear form</button>
        </div>
      </div>
    </div>

    <!-- ── PANEL: HISTORY ── -->
    <div class="lr-panel" id="lr-panel-history" role="tabpanel" aria-labelledby="lr-tab-history">
      <div id="lr-history-content">
        <!-- populated by JS -->
      </div>
    </div>

    <!-- ── EXPLANATION OUTPUT ── -->
    <div id="lr-explanation" class="hidden" aria-live="polite">
      <!-- populated by JS -->
    </div>
  `,

  // ── SCHEDULE & REMINDERS ──────────────────────────────────────────────────
  schedule: () => `
    <div class="view-header">
      <span class="view-badge" style="background:#f5f3ff;color:#7c3aed;border:1px solid #ddd6fe;">
        📅 Schedule &amp; Reminders
      </span>
      <h1>Schedule &amp; Reminders</h1>
      <p class="view-subtitle">
        Track your dialysis appointments, lab tests, and care tasks.
        Set reminders, and keep your clinic and transport contacts close to hand.
      </p>
    </div>

    <!-- ── NOTIFICATION NOTICE ── -->
    <div class="notice notice-info" id="sc-notification-notice">
      <span class="notice-icon">🔔</span>
      <div class="notice-body">
        <strong>How reminders work in this app</strong>
        Reminders only fire while this page is <strong>open in your browser</strong>.
        If you close the tab or put your phone to sleep, reminders will not arrive.
        To get reminders on a closed device, add this page to your home screen as a web app and keep it running,
        or set a reminder in your phone's built-in calendar app as a backup.
        <div style="margin-top:0.5rem;">
          <button class="btn-outline sc-btn-sm" id="sc-btn-request-notify">🔔 Enable browser notifications</button>
          <span id="sc-notify-status" class="sc-notify-status"></span>
        </div>
      </div>
    </div>

    <!-- ── TABS ── -->
    <div class="sc-tabs" role="tablist" aria-label="Schedule sections">
      <button class="sc-tab active" data-sc-tab="upcoming" role="tab" aria-selected="true"  aria-controls="sc-panel-upcoming">📋 Upcoming</button>
      <button class="sc-tab"        data-sc-tab="add"      role="tab" aria-selected="false" aria-controls="sc-panel-add">➕ Add event</button>
      <button class="sc-tab"        data-sc-tab="contacts" role="tab" aria-selected="false" aria-controls="sc-panel-contacts">📞 Contacts</button>
    </div>

    <!-- ── PANEL: UPCOMING ── -->
    <div class="sc-panel active" id="sc-panel-upcoming" role="tabpanel">
      <div id="sc-upcoming-list"><!-- populated by JS --></div>
    </div>

    <!-- ── PANEL: ADD EVENT ── -->
    <div class="sc-panel" id="sc-panel-add" role="tabpanel">

      <!-- Suggested task chips -->
      <div class="sc-suggestions-label">Quick-add a suggested event:</div>
      <div class="sc-suggestions" id="sc-suggestions">
        <button class="sc-chip" data-suggest="dialysis">💉 Dialysis appointment</button>
        <button class="sc-chip" data-suggest="lab">🔬 Lab blood test</button>
        <button class="sc-chip" data-suggest="access">🩺 Vein-access clinic</button>
        <button class="sc-chip" data-suggest="taxi">🚖 Arrange taxi</button>
        <button class="sc-chip" data-suggest="clean">🧼 Clean dialysis equipment</button>
        <button class="sc-chip" data-suggest="fluid">💧 Check fluid allowance log</button>
        <button class="sc-chip" data-suggest="medication">💊 Collect medications</button>
        <button class="sc-chip" data-suggest="dietitian">🥗 Dietitian appointment</button>
      </div>

      <form id="sc-event-form" class="sc-form" novalidate>
        <input type="hidden" id="sc-edit-id" value="" />

        <div class="sc-form-row sc-form-row-2">
          <div class="sc-field">
            <label for="sc-title">Event title <span class="sc-required">*</span></label>
            <input type="text" id="sc-title" class="sc-input" placeholder="e.g. Dialysis at City Hospital" required />
          </div>
          <div class="sc-field">
            <label for="sc-category">Category</label>
            <select id="sc-category" class="sc-input">
              <option value="dialysis">💉 Dialysis</option>
              <option value="lab">🔬 Lab / blood test</option>
              <option value="access">🩺 Access clinic</option>
              <option value="transport">🚖 Transport</option>
              <option value="medication">💊 Medication</option>
              <option value="nutrition">🥗 Nutrition / dietitian</option>
              <option value="equipment">🧼 Equipment / cleaning</option>
              <option value="other">📌 Other</option>
            </select>
          </div>
        </div>

        <div class="sc-form-row sc-form-row-3">
          <div class="sc-field">
            <label for="sc-date">Date <span class="sc-required">*</span></label>
            <input type="date" id="sc-date" class="sc-input" required />
          </div>
          <div class="sc-field">
            <label for="sc-time">Time (optional)</label>
            <input type="time" id="sc-time" class="sc-input" />
          </div>
          <div class="sc-field">
            <label for="sc-repeat">Repeat</label>
            <select id="sc-repeat" class="sc-input">
              <option value="none">No repeat</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="fortnightly">Every 2 weeks</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>
        </div>

        <div class="sc-form-row sc-form-row-2">
          <div class="sc-field">
            <label for="sc-reminder">Reminder</label>
            <select id="sc-reminder" class="sc-input">
              <option value="none">No reminder</option>
              <option value="5">5 minutes before</option>
              <option value="15">15 minutes before</option>
              <option value="30">30 minutes before</option>
              <option value="60">1 hour before</option>
              <option value="120">2 hours before</option>
              <option value="1440">1 day before</option>
            </select>
          </div>
          <div class="sc-field">
            <label for="sc-notes">Notes (optional)</label>
            <input type="text" id="sc-notes" class="sc-input" placeholder="e.g. Bring medication list" />
          </div>
        </div>

        <div class="sc-form-actions">
          <button type="submit" class="btn-primary" id="sc-btn-save">Save event</button>
          <button type="button" class="btn-outline"  id="sc-btn-cancel-edit" style="display:none;">Cancel edit</button>
          <button type="button" class="btn-outline"  id="sc-btn-clear-form">Clear</button>
        </div>
      </form>
    </div>

    <!-- ── PANEL: CONTACTS ── -->
    <div class="sc-panel" id="sc-panel-contacts" role="tabpanel">
      <p class="text-muted text-sm" style="margin-bottom:var(--space-md);">
        Save your clinic, dialysis unit, and transport contact details here for quick one-tap calling or texting.
        Tapping <strong>Call</strong> or <strong>Text</strong> will open your phone's dialler or messaging app — this app cannot make calls or send messages itself, and cannot confirm whether a call or ride was arranged.
      </p>

      <div id="sc-contacts-list"><!-- populated by JS --></div>

      <div class="sc-add-contact-form" id="sc-add-contact-form">
        <h3 class="sc-section-title">Add a contact</h3>
        <input type="hidden" id="sc-contact-edit-id" value="" />
        <div class="sc-form-row sc-form-row-3">
          <div class="sc-field">
            <label for="sc-contact-name">Name / label <span class="sc-required">*</span></label>
            <input type="text" id="sc-contact-name" class="sc-input" placeholder="e.g. Dialysis Unit" />
          </div>
          <div class="sc-field">
            <label for="sc-contact-phone">Phone number</label>
            <input type="tel" id="sc-contact-phone" class="sc-input" placeholder="e.g. 01234 567890" />
          </div>
          <div class="sc-field">
            <label for="sc-contact-type">Type</label>
            <select id="sc-contact-type" class="sc-input">
              <option value="clinic">🏥 Clinic / hospital</option>
              <option value="dialysis">💉 Dialysis unit</option>
              <option value="taxi">🚖 Taxi / transport</option>
              <option value="dietitian">🥗 Dietitian</option>
              <option value="pharmacy">💊 Pharmacy</option>
              <option value="other">📌 Other</option>
            </select>
          </div>
        </div>
        <div class="sc-form-actions">
          <button type="button" class="btn-primary" id="sc-btn-save-contact">Save contact</button>
          <button type="button" class="btn-outline"  id="sc-btn-cancel-contact" style="display:none;">Cancel edit</button>
        </div>
      </div>
    </div>

    <!-- ── CALL CONFIRM MODAL ── -->
    <div id="sc-call-modal" class="sc-modal-overlay" aria-hidden="true" role="dialog" aria-modal="true" aria-labelledby="sc-modal-title">
      <div class="sc-modal-box">
        <h3 id="sc-modal-title">Open phone app?</h3>
        <p id="sc-modal-body"></p>
        <p class="text-muted text-sm">This will open your phone's dialler or messaging app. This app cannot make the call or send the message for you, and cannot confirm that a call or ride was arranged.</p>
        <div class="sc-modal-actions">
          <a id="sc-modal-action-link" href="#" class="btn-primary" target="_blank" rel="noopener">Continue</a>
          <button class="btn-outline" id="sc-modal-cancel">Cancel</button>
        </div>
      </div>
    </div>
  `,

  // ── ASK ASSISTANT (Chat — SafetyGuard wired) ─────────────────────────────
  assistant: () => `
    <div class="view-header">
      <span class="view-badge" style="background:#f5f0ff;color:#7c5cd8;border:1px solid #ddd6fe;">
        💬 Ask the Assistant
      </span>
      <h1>DialysisCare Assistant</h1>
      <p class="view-subtitle">
        Ask general questions about dialysis and kidney-friendly living.
        All messages are screened by the safety guard before any response is shown.
      </p>
    </div>

    <div class="notice notice-info">
      <span class="notice-icon">🛡️</span>
      <div class="notice-body">
        <strong>Safety Guard Active.</strong>
        Every message is classified before a response is generated.
        Emergency questions → 911 guidance immediately.
        High-risk questions → safety guidance + care-team referral + flagged for clinician review.
        Safe questions → educational content from the knowledge base.
      </div>
    </div>

    <div class="chat-container">
      <div class="chat-messages" id="chat-messages" aria-live="polite" aria-label="Conversation">

        <div class="chat-bubble assistant">
          <div class="bubble-label">DialysisCare Assistant</div>
          Hello! I'm the DialysisCare Assistant. I can help you learn about hemodialysis,
          peritoneal dialysis, and kidney-friendly nutrition.<br><br>
          <strong>Please note:</strong> I provide general educational information only. I cannot
          diagnose conditions, prescribe medications, or replace your healthcare team's advice.
          Questions involving medications, symptoms, or lab values will always be referred to your
          care team, and flagged for qualified clinician review.
        </div>

        <div class="chat-bubble system-notice" role="status">
          🛡️ <strong>Safety Guard Active:</strong> All messages are screened before any response is shown.
          Try asking: <em>"What is hemodialysis?"</em> (safe) or <em>"I have chest pain"</em> (emergency) to see the safety system in action.
        </div>

      </div>

      <div class="chat-input-row">
        <textarea
          class="chat-input"
          id="chat-input"
          placeholder="Type your question about dialysis or kidney nutrition…"
          rows="1"
          aria-label="Type your question"
        ></textarea>
        <button class="chat-send-btn" id="chat-send" aria-label="Send message">
          Send
        </button>
      </div>

      <div class="chat-footer-note">
        ⚕️ This assistant does not diagnose conditions or prescribe medications.
        Always consult your nephrologist, dialysis nurse, or dietitian for personalised advice.
        No patient data is collected or stored.
      </div>
    </div>
  `
};

// ─────────────────────────────────────────────────────────────────────────────
// ROUTER — renders the correct view into #main-content
// ─────────────────────────────────────────────────────────────────────────────

let currentView = 'home';

function renderView(viewName) {
  const content = document.getElementById('main-content');
  const viewFn  = VIEWS[viewName];

  if (!viewFn) {
    console.warn(`View "${viewName}" not found.`);
    return;
  }

  // Render the view
  content.innerHTML = viewFn();
  currentView = viewName;

  // Sync sidebar active state
  document.querySelectorAll('.nav-item').forEach(btn => {
    const isActive = btn.dataset.view === viewName;
    btn.classList.toggle('active', isActive);
    btn.setAttribute('aria-current', isActive ? 'page' : 'false');
  });

  // Scroll to top
  content.scrollTo({ top: 0, behavior: 'smooth' });

  // Wire up in-view interactions after render
  initViewInteractions(viewName);

  // Close mobile nav drawer on navigation
  var headerNav = document.getElementById('header-nav');
  var mobileBtn = document.getElementById('btn-mobile-nav');
  if (headerNav) headerNav.classList.remove('open');
  if (mobileBtn) {
    mobileBtn.setAttribute('aria-expanded', 'false');
    mobileBtn.textContent = '☰';
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// VIEW-LEVEL INTERACTIONS (tabs, culture buttons — no medical logic)
// ─────────────────────────────────────────────────────────────────────────────

function initViewInteractions(viewName) {

  // ── TABS — scoped to each tablist so nested tab groups don't conflict ─────
  document.querySelectorAll('[role="tablist"]').forEach(function(tablist) {
    tablist.querySelectorAll('.tab-btn').forEach(function(btn) {
      btn.addEventListener('click', function() {
        var targetId = btn.dataset.tab || btn.dataset.nutrientTab;
        if (!targetId) return;

        // Deactivate only sibling tabs within this tablist
        tablist.querySelectorAll('.tab-btn').forEach(function(b) {
          b.classList.remove('active');
          b.setAttribute('aria-selected', 'false');
        });

        // Deactivate panels that belong to this tablist's buttons
        tablist.querySelectorAll('.tab-btn[data-tab]').forEach(function(b) {
          var p = document.getElementById(b.dataset.tab);
          if (p) p.classList.remove('active');
        });

        btn.classList.add('active');
        btn.setAttribute('aria-selected', 'true');
        var panel = document.getElementById(targetId);
        if (panel) panel.classList.add('active');
      });
    });
  });

  // ── HOME CARD NAV LINKS ───────────────────────────────────────────────────
  document.querySelectorAll('[data-nav]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var target = btn.dataset.nav;
      if (target) renderView(target);
    });
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// CHAT — Safety Guard wired. No knowledge base yet (Stage 3).
// ─────────────────────────────────────────────────────────────────────────────

function initChat() {
  var input    = document.getElementById('chat-input');
  var sendBtn  = document.getElementById('chat-send');
  var messages = document.getElementById('chat-messages');
  if (!input || !sendBtn || !messages) return;

  // ── CONVERSATION STATE ───────────────────────────────────────────────────
  // Tracks a pending follow-up turn so the next user message is interpreted
  // in context rather than as a fresh question.
  //
  // shape: null  |  {
  //   flow:    'meal' | 'exercise_questions',
  //   step:    string   (name of the question we just asked)
  //   data:    {}       (accumulated answers so far)
  // }
  var _pendingFollowUp = null;

  // ── DOM HELPERS ──────────────────────────────────────────────────────────

  function scrollToBottom() {
    messages.scrollTop = messages.scrollHeight;
  }

  function appendBubble(html, role) {
    var div = document.createElement('div');
    div.className = 'chat-bubble ' + role;
    div.innerHTML = html;
    messages.appendChild(div);
    scrollToBottom();
    return div;
  }

  function appendUserBubble(text) {
    appendBubble('<div class="bubble-label">You</div>' + escapeHtml(text), 'user');
  }

  function appendRiskBadge(riskLevel) {
    var badges = {
      emergency: '<span class="risk-badge risk-badge-emergency">🚨 Emergency</span>',
      high_risk: '<span class="risk-badge risk-badge-high">⚠️ High-Risk — Flagged for Review</span>',
      caution:   '<span class="risk-badge risk-badge-caution">⚠️ Caution</span>',
      safe:      '<span class="risk-badge risk-badge-safe">✅ Safe</span>'
    };
    return badges[riskLevel] || '';
  }

  // Show a brief animated typing indicator, then remove it and call cb().
  function withTypingDelay(cb, delay) {
    var indicator = appendBubble(
      '<div class="bubble-label">DialysisCare Assistant</div>' +
      '<div class="typing-indicator"><span></span><span></span><span></span></div>',
      'assistant'
    );
    setTimeout(function() {
      if (indicator.parentNode) indicator.parentNode.removeChild(indicator);
      cb();
    }, delay || 420);
  }

  // Append a row of suggested reply chips below the last assistant bubble.
  // replies = array of { label, text } or plain strings.
  // onPick(text) is called (and the row fades out) when one is clicked.
  function appendSuggestedReplies(replies, onPick) {
    var row = document.createElement('div');
    row.className = 'suggested-replies';
    replies.forEach(function(r) {
      var label = typeof r === 'string' ? r : r.label;
      var text  = typeof r === 'string' ? r : (r.text || r.label);
      var btn = document.createElement('button');
      btn.className = 'suggested-reply-btn';
      btn.textContent = label;
      btn.addEventListener('click', function() {
        row.classList.add('used');
        onPick(text);
      });
      row.appendChild(btn);
    });
    messages.appendChild(row);
    scrollToBottom();
    return row;
  }

  // Append a follow-up question bubble (purple tint, distinct from normal answer).
  function appendFollowUpBubble(html) {
    return appendBubble('<div class="follow-up-label">Follow-up question</div>' + html, 'follow-up');
  }

  // ── ANSWER ENGINE ────────────────────────────────────────────────────────
  // Analyses the user's question and returns focused educational HTML drawn
  // directly from the knowledge sources.  Only returns content that is
  // relevant to what was asked.  Falls back with a referral if nothing matches.
  //
  // FIX: food-lookup trigger tightened so "safe to exercise?" doesn't fire it.
  // Food lookup now requires at least one known food name in the query *or* an
  // explicit food-query phrase ("can I eat X", "is X ok", "X for dialysis").

  function generateAnswer(question) {
    var lower = question.toLowerCase();
    var kbReady = typeof KnowledgeBase !== 'undefined' && KnowledgeBase.isLoaded();
    var ngReady = typeof NutritionGuide !== 'undefined';

    // ── 1. SPECIFIC FOOD LOOKUP ─────────────────────────────────────────────
    // Requires: an explicit food-query phrase AND a food name we know about,
    // OR: the query contains a food name from our DB AND a food-context word.
    // This prevents "is it safe to exercise?" from triggering food lookup.
    if (kbReady && ngReady) {
      var allFoods = KnowledgeBase.findFoods('');
      var foodHits = allFoods.filter(function(f) {
        return lower.includes(f.name.toLowerCase());
      });
      var hasFoodQueryPhrase = /\b(can i eat|is .+ ok|safe to eat|eat .+\?|avoid .+|.+ for dialysis|.+ for kidney|.+ ok for dialysis)\b/i.test(question);
      var hasFoodContextWord = /\b(eat|food|diet|safe to eat|ok to eat|avoid)\b/i.test(lower);
      // Only enter food lookup if we actually found a food name in the query
      if (foodHits.length > 0 && (hasFoodQueryPhrase || hasFoodContextWord)) {
        var foodTable = NutritionGuide.lookupFood(foodHits[0].name);
        return '<p>Here is what I found about <strong>' + escapeHtml(foodHits[0].name) + '</strong> for dialysis patients:</p>' + foodTable +
          (foodHits.length > 1
            ? '<p style="margin-top:0.75rem;">I also found <strong>' + (foodHits.length - 1) + '</strong> other match(es). Use the <strong>Nutrition &amp; Meals</strong> food search for a full list.</p>'
            : '');
      }
    }

    // ── 1b. MEAL IDEA / MULTI-CONSTRAINT REQUEST ────────────────────────────
    var _mealRequestPhrases = [
      'meal idea', 'meal ideas', 'dinner idea', 'dinner ideas',
      'meal suggestion', 'meal suggestions', 'dinner suggestion',
      'meal for tonight', 'dinner for tonight', 'eat tonight', 'dinner tonight',
      'meal for dialysis', 'dialysis meal', 'dialysis-friendly meal', 'kidney-friendly meal',
      'kidney meal', 'meal for kidney', 'meal on dialysis',
      'suggest a meal', 'suggest a dinner', 'suggest something to eat',
      'give me a meal', 'give me one meal', 'give me a dinner',
      'what can i eat', 'what should i eat', 'what can i have for dinner',
      'what should i have for dinner', 'what can i make for dinner',
      'something to eat', 'something for dinner'
    ];
    var isMealRequest = _mealRequestPhrases.some(function(p) { return lower.includes(p); });

    var _hasNutrient = /\b(potassium|phosphorus|protein|sodium)\b/i.test(lower);
    var _hasLevel    = /\b(low|high|limit|reduce|less|more)\b/i.test(lower);
    var _hasMealWord = /\b(meal|dinner|eat|food|tonight|lunch|breakfast|snack)\b/i.test(lower);
    var isMealWithConstraints = _hasNutrient && _hasLevel && _hasMealWord;

    if (ngReady && (isMealRequest || isMealWithConstraints)) {
      var constraints = {};

      function _paired(level, nutrient) {
        var pat1 = new RegExp('\\b' + level + '\\b.{0,20}\\b' + nutrient + '\\b', 'i');
        var pat2 = new RegExp('\\b' + nutrient + '\\b.{0,20}\\b' + level + '\\b', 'i');
        return pat1.test(lower) || pat2.test(lower);
      }
      function _sharedModifier(level, nutrient) {
        var pat = new RegExp('\\b' + level + '\\b.{0,35}\\b' + nutrient + '\\b', 'i');
        return pat.test(lower);
      }

      if (_paired('low', 'potassium')   || _sharedModifier('low', 'potassium'))   constraints.potassium  = 'low';
      if (_paired('high', 'potassium')  || _sharedModifier('high', 'potassium'))  constraints.potassium  = 'high';
      if (_paired('low', 'phosphorus')  || _sharedModifier('low', 'phosphorus'))  constraints.phosphorus = 'low';
      if (_paired('high', 'phosphorus') || _sharedModifier('high', 'phosphorus')) constraints.phosphorus = 'high';
      if (_paired('low', 'protein')     || _sharedModifier('low', 'protein'))     constraints.protein    = 'low';
      if (_paired('high', 'protein')    || _sharedModifier('high', 'protein'))    constraints.protein    = 'high';

      var constraintLabels = [];
      if (constraints.potassium)  constraintLabels.push((constraints.potassium  === 'low'  ? 'low'  : 'high') + ' potassium');
      if (constraints.phosphorus) constraintLabels.push((constraints.phosphorus === 'low'  ? 'low'  : 'high') + ' phosphorus');
      if (constraints.protein)    constraintLabels.push((constraints.protein    === 'high' ? 'high' : 'low')  + ' protein');

      var preamble = constraintLabels.length
        ? '<p>Here is a dinner idea from the sample meal plans that fits your request (' +
          constraintLabels.map(function(l) { return '<strong>' + escapeHtml(l) + '</strong>'; }).join(', ') +
          '):</p>'
        : '<p>Here is a kidney-friendly dinner idea from the sample meal plans:</p>';

      return preamble + NutritionGuide.buildMealSuggestionHTML(constraints);
    }

    // ── 2. SPECIFIC NUTRIENT QUESTIONS ──────────────────────────────────────
    var nutrientMap = {
      potassium:  ['potassium', 'high potassium', 'low potassium', 'hyperkalemia'],
      phosphorus: ['phosphorus', 'phosphate', 'binder'],
      sodium:     ['sodium', 'salt', 'salty'],
      fluid:      ['fluid', 'fluid limit', 'fluid restriction', 'how much can i drink', 'thirst', 'water limit'],
      protein:    ['protein', 'muscle', 'muscle wasting', 'albumin']
    };
    var matchedNutrient = null;
    Object.keys(nutrientMap).forEach(function(n) {
      if (matchedNutrient) return;
      nutrientMap[n].forEach(function(kw) {
        if (!matchedNutrient && lower.includes(kw)) matchedNutrient = n;
      });
    });
    if (matchedNutrient && ngReady) {
      var nutrientHTML = NutritionGuide.buildNutrientHTML(matchedNutrient);
      if (kbReady) {
        var specificFoods = KnowledgeBase.findFoods('').filter(function(f) {
          return lower.includes(f.name.toLowerCase());
        });
        if (specificFoods.length > 0) {
          nutrientHTML += '<p style="margin-top:0.75rem;"><strong>Foods mentioned in your question:</strong></p>' +
            NutritionGuide.lookupFood(specificFoods[0].name);
        }
      }
      return nutrientHTML;
    }

    // ── 3. COOKING / MEAL PREPARATION QUESTIONS ─────────────────────────────
    var cookingTriggers = ['cook', 'cooking tip', 'leach', 'boil', 'prepare', 'recipe', 'meal prep', 'how to make'];
    var isCookingQ = cookingTriggers.some(function(w) { return lower.includes(w); });
    if (isCookingQ && ngReady) {
      return NutritionGuide.buildCookingTipsHTML();
    }

    // ── 4. CULTURAL DIET QUESTIONS ───────────────────────────────────────────
    var cultureMap = {
      'south-asian':    ['south asian', 'indian', 'pakistani', 'bangladeshi', 'curry', 'chapati', 'dal', 'lentil'],
      'east-asian':     ['east asian', 'chinese', 'japanese', 'korean', 'soy sauce', 'miso', 'tofu'],
      'west-african':   ['west african', 'nigerian', 'ghanaian', 'plantain', 'cassava', 'jollof'],
      'caribbean':      ['caribbean', 'jamaican', 'ackee', 'salt fish', 'callaloo'],
      'latin-american': ['latin', 'mexican', 'hispanic', 'tortilla', 'beans', 'guacamole', 'avocado'],
      'middle-eastern': ['middle eastern', 'arabic', 'hummus', 'tahini', 'lebanese', 'mediterranean'],
      'east-african':   ['east african', 'ethiopian', 'somali', 'injera', 'berbere'],
      'european':       ['european', 'british', 'irish', 'baked beans', 'roast potato', 'cheddar']
    };
    var matchedCulture = null;
    Object.keys(cultureMap).forEach(function(c) {
      if (matchedCulture) return;
      cultureMap[c].forEach(function(kw) {
        if (!matchedCulture && lower.includes(kw)) matchedCulture = c;
      });
    });
    if (matchedCulture && ngReady) {
      return '<p>Here are kidney-friendly tips for <strong>' + escapeHtml(matchedCulture.replace('-', ' ')) + '</strong> foods:</p>' +
        NutritionGuide.buildCulturalHTML(matchedCulture);
    }

    // ── 5. KNOWLEDGE BASE TOPIC MATCH (HD / PD topics) ──────────────────────
    // Only skip KB if the question is *purely* food/nutrition with no clinical topic words
    var _isFoodOnlyQuestion = /\b(meal|food|eat|diet|nutrition|potassium|phosphorus|protein|sodium|recipe)\b/i.test(lower) &&
      !/\b(exercise|transplant|medication|sleep|itch|restless|mental|depression|anxiety|blood test|kt|urr|creatinine|urea|access|fistula|catheter|graft|peritonitis|side effect|cramp|fatigue|tired|symptom|caregiver|carer|travel|holiday)\b/i.test(lower);
    if (kbReady && !_isFoodOnlyQuestion) {
      var matches = KnowledgeBase.search(question);
      if (matches.length > 0) {
        var topicCount = matches.length > 1 && _isVagueQuestion(lower) ? matches.length : 1;
        return matches.slice(0, topicCount).map(function(t) {
          return KnowledgeBase.buildTopicHTML(t);
        }).join('<hr style="margin:1rem 0;border:none;border-top:1px solid #e5e7eb;">');
      }
    }

    // ── 6. GENERAL DIET / FOOD OVERVIEW ─────────────────────────────────────
    var broadFoodWords = ['food', 'eat', 'diet', 'meal', 'nutrition'];
    var isBroadFoodQ = broadFoodWords.some(function(w) { return lower.includes(w); });
    if (isBroadFoodQ && ngReady) {
      return '<p>Here is a general overview of kidney-friendly food choices on dialysis. ' +
        'For a specific food, try searching by name in the <strong>Nutrition &amp; Meals</strong> section.</p>' +
        NutritionGuide.buildTrafficLightSummaryHTML();
    }

    // ── 7. VAGUE / VERY SHORT QUESTION ──────────────────────────────────────
    if (question.trim().split(/\s+/).length <= 3) {
      return '<p>Could you tell me a bit more about what you would like to know? For example:</p>' +
        '<ul>' +
        '<li>Are you asking about <strong>hemodialysis</strong> or <strong>peritoneal dialysis</strong>?</li>' +
        '<li>Are you asking about a specific <strong>food</strong>, <strong>nutrient</strong>, or <strong>symptom</strong>?</li>' +
        '<li>Are you looking for <strong>general information</strong> about how dialysis works?</li>' +
        '</ul>' +
        '<p>The more detail you give me, the more specific I can be with my answer.</p>';
    }

    // ── 8. NOT FOUND — honest fallback ───────────────────────────────────────
    return '<p>I wasn\'t able to find specific information about that in my knowledge sources.</p>' +
      '<p>For the most accurate answer, please speak with one of your healthcare professionals:</p>' +
      '<ul>' +
      '<li>Your <strong>nephrologist</strong> — for treatment and medical questions</li>' +
      '<li>Your <strong>dialysis nurse</strong> — for day-to-day dialysis care questions</li>' +
      '<li>Your <strong>renal dietitian</strong> — for nutrition, food, and fluid questions</li>' +
      '</ul>';
  }

  function _isVagueQuestion(lower) {
    // A question is vague if it is short OR uses a catch-all phrasing
    var vagueTerms = ['dialysis', 'kidney', 'general', 'tell me about', 'what should i know',
                      'information about', 'what can you tell me', 'explain', 'everything about'];
    var isShort = lower.split(/\s+/).length < 7;
    var hasVagueTerm = vagueTerms.some(function(t) { return lower.includes(t); });
    return hasVagueTerm && isShort;
  }

  // ── INTENT DETECTION ─────────────────────────────────────────────────────
  // Detect which interactive flow a fresh question should start, if any.

  function _detectMealIntent(lower) {
    var phrases = [
      'meal idea', 'meal ideas', 'dinner idea', 'dinner ideas',
      'meal suggestion', 'meal for tonight', 'dinner for tonight',
      'eat tonight', 'dinner tonight', 'dialysis meal', 'kidney meal',
      'kidney-friendly meal', 'dialysis-friendly meal',
      'suggest a meal', 'suggest a dinner', 'give me a meal',
      'what can i eat', 'what should i eat', 'what can i have',
      'something to eat', 'something for dinner', 'meal for dialysis',
      'meal on dialysis', 'meal for kidney'
    ];
    return phrases.some(function(p) { return lower.includes(p); });
  }

  function _detectExerciseIntent(lower) {
    return /\b(exercise|workout|gym|walk|swim|swimming|physical activity|sport|active|fitness)\b/i.test(lower) &&
      /\b(dialysis|kidney|can i|safe|advice|help|should i|is it ok)\b/i.test(lower);
  }

  // ── FOLLOW-UP FLOW HANDLERS ──────────────────────────────────────────────
  // Each handler receives the raw user text and the accumulated data object.
  // Returns true if it consumed the message (so handleSend won't re-process).

  function _handleMealFollowUp(text, data) {
    var lower = text.toLowerCase();

    // ── step 1: asked which dialysis type ───────────────────────────────────
    if (data.step === 'ask_dialysis_type') {
      if (/\b(hd|hemodialysis|haemo|hemo)\b/i.test(lower) || lower.includes('hd')) {
        data.dialysisType = 'hd';
      } else if (/\b(pd|peritoneal)\b/i.test(lower)) {
        data.dialysisType = 'pd';
      } else {
        // Unclear answer — nudge once more
        withTypingDelay(function() {
          appendFollowUpBubble('<p>Just to confirm — are you on <strong>hemodialysis (HD)</strong> or <strong>peritoneal dialysis (PD)</strong>?</p>');
          appendSuggestedReplies(['Hemodialysis (HD)', 'Peritoneal dialysis (PD)', 'Not sure'], function(picked) {
            _syntheticSend(picked);
          });
        });
        return true;
      }
      // Now ask meal vs snack
      data.step = 'ask_meal_or_snack';
      withTypingDelay(function() {
        appendFollowUpBubble('<p>Got it — <strong>' + escapeHtml(data.dialysisType.toUpperCase()) + '</strong>. Are you looking for a <strong>main meal</strong> (breakfast, lunch, or dinner) or a <strong>snack</strong> idea?</p>');
        appendSuggestedReplies(['Main meal', 'Snack', 'Either is fine'], function(picked) {
          _syntheticSend(picked);
        });
      });
      return true;
    }

    // ── step 2: asked meal or snack ─────────────────────────────────────────
    if (data.step === 'ask_meal_or_snack') {
      if (/\bsnack\b/i.test(lower)) {
        data.mealType = 'snack';
      } else {
        data.mealType = 'meal';
      }
      // Ask about constraints
      data.step = 'ask_constraints';
      withTypingDelay(function() {
        appendFollowUpBubble(
          '<p>Any specific nutrient preferences I should take into account? For example, do you need something <strong>low potassium</strong>, <strong>high protein</strong>, or <strong>low phosphorus</strong>?</p>' +
          '<p class="text-muted text-sm">You can say "no preference" if you just want a general kidney-friendly idea.</p>'
        );
        appendSuggestedReplies(
          ['Low potassium', 'High protein', 'Low phosphorus', 'Low potassium + high protein', 'No preference'],
          function(picked) { _syntheticSend(picked); }
        );
      });
      return true;
    }

    // ── step 3: asked about constraints → deliver final answer ──────────────
    if (data.step === 'ask_constraints') {
      var constraints = {};
      if (/\blow.{0,10}potassium\b/i.test(lower) || lower === 'low potassium')   constraints.potassium  = 'low';
      if (/\bhigh.{0,10}potassium\b/i.test(lower))                               constraints.potassium  = 'high';
      if (/\blow.{0,10}phosphorus\b/i.test(lower) || lower === 'low phosphorus') constraints.phosphorus = 'low';
      if (/\bhigh.{0,10}phosphorus\b/i.test(lower))                              constraints.phosphorus = 'high';
      if (/\bhigh.{0,10}protein\b/i.test(lower) || lower === 'high protein')     constraints.protein    = 'high';
      if (/\blow.{0,10}protein\b/i.test(lower))                                  constraints.protein    = 'low';
      // Combined shortcuts
      if (/low potassium.*high protein|high protein.*low potassium/i.test(lower)) {
        constraints.potassium = 'low'; constraints.protein = 'high';
      }

      _pendingFollowUp = null; // clear state before delivering

      var ngReady = typeof NutritionGuide !== 'undefined';
      var mealTypeLabel = data.mealType === 'snack' ? 'snack' : 'meal';
      var dtLabel = data.dialysisType ? data.dialysisType.toUpperCase() : 'dialysis';

      var labels = [];
      if (constraints.potassium)  labels.push((constraints.potassium === 'low' ? 'low' : 'high') + ' potassium');
      if (constraints.phosphorus) labels.push((constraints.phosphorus === 'low' ? 'low' : 'high') + ' phosphorus');
      if (constraints.protein)    labels.push((constraints.protein === 'high' ? 'high' : 'low') + ' protein');

      var preamble = '<p>Here is a kidney-friendly <strong>' + escapeHtml(mealTypeLabel) +
        ' idea</strong> for a patient on <strong>' + escapeHtml(dtLabel) + '</strong>';
      if (labels.length) {
        preamble += ', tailored for ' + labels.map(function(l) { return '<strong>' + escapeHtml(l) + '</strong>'; }).join(', ');
      }
      preamble += ':</p>';

      var answerHTML = ngReady
        ? (preamble + NutritionGuide.buildMealSuggestionHTML(constraints))
        : (preamble + '<p>Meal plan data is not currently loaded. Please visit the <strong>Nutrition &amp; Meals</strong> section to browse full meal plans.</p>');

      withTypingDelay(function() {
        var riskLevel = 'safe';
        var result    = SafetyGuard.buildResponse(riskLevel, 'meal idea');
        var html = result.html.replace('{{EDUCATIONAL_CONTENT}}', answerHTML);
        appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' + html, 'assistant');
        _appendContextualReplies('meal');
      }, 500);
      return true;
    }

    return false;
  }

  function _handleExerciseFollowUp(text, data) {
    var lower = text.toLowerCase();

    // ── step 1: offered to build care-team questions; user said yes/no ───────
    if (data.step === 'ask_build_questions') {
      _pendingFollowUp = null;

      if (/\b(yes|sure|ok|okay|please|yeah|yep|go ahead|build|show)\b/i.test(lower)) {
        withTypingDelay(function() {
          var html = _buildExerciseQuestionsHTML();
          var result = SafetyGuard.buildResponse('safe', 'exercise questions');
          appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' +
            result.html.replace('{{EDUCATIONAL_CONTENT}}', html), 'assistant');
          _appendContextualReplies('exercise');
        });
      } else {
        withTypingDelay(function() {
          appendBubble(
            '<div class="bubble-label">DialysisCare Assistant</div>' +
            '<p>No problem. Whenever you are ready to talk to your care team about exercise, I can help you prepare. ' +
            'Is there anything else I can help you with?</p>',
            'assistant'
          );
          _appendContextualReplies('general');
        });
      }
      return true;
    }

    return false;
  }

  // Build a printable list of questions to bring to the care team about exercise.
  function _buildExerciseQuestionsHTML() {
    return '<p>Here are some questions you can bring to your <strong>nephrologist or dialysis nurse</strong> ' +
      'at your next appointment:</p>' +
      '<div class="notice notice-info" style="margin-bottom:1rem;">' +
      '<span class="notice-icon">🏃</span>' +
      '<div class="notice-body">' +
      '<strong>Questions to Ask Your Care Team About Exercise</strong>' +
      '<ol style="margin-top:0.5rem;padding-left:1.3em;">' +
      '<li>Is it safe for me to exercise given my current health and dialysis schedule?</li>' +
      '<li>What types of exercise are most suitable for me (walking, stretching, swimming)?</li>' +
      '<li>Are there any exercises I should avoid — especially around my access site?</li>' +
      '<li>Is there a target heart rate or intensity level I should stay within?</li>' +
      '<li>Should I exercise before or after my dialysis sessions?</li>' +
      '<li>How long and how often should I aim to exercise each week?</li>' +
      '<li>What warning signs should make me stop exercising and seek advice?</li>' +
      '<li>Would a referral to a physiotherapist or renal rehabilitation programme help me?</li>' +
      '</ol>' +
      '</div></div>' +
      '<p class="text-muted text-sm">You can write these down or show this screen to your healthcare professional.</p>';
  }

  // ── CONTEXTUAL SUGGESTED REPLIES ────────────────────────────────────────
  // Shown after a complete answer to keep the conversation going.

  function _appendContextualReplies(context) {
    var replies;
    if (context === 'meal') {
      replies = [
        { label: '🍽️ Another meal idea',    text: 'Give me another meal idea' },
        { label: '🏃 Exercise questions',    text: 'Can I exercise on dialysis?' },
        { label: '❓ Ask something else',    text: '' }
      ];
    } else if (context === 'exercise') {
      replies = [
        { label: '🍽️ Meal idea',            text: 'Give me a meal idea' },
        { label: '💊 About my dialysis',     text: 'Tell me about hemodialysis' },
        { label: '❓ Ask something else',    text: '' }
      ];
    } else if (context === 'food') {
      replies = [
        { label: '🍽️ Meal idea',            text: 'Give me a meal idea' },
        { label: '🧂 About potassium',       text: 'What is potassium?' },
        { label: '❓ Ask something else',    text: '' }
      ];
    } else if (context === 'topic') {
      replies = [
        { label: '🍽️ Meal idea',            text: 'Give me a meal idea' },
        { label: '🏃 Exercise questions',    text: 'Can I exercise on dialysis?' },
        { label: '❓ Ask something else',    text: '' }
      ];
    } else {
      replies = [
        { label: '🍽️ Meal idea',            text: 'Give me a meal idea' },
        { label: '🏃 Exercise questions',    text: 'Can I exercise on dialysis?' },
        { label: '❓ Ask something else',    text: '' }
      ];
    }

    appendSuggestedReplies(replies, function(text) {
      if (!text) {
        // "Ask something else" — just focus the input
        input.focus();
        return;
      }
      _syntheticSend(text);
    });
  }

  // ── SYNTHETIC SEND ───────────────────────────────────────────────────────
  // Used by suggested reply buttons to inject a message as if the user typed it.

  function _syntheticSend(text) {
    input.value = text;
    handleSend();
  }

  // ── MAIN SEND HANDLER ────────────────────────────────────────────────────

  function handleSend() {
    var text = input.value.trim();
    if (!text) return;

    appendUserBubble(text);
    input.value = '';
    input.style.height = 'auto';
    sendBtn.disabled = true;

    if (typeof SafetyGuard === 'undefined') {
      appendBubble('<em>Safety guard not loaded. Please refresh the page.</em>', 'assistant');
      sendBtn.disabled = false;
      return;
    }

    // ── Follow-up flow: consume the message in context ───────────────────
    if (_pendingFollowUp) {
      var consumed = false;
      var flow = _pendingFollowUp.flow;
      var data = _pendingFollowUp.data;
      if (flow === 'meal') {
        consumed = _handleMealFollowUp(text, data);
      } else if (flow === 'exercise_questions') {
        consumed = _handleExerciseFollowUp(text, data);
      }
      if (consumed) {
        sendBtn.disabled = false;
        input.focus();
        return;
      }
      // If the user said something unrelated, clear the pending flow and
      // fall through to normal processing below.
      _pendingFollowUp = null;
    }

    // ── Safety classification ─────────────────────────────────────────────
    var riskLevel = SafetyGuard.classify(text);
    var result    = SafetyGuard.buildResponse(riskLevel, text);
    var lower     = text.toLowerCase();

    // Short delay so the response feels natural
    setTimeout(function() {
      var badge = appendRiskBadge(riskLevel);
      var html  = badge ? '<div style="margin-bottom:8px;">' + badge + '</div>' : '';

      if (riskLevel === 'safe' || riskLevel === 'caution') {

        // ── EXERCISE INTENT — interactive flow ───────────────────────────
        if (_detectExerciseIntent(lower)) {
          // Explain the limitation, then offer to build questions.
          var exerciseIntroHTML =
            '<p>Exercise on dialysis can be really beneficial — it can improve energy, ' +
            'strength, mood, and even your dialysis adequacy. However, the right type, ' +
            'intensity, and timing are <strong>highly individual</strong> and depend on ' +
            'your current health, your access site, and your dialysis schedule.</p>' +
            '<div class="notice notice-warning" style="margin-top:0.75rem;">' +
            '<span class="notice-icon">⚠️</span>' +
            '<div class="notice-body"><strong>Personalised exercise guidance needs sign-off from your care team</strong><br>' +
            'Your nephrologist or dialysis nurse needs to assess whether a specific exercise ' +
            'routine is safe for <em>you</em> before you start. This assistant cannot replace that assessment.</div>' +
            '</div>' +
            '<p style="margin-top:0.75rem;">What I <em>can</em> do is help you prepare a list of questions to bring to your ' +
            'next appointment. Would that be helpful?</p>';

          html += result.html.replace('{{EDUCATIONAL_CONTENT}}', exerciseIntroHTML);
          appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' + html, 'assistant');

          // Set up follow-up state and show YES/NO chips
          _pendingFollowUp = { flow: 'exercise_questions', step: 'ask_build_questions', data: {} };
          appendSuggestedReplies(
            ['Yes, build my questions list', 'No thanks'],
            function(picked) { _syntheticSend(picked); }
          );
          sendBtn.disabled = false;
          input.focus();
          return;
        }

        // ── MEAL INTENT — interactive follow-up flow ─────────────────────
        // Only start the interactive flow when the question does NOT already
        // carry enough context (dialysis type + constraints) to answer directly.
        var alreadyHasContext = (
          /\b(hd|hemodialysis|pd|peritoneal)\b/i.test(lower) ||
          /\b(low|high)\b.{0,20}\b(potassium|phosphorus|protein)\b/i.test(lower)
        );
        if (_detectMealIntent(lower) && !alreadyHasContext) {
          // Start by asking which dialysis type they are on.
          var mealIntroHTML = '<p>I\'d love to suggest a kidney-friendly meal idea! ' +
            'A couple of quick questions so I can tailor it to you.</p>';
          html += result.html.replace('{{EDUCATIONAL_CONTENT}}', mealIntroHTML);
          appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' + html, 'assistant');

          _pendingFollowUp = { flow: 'meal', step: 'ask_dialysis_type', data: {} };
          withTypingDelay(function() {
            appendFollowUpBubble('<p>First — are you on <strong>hemodialysis (HD)</strong> or <strong>peritoneal dialysis (PD)</strong>?</p>');
            appendSuggestedReplies(
              ['Hemodialysis (HD)', 'Peritoneal dialysis (PD)', 'Not sure'],
              function(picked) { _syntheticSend(picked); }
            );
          });
          sendBtn.disabled = false;
          input.focus();
          return;
        }

        // ── Standard answer ───────────────────────────────────────────────
        var educationalHTML = generateAnswer(text);
        // Don't show the ✅ Safe badge when the answer is the "not found" fallback —
        // the badge implies confident knowledge-base match, which isn't the case here.
        var isFallback = educationalHTML.indexOf("wasn\u2019t able to find") !== -1 ||
                         educationalHTML.indexOf("wasn't able to find") !== -1;
        var displayBadge = (riskLevel === 'safe' && isFallback) ? '' : badge;
        var displayHtml  = (displayBadge ? '<div style="margin-bottom:8px;">' + displayBadge + '</div>' : '') +
                           result.html.replace('{{EDUCATIONAL_CONTENT}}', educationalHTML);
        appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' + displayHtml, 'assistant');

        // Decide which contextual replies to show based on what was answered
        var context = 'general';
        var allFoodsCheck = (typeof KnowledgeBase !== 'undefined' && KnowledgeBase.isLoaded())
          ? KnowledgeBase.findFoods('').filter(function(f) { return lower.includes(f.name.toLowerCase()); })
          : [];
        if (allFoodsCheck.length > 0) {
          context = 'food';
        } else if (/\b(meal|food|eat|diet|recipe)\b/i.test(lower)) {
          context = 'meal';
        } else if (/\b(dialysis|hd|pd|fistula|catheter|exchange|access)\b/i.test(lower)) {
          context = 'topic';
        }
        _appendContextualReplies(context);

      } else {
        // emergency or high_risk
        html += result.html;
        appendBubble('<div class="bubble-label">DialysisCare Assistant</div>' + html, 'assistant');
      }

      if (result.requiresReview) {
        appendBubble(
          '🛡️ This question has been added to the <strong>Safety Review</strong> queue. ' +
          'A qualified clinician will review it. You can see the queue under <strong>Safety Review</strong> in the sidebar.',
          'system-notice'
        );
      }

      sendBtn.disabled = false;
      input.focus();
    }, 300);
  }

  sendBtn.addEventListener('click', handleSend);
  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  });

  // Auto-resize textarea
  input.addEventListener('input', function() {
    this.style.height = 'auto';
    this.style.height = Math.min(this.scrollHeight, 120) + 'px';
  });

  input.focus();
}

// ─────────────────────────────────────────────────────────────────────────────
// SAFETY REVIEW QUEUE DASHBOARD
// ─────────────────────────────────────────────────────────────────────────────

function renderReviewQueue() {
  var listEl = document.getElementById('live-review-queue');
  if (!listEl || typeof SafetyGuard === 'undefined') return;

  var queue = SafetyGuard.getQueue();
  var stats = SafetyGuard.getQueueStats();

  // Update stat numbers
  var pEl = document.getElementById('stat-pending');
  var rEl = document.getElementById('stat-reviewed');
  var rfEl = document.getElementById('stat-referred');
  if (pEl)  pEl.textContent  = stats.pending;
  if (rEl)  rEl.textContent  = stats.reviewed;
  if (rfEl) rfEl.textContent = stats.referred;

  if (queue.length === 0) {
    listEl.innerHTML = '<li class="queue-empty">No flagged items yet. Use the Assistant to test the safety system.</li>';
    return;
  }

  listEl.innerHTML = queue.map(function(item) {
    var riskLabel = {
      emergency: '🚨 Emergency',
      high_risk: '⚠️ High-Risk'
    }[item.riskLevel] || item.riskLevel;

    var statusBadge = {
      pending:  '<span class="review-status-badge badge-pending">⏳ Pending Review</span>',
      reviewed: '<span class="review-status-badge badge-approved">✓ Reviewed</span>',
      referred: '<span class="review-status-badge badge-flagged">🚫 Referred to Care Team</span>'
    }[item.status] || '';

    var date = new Date(item.timestamp).toLocaleString();
    var actions = item.status === 'pending' ? [
      '<button class="btn-resolve btn-resolve-approve" data-id="' + item.id + '" data-action="reviewed">✓ Mark Reviewed</button>',
      '<button class="btn-resolve btn-resolve-refer"   data-id="' + item.id + '" data-action="referred">🚫 Refer to Care Team</button>'
    ].join('') : (item.reviewedBy ? '<span class="text-xs text-muted">by ' + escapeHtml(item.reviewedBy) + '</span>' : '');

    return [
      '<li>',
      '  <div style="flex:1;">',
      '    <div><strong>' + escapeHtml(item.topic) + '</strong></div>',
      '    <div class="lrq-meta">',
      '      ' + riskLabel + ' · ' + date + ' · No patient data stored',
      '      ' + (item.reviewNote ? ' · <em>' + escapeHtml(item.reviewNote) + '</em>' : ''),
      '    </div>',
      '  </div>',
      '  <div class="lrq-actions">',
      '    ' + statusBadge,
      '    ' + actions,
      '  </div>',
      '</li>'
    ].join('\n');
  }).join('');

  // Wire resolve buttons
  listEl.querySelectorAll('.btn-resolve').forEach(function(btn) {
    btn.addEventListener('click', function() {
      var id     = btn.dataset.id;
      var action = btn.dataset.action;
      SafetyGuard.resolveItem(id, action, 'Clinician (prototype)', '');
      renderReviewQueue();
    });
  });
}

function initSafetyDashboard() {
  renderReviewQueue();
  var refreshBtn = document.getElementById('btn-refresh-queue');
  var clearBtn   = document.getElementById('btn-clear-resolved');
  if (refreshBtn) refreshBtn.addEventListener('click', renderReviewQueue);
  if (clearBtn)   clearBtn.addEventListener('click', function() {
    SafetyGuard.clearResolvedItems();
    renderReviewQueue();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY
// ─────────────────────────────────────────────────────────────────────────────

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

// ─────────────────────────────────────────────────────────────────────────────
// SIDEBAR NAVIGATION
// ─────────────────────────────────────────────────────────────────────────────

function initNavigation() {
  document.querySelectorAll('.nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      renderView(btn.dataset.view);
    });
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// DISCLAIMER MODAL
// ─────────────────────────────────────────────────────────────────────────────

function initDisclaimerModal() {
  const modal      = document.getElementById('modal-disclaimer');
  const btnOpen    = document.getElementById('btn-disclaimer');
  const btnClose   = document.getElementById('btn-close-disclaimer');

  function openModal() {
    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    btnClose.focus();
  }

  function closeModal() {
    modal.classList.remove('open');
    modal.setAttribute('aria-hidden', 'true');
    btnOpen.focus();
  }

  btnOpen.addEventListener('click', openModal);
  btnClose.addEventListener('click', closeModal);

  // Close on backdrop click
  modal.addEventListener('click', (e) => {
    if (e.target === modal) closeModal();
  });

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) closeModal();
  });

  // Show disclaimer automatically on first load
  openModal();
}

// ─────────────────────────────────────────────────────────────────────────────
// MOBILE NAVIGATION TOGGLE
// ─────────────────────────────────────────────────────────────────────────────

function initMobileNav() {
  const btn = document.getElementById('btn-mobile-nav');
  const nav = document.getElementById('header-nav');
  if (!btn || !nav) return;

  function close() {
    nav.classList.remove('open');
    btn.setAttribute('aria-expanded', 'false');
    btn.textContent = '☰';
  }

  btn.addEventListener('click', () => {
    const isOpen = nav.classList.toggle('open');
    btn.setAttribute('aria-expanded', String(isOpen));
    btn.textContent = isOpen ? '✕' : '☰';
  });

  // Auto-close when the user picks a nav item
  nav.querySelectorAll('.nav-item[data-view]').forEach(item => {
    item.addEventListener('click', close);
  });

  // Auto-close on click outside the header
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#site-header')) close();
  });
}

// ─────────────────────────────────────────────────────────────────────────────
// NUTRITION VIEW INTERACTIONS
// ─────────────────────────────────────────────────────────────────────────────

function initNutritionView() {

  // ── Food search ───────────────────────────────────────────────────────────
  var searchInput = document.getElementById('food-search-input');
  var searchBtn   = document.getElementById('food-search-btn');
  var resultsDiv  = document.getElementById('food-results');

  function doFoodSearch() {
    if (!searchInput || !resultsDiv) return;
    var q = searchInput.value.trim();
    if (!q) { resultsDiv.innerHTML = '<p class="text-muted text-sm">Enter a food name to search.</p>'; return; }
    resultsDiv.innerHTML = typeof NutritionGuide !== 'undefined'
      ? NutritionGuide.lookupFood(q)
      : '<p class="text-muted">Nutrition guide not loaded.</p>';
  }

  if (searchBtn) searchBtn.addEventListener('click', doFoodSearch);
  if (searchInput) searchInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') doFoodSearch();
  });

  // ── Nutrient tabs ─────────────────────────────────────────────────────────
  document.querySelectorAll('[data-nutrient-tab]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('[data-nutrient-tab]').forEach(function(b){ b.classList.remove('active'); });
      btn.classList.add('active');
      var detail = document.getElementById('nutrient-detail');
      if (detail && typeof NutritionGuide !== 'undefined') {
        detail.innerHTML = NutritionGuide.buildNutrientHTML(btn.dataset.nutrientTab);
      }
    });
  });

  // ── Cultural tips selector ─────────────────────────────────────────────────
  document.querySelectorAll('#culture-selector-nut .culture-btn').forEach(function(btn) {
    btn.addEventListener('click', function() {
      document.querySelectorAll('#culture-selector-nut .culture-btn').forEach(function(b){ b.classList.remove('selected'); });
      btn.classList.add('selected');
      var output = document.getElementById('cultural-tips-output');
      if (output && typeof NutritionGuide !== 'undefined') {
        output.innerHTML = NutritionGuide.buildCulturalHTML(btn.dataset.culture);
      }
    });
  });

  // ── Meal plan generator ───────────────────────────────────────────────────
  var genBtn = document.getElementById('btn-generate-plan');
  if (genBtn) {
    genBtn.addEventListener('click', function() {
      var culture = document.getElementById('plan-culture').value;
      var dtype   = document.getElementById('plan-type').value;
      var output  = document.getElementById('meal-plan-output');
      if (output && typeof MealPlanner !== 'undefined') {
        output.innerHTML = MealPlanner.buildPlanHTML(culture, dtype);
      }
    });
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// APP BOOTSTRAP
// ─────────────────────────────────────────────────────────────────────────────

// Hook into renderView to wire view-specific logic after each render
var _originalRenderView = renderView;
renderView = function(viewName) {
  _originalRenderView(viewName);
  if (viewName === 'assistant')  initChat();
  if (viewName === 'safety')     initSafetyDashboard();
  if (viewName === 'nutrition')  initNutritionView();
  if (viewName === 'labResults') { if (typeof LabResults  !== 'undefined') LabResults.init();  }
  if (viewName === 'schedule')   { if (typeof Schedule    !== 'undefined') Schedule.init();    }
};

function init() {
  initNavigation();
  initDisclaimerModal();
  initMobileNav();

  // Init SafetyGuard first, then KnowledgeBase, then render home
  if (typeof SafetyGuard !== 'undefined') {
    SafetyGuard.init(function() {
      if (typeof KnowledgeBase !== 'undefined') {
        KnowledgeBase.init(function(errors) {
          if (errors) console.warn('KnowledgeBase load warnings:', errors);
          renderView('home');
        });
      } else {
        renderView('home');
      }
    });
  } else {
    console.warn('SafetyGuard not found — rendering without safety layer.');
    renderView('home');
  }

  console.log(
    '%c DialysisCare AI Assistant — Stage 3 loaded ',
    'background:#16a34a;color:#fff;font-weight:bold;padding:4px 8px;border-radius:4px;'
  );
  console.log('Stage 3: Knowledge base, nutrition guide, and meal planner active.');
}

// Script loads at end of <body> so DOM is already ready — call directly.
init();
