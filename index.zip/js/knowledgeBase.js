/**
 * DialysisCare AI Assistant — js/knowledgeBase.js
 * =================================================
 * All educational data is embedded inline so the app works by
 * double-clicking index.html (file:// protocol — no server needed).
 *
 * Source references:
 *  - National Kidney Foundation (kidney.org)
 *  - NIDDK — National Institute of Diabetes and Digestive and Kidney Diseases
 *  - Kidney Disease: Improving Global Outcomes (KDIGO)
 *
 * Content is general education only. No individualised medical advice.
 * All responses are wrapped by safetyGuard.js before display.
 *
 * The JSON data files in /data/ remain as the canonical source-of-truth
 * backups. This file mirrors their content for offline/file:// use.
 */

var KnowledgeBase = (function () {

  // ─────────────────────────────────────────────────────────────────────────
  // INLINE DATA — mirrors data/*.json exactly
  // ─────────────────────────────────────────────────────────────────────────

  var _data = {

    // ── HEMODIALYSIS (source: data/hd-content.json) ───────────────────────
    hd: {
      topics: [
        {
          id: 'hd-what-is',
          title: 'What is Hemodialysis?',
          keywords: ['what is hemodialysis','what is hd','how does hemodialysis work','explain hemodialysis','hd explained'],
          tier: 'safe',
          content: 'Hemodialysis (HD) is a treatment that cleans your blood when your kidneys can no longer do this job well enough on their own. During HD, your blood is gently pumped out of your body through a special access site, passed through a filter called a dialyser (or artificial kidney), and then returned to your body — clean.',
          key_points: [
            'The dialyser removes waste products such as urea and creatinine, and excess fluid from your blood.',
            'Most people on HD have treatment 3 times per week, with each session lasting around 3–5 hours.',
            'HD can be done in a dialysis centre, a satellite unit, or at home (home haemodialysis).',
            'The dialyser does not do everything your kidneys did — it cannot make hormones or regulate all functions — so medications and diet remain important.'
          ],
          disclaimer: 'This is general educational information. Your treatment schedule, duration, and targets are set by your nephrologist based on your individual needs.'
        },
        {
          id: 'hd-access-fistula',
          title: 'Arteriovenous (AV) Fistula',
          keywords: ['fistula','av fistula','arteriovenous fistula','access fistula','fistula care','fistula buzzing','fistula thrill'],
          tier: 'safe',
          content: 'An AV fistula is created by a surgeon who joins an artery and a vein — usually in your forearm or upper arm. Over several weeks, the increased blood flow causes the vein to enlarge and strengthen, making it suitable for dialysis needles.',
          key_points: [
            'A fistula is considered the best long-term access because it has the lowest risk of infection and clotting.',
            "You should feel a 'buzz' or 'thrill' when you gently press your fistula — this means blood is flowing well.",
            'Check your fistula every day. Contact your dialysis team if you cannot feel the thrill, if the area is red, swollen, warm, or painful.',
            'Do not allow blood pressure measurements, needle injections, or tight clothing on your fistula arm.',
            "Keep the fistula site clean and dry. Follow your unit's specific dressing instructions."
          ],
          disclaimer: 'Contact your dialysis unit immediately if you notice any changes to your fistula. Do not attempt to treat access problems yourself.'
        },
        {
          id: 'hd-access-graft',
          title: 'AV Graft',
          keywords: ['graft','av graft','arteriovenous graft','access graft','graft care'],
          tier: 'safe',
          content: 'An AV graft uses a short piece of soft synthetic tubing to connect an artery and a vein under the skin. It can be used for dialysis sooner than a fistula — usually within 2–4 weeks of surgery.',
          key_points: [
            "Grafts are often used when a patient's veins are not suitable for a fistula.",
            'Like a fistula, you should feel a thrill when touching the graft area.',
            'Grafts have a slightly higher risk of clotting and infection than fistulas, so regular monitoring is important.',
            'Report any redness, warmth, swelling, or loss of thrill to your dialysis team right away.',
            'Do not allow blood pressure cuffs or needles on the graft arm.'
          ],
          disclaimer: 'Any changes to your graft should be reported to your dialysis unit promptly. Do not attempt home treatment of graft complications.'
        },
        {
          id: 'hd-access-catheter',
          title: 'Central Venous Catheter (CVC)',
          keywords: ['catheter','cvc','central line','tunnelled catheter','dialysis catheter','catheter care','catheter dressing'],
          tier: 'safe',
          content: 'A central venous catheter (CVC) is a flexible tube inserted into a large vein — usually in the neck, chest, or groin. It allows blood to flow in and out during dialysis without needing needles in the arm.',
          key_points: [
            'CVCs are often used when dialysis needs to start quickly, or while waiting for a fistula or graft to mature.',
            'CVCs carry a higher risk of infection than fistulas or grafts, so careful hygiene is very important.',
            'Never get the catheter exit site wet unless you have specific instructions from your care team to do so.',
            'The dressing over the catheter exit site must be kept clean, dry, and intact between dialysis sessions.',
            'Report any redness, discharge, fever, or chills to your dialysis team immediately — these can be signs of infection.'
          ],
          disclaimer: 'Catheter care instructions vary by unit and catheter type. Always follow the specific instructions given by your dialysis team.'
        },
        {
          id: 'hd-what-to-expect',
          title: 'What to Expect During a HD Session',
          keywords: ['what happens during dialysis','what to expect','dialysis session','during treatment','dialysis machine','how long does dialysis take'],
          tier: 'safe',
          content: 'Knowing what to expect can help reduce anxiety about starting or continuing hemodialysis. Here is a general overview of a typical in-centre HD session.',
          key_points: [
            'Before your session: your weight is measured (to check fluid gained since last treatment), blood pressure is taken, and your access site is assessed.',
            'Connection: two needles are placed in your fistula or graft (or your CVC is connected). One carries blood to the machine; the other returns cleaned blood to you.',
            'During treatment: you can read, watch TV, sleep, or talk. Some people feel a little cold — bring a light blanket.',
            'The machine monitors blood flow, pressure, and fluid removal continuously. Nurses are always present.',
            'After your session: needles are removed and the access site is pressed until bleeding stops. You are weighed again.',
            'Sessions usually last 3–5 hours, typically 3 times per week — but your schedule is set by your care team.'
          ],
          disclaimer: 'Your experience may differ. Ask your dialysis team any questions you have before, during, or after your treatment.'
        },
        {
          id: 'hd-fluid-management',
          title: 'Fluid Management Between Sessions',
          keywords: ['fluid','fluid limit','fluid restriction','how much can i drink','weight gain','interdialytic weight','thirst','dry weight'],
          tier: 'caution',
          content: 'Between dialysis sessions, fluid can build up in your body because your kidneys cannot remove it. Managing this is important for your heart and blood pressure.',
          key_points: [
            "Your 'dry weight' is the weight your dialysis team aims for you to reach by the end of each session — it is the weight without excess fluid.",
            'Most HD patients are advised to limit how much fluid they drink between sessions. The amount varies by individual.',
            'All fluids count — water, tea, coffee, soup, ice cream, jelly, gravy, and foods with high water content.',
            'Tips to manage thirst: use smaller cups, suck on ice chips, use chilled sugar-free lemon slices, rinse your mouth with cold water.',
            'Try to keep weight gain between sessions to the target your care team gives you — gaining too much fluid puts strain on your heart.'
          ],
          disclaimer: 'Your individual fluid allowance is set by your nephrologist and dialysis team based on your urine output, blood pressure, and heart health. Do not change your fluid limit without speaking to your care team.'
        },
        {
          id: 'hd-home-dialysis',
          title: 'Home Hemodialysis',
          keywords: ['home dialysis','home hd','home hemodialysis','dialysis at home','nocturnal dialysis'],
          tier: 'safe',
          content: 'Home hemodialysis (HHD) allows eligible patients to perform their dialysis treatment at home, often with the support of a trained caregiver.',
          key_points: [
            'HHD often allows more frequent or longer sessions, which can improve how you feel and your lab results.',
            'Training is provided by your dialysis unit — it typically takes several weeks.',
            'Home HD requires a dedicated space, a water supply modification, and storage for supplies.',
            'Not everyone is suitable for HHD — your care team will assess if it is right for you.',
            'Many people find HHD gives them more flexibility, less travel, and a greater sense of control.'
          ],
          disclaimer: 'Home HD is only suitable for some patients. Your eligibility and setup requirements will be determined by your dialysis team.'
        },
        {
          id: 'hd-caregiver',
          title: 'Information for Caregivers of HD Patients',
          keywords: ['caregiver','carer','supporting someone on dialysis','family member on dialysis','helping with dialysis'],
          tier: 'safe',
          content: 'Caring for someone on hemodialysis can be demanding but also deeply meaningful. Understanding what your loved one goes through helps you provide better support.',
          key_points: [
            'HD sessions take 3–5 hours, 3 times a week — your loved one may feel tired afterwards. Rest and a light meal can help.',
            'Help them track their fluid intake and daily weight if needed.',
            'Encourage diet adherence — eating kidney-friendly meals together makes it easier.',
            'Accompany them to clinic appointments when possible to hear information first-hand.',
            'Look after yourself too — carer fatigue is real. Ask the dialysis social worker about support services.',
            'If you notice your loved one seems unusually unwell, confused, or short of breath after a session, contact the dialysis unit.'
          ],
          disclaimer: 'Specific care instructions for your loved one come from their dialysis team. This is general guidance only.'
        },
        {
          id: 'hd-common-side-effects',
          title: 'Common Side Effects During HD',
          keywords: [
            'side effects','feeling unwell during dialysis','cramps during dialysis',
            'low blood pressure dialysis','headache dialysis','nausea dialysis',
            'cramps','muscle cramp','leg cramp','leg pain','leg is paining',
            'legs hurt','legs ache','legs are sore','pain after dialysis','pain during dialysis',
            'feel unwell','feeling sick after','feel sick after dialysis','nausea after dialysis',
            'headache after dialysis','dizzy after dialysis','fatigue after dialysis',
            'low blood pressure','hypotension','feel faint','lightheaded after dialysis',
            'itching after dialysis','itchy after dialysis','why do i feel bad after dialysis'
          ],
          tier: 'caution',
          content: 'Some side effects can occur during or shortly after a HD session. Knowing about them helps you communicate with your care team.',
          key_points: [
            'Low blood pressure (hypotension): a drop in blood pressure during dialysis can cause dizziness, nausea, or feeling faint. Tell the nurse immediately if you feel this way.',
            'Muscle cramps: often occur toward the end of a session or when too much fluid is removed too quickly. Inform your nurse.',
            'Headache and nausea: can occur, especially in newer patients or when large amounts of waste are cleared quickly.',
            'Fatigue: many patients feel tired after dialysis — this is common, especially in the first few months.',
            'Itching: caused by build-up of waste products or phosphorus. Your care team can advise on management.'
          ],
          disclaimer: 'If you experience any severe, sudden, or new symptoms during or after dialysis, tell your nurse or dialysis team immediately. Do not manage these symptoms on your own.'
        },
        {
          id: 'hd-exercise',
          title: 'Exercise and Physical Activity on Dialysis',
          keywords: ['exercise','exercise on dialysis','can i exercise','physical activity dialysis','gym dialysis','walking dialysis','fitness dialysis','is it safe to exercise','workout dialysis','swimming dialysis'],
          tier: 'safe',
          content: 'Regular gentle exercise is beneficial for most dialysis patients and is encouraged by kidney health organisations worldwide. Exercise can improve your energy, mood, heart health, and quality of life.',
          key_points: [
            'Low-impact activities are generally recommended: walking, cycling (stationary), swimming, yoga, and gentle stretching.',
            'Many dialysis centres offer exercise programmes during your treatment session — ask your team.',
            'Start slowly and build up gradually — even 10 minutes of walking per day is a great starting point.',
            'Avoid very vigorous exercise on the same day as dialysis, especially in the first few hours after treatment.',
            'If you have an AV fistula, avoid swimming until your care team confirms the access site is fully healed.',
            'Stop any activity and rest if you feel dizzy, chest pain, shortness of breath, or unusual tiredness.',
            'Tell your dialysis team about any exercise you do — they can offer personalised advice based on your condition.'
          ],
          disclaimer: 'Always speak to your nephrologist or dialysis nurse before starting a new exercise programme. Exercise recommendations vary based on your individual health status.'
        },
        {
          id: 'hd-itching',
          title: 'Itching (Uraemic Pruritus) on Dialysis',
          keywords: ['itching','itch','itchy','pruritus','uraemic itch','uremic itch','itchy skin dialysis','skin itch kidney','why do i itch'],
          tier: 'caution',
          content: 'Itching — also called uraemic pruritus — is very common in dialysis patients. It can be mild or severe and significantly affects quality of life. There are several causes and many management strategies.',
          key_points: [
            'Common causes include: build-up of waste products in the blood, elevated phosphorus levels, dry skin, and nerve changes.',
            'Keeping your phosphorus levels well-controlled (through diet and phosphate binders) can reduce itching.',
            'Use gentle, fragrance-free moisturisers — apply after bathing while your skin is still slightly damp.',
            'Avoid hot showers or baths, which can dry out skin further.',
            'Antihistamines may help some patients — ask your doctor before taking any.',
            'Newer medications (such as difelikefalin/Kapruvia) can be prescribed for moderate-to-severe itch — ask your nephrologist.',
            'Some patients find relief from UV phototherapy — ask your care team about referral to dermatology.'
          ],
          disclaimer: 'Persistent or severe itching should be discussed with your nephrologist or dialysis nurse. Do not stop any medication or start new treatments without medical guidance.'
        },
        {
          id: 'hd-restless-legs',
          title: 'Restless Legs Syndrome (RLS) on Dialysis',
          keywords: ['restless legs','restless leg','rlss','restless leg syndrome','legs moving at night','legs uncomfortable at night','crawling sensation legs','sleep dialysis legs'],
          tier: 'caution',
          content: 'Restless Legs Syndrome (RLS) causes uncomfortable sensations in the legs — often described as crawling, tingling, or an irresistible urge to move them, particularly at night. It is significantly more common in kidney failure patients than in the general population.',
          key_points: [
            'RLS is more common in dialysis patients and can seriously disrupt sleep and quality of life.',
            'Contributing factors may include anaemia (low iron or EPO), nerve damage, and high phosphorus.',
            'Longer or more frequent dialysis sessions sometimes help.',
            'Lifestyle measures: regular gentle exercise, avoiding caffeine and alcohol in the evening, and maintaining a consistent sleep schedule.',
            'Your doctor can assess your iron levels and anaemia treatment as a first step.',
            'Medications can be prescribed for more severe cases — discuss this with your nephrologist.'
          ],
          disclaimer: 'If restless legs are disrupting your sleep or quality of life, tell your nephrologist. Do not start any medication (including over-the-counter sleep aids) without medical advice.'
        },
        {
          id: 'hd-sleep',
          title: 'Sleep Problems on Dialysis',
          keywords: ['sleep','insomnia','trouble sleeping','cant sleep','can\'t sleep','sleep problems dialysis','poor sleep dialysis','tired after dialysis','fatigue dialysis'],
          tier: 'safe',
          content: 'Sleep disturbances are very common in dialysis patients. Poor sleep can affect energy, mood, and overall health. Understanding the common causes helps you work with your team to improve your sleep.',
          key_points: [
            'Common causes of poor sleep in dialysis patients include: restless legs syndrome, sleep apnoea, itching, leg cramps, anxiety, and the physical effects of treatment.',
            'Sleep apnoea is especially common in kidney failure — tell your team if you snore heavily or feel unrefreshed after sleep.',
            'Avoid caffeine in the afternoon and evening.',
            'Try to keep a regular sleep and wake schedule, even on dialysis days.',
            'Some patients sleep better on dialysis days if they avoid scheduling treatment late in the evening.',
            'Discuss sleep problems with your care team — there are effective treatments for many causes.'
          ],
          disclaimer: 'Speak to your doctor before taking any sleep medications, herbal remedies, or supplements — many interact with kidney disease or dialysis medications.'
        },
        {
          id: 'hd-mental-health',
          title: 'Mental Health and Emotional Wellbeing on Dialysis',
          keywords: ['mental health','depression','anxiety','low mood','stress dialysis','emotional wellbeing','feeling down','dialysis depression','dialysis anxiety','coping with dialysis','psychological'],
          tier: 'safe',
          content: 'Living with kidney failure and dialysis is demanding — not just physically, but emotionally. Depression and anxiety are significantly more common in dialysis patients than in the general population, and both are very treatable.',
          key_points: [
            'It is completely normal to feel frustrated, sad, or overwhelmed at times — these feelings do not mean you are weak.',
            'Depression affects around 20–30% of dialysis patients. Common signs: persistent low mood, loss of interest, poor sleep, low energy, feeling hopeless.',
            'Anxiety is also very common: worry about health, treatment outcomes, or the future.',
            'Tell your dialysis team or GP how you are feeling — help is available and asking is a sign of strength, not weakness.',
            'Counselling, psychology referrals, and in some cases medication can all help significantly.',
            'Peer support — talking to other dialysis patients — can be very powerful. Ask your unit about support groups.',
            'Kidney charities (such as Kidney Care UK, National Kidney Foundation) have dedicated mental health resources.'
          ],
          disclaimer: 'If you are feeling persistently low, hopeless, or are having thoughts of self-harm, please speak to your GP, dialysis team, or contact a crisis line immediately.'
        },
        {
          id: 'hd-transplant',
          title: 'Kidney Transplant — What You Should Know',
          keywords: ['transplant','kidney transplant','waiting list','transplant list','listed for transplant','how long for transplant','living donor','transplant assessment','after transplant','transplant vs dialysis'],
          tier: 'safe',
          content: 'A kidney transplant is often considered the best long-term treatment for kidney failure. Not everyone is suitable, but many dialysis patients are eligible and can be assessed for a transplant.',
          key_points: [
            'A transplant replaces the work of dialysis with a functioning kidney — most people feel significantly better after a successful transplant.',
            'Kidneys can come from a deceased donor (from the national transplant list) or a living donor (usually a family member or friend).',
            'You need to be assessed by a transplant team before being added to the waiting list.',
            'Waiting times vary enormously by country, blood group, and availability — your transplant coordinator can give you realistic expectations.',
            'After transplant, you will need to take anti-rejection medications (immunosuppressants) for life.',
            'Tell your nephrologist if you are interested in transplant assessment — they can refer you if you have not already been assessed.',
            'Living donor transplants often happen sooner and have better outcomes — if a family member or friend wants to be assessed, encourage them to speak to the transplant team.'
          ],
          disclaimer: 'Transplant suitability and eligibility are assessed by your nephrologist and transplant team. This information is general — your individual circumstances will determine whether you are suitable.'
        },
        {
          id: 'hd-medications',
          title: 'Common Medications for Dialysis Patients',
          keywords: ['medication','medications','phosphate binder','binder','epo','erythropoietin','anaemia treatment','anemia treatment','blood pressure medication','dialysis tablets','vitamin d dialysis','calcitriol','alfacalcidol','cinacalcet','iron dialysis','blood thinners','heparin dialysis'],
          tier: 'caution',
          content: 'Most dialysis patients take several medications to manage the effects of kidney failure. Understanding what each one does helps you take them correctly and report any side effects.',
          key_points: [
            'Phosphate binders (e.g. sevelamer/Renagel, calcium carbonate, lanthanum): taken WITH food to reduce phosphorus absorption. Must be taken with every meal — taking them at the wrong time makes them much less effective.',
            'EPO / erythropoietin-stimulating agents (e.g. Aranesp, Mircera): injections to treat anaemia (low red blood cell count). Usually given at the dialysis unit.',
            'Iron supplements (oral or IV): often needed alongside EPO to maintain iron stores for making red blood cells.',
            'Vitamin D analogues (e.g. calcitriol, alfacalcidol): help manage calcium, phosphorus, and parathyroid hormone levels.',
            'Blood pressure medications: very common in kidney failure — your team will adjust these as needed.',
            'Never stop or change your medication dose without speaking to your nephrologist or pharmacist.',
            'Tell every doctor, dentist, or pharmacist you see about all your medications, including supplements and herbal remedies — many interact with kidney medications.'
          ],
          disclaimer: 'This is a general overview. Your specific medications and doses are prescribed for your individual needs. Never adjust or stop medications without advice from your healthcare team.'
        },
        {
          id: 'hd-blood-tests',
          title: 'Understanding Your Blood Test Results',
          keywords: ['blood tests','blood results','lab results','kt/v','urr','urea','creatinine','haemoglobin','hemoglobin','phosphorus result','potassium result','albumin','what does my blood test mean','adequacy dialysis'],
          tier: 'caution',
          content: 'Regular blood tests are an essential part of dialysis monitoring. They help your team see how well your treatment is working, monitor your nutrition, and detect problems early.',
          key_points: [
            'Kt/V and URR (Urea Reduction Ratio): measures of dialysis adequacy — how well waste products are being removed. Your team has targets they aim for.',
            'Potassium (K+): must be kept in a safe range — high potassium (hyperkalaemia) can cause dangerous heart rhythm problems. Controlled by diet.',
            'Phosphorus: should be kept in target range — controlled by diet and phosphate binders taken with meals.',
            'Haemoglobin / Hb: measures red blood cells. Low Hb (anaemia) causes fatigue and is treated with EPO and iron.',
            'Albumin: a protein that reflects your nutritional status. Low albumin can indicate poor nutrition.',
            'PTH (parathyroid hormone): relates to bone and calcium metabolism — often elevated in kidney failure.',
            'Your results are reviewed at every clinical review — do not interpret individual numbers in isolation without your care team\'s guidance.'
          ],
          disclaimer: 'Blood test results must always be interpreted by your healthcare team in the context of your overall clinical picture. Never adjust your treatment or diet based on numbers alone without medical guidance.'
        },
        {
          id: 'hd-leg-pain-symptoms',
          title: 'Leg Pain, Cramps, and Physical Symptoms on Dialysis',
          keywords: [
            'leg pain','leg is paining','leg hurts','leg ache','legs hurt','legs ache',
            'legs are sore','legs are painful','legs are hurting','leg is hurting',
            'calf pain','calf cramp','foot pain','feet hurt','feet are swollen',
            'muscle pain','muscle ache','muscle cramp','cramps during dialysis',
            'body ache','body pain','aching after dialysis','pain after dialysis','pain during dialysis',
            'arm pain','arm ache','numb','numbness','tingling','pins and needles',
            'shortness of breath','breathless','feel faint','lightheaded',
            'nausea','nauseous','feeling sick','headache','head hurts',
            'no appetite','lost my appetite','weight loss','losing weight','losing muscle'
          ],
          tier: 'caution',
          content: 'Physical symptoms — including leg pain, cramps, aches, numbness, breathlessness, nausea, and low appetite — are common in dialysis patients. They can have several causes, most of which can be managed with the help of your care team. Here is an overview of the most frequent ones.',
          key_points: [
            'Leg cramps and muscle pain: very common during or after dialysis, often caused by rapid fluid removal, low blood pressure during treatment, or low mineral levels (calcium, magnesium). Tell your nurse — they can slow the fluid removal rate or adjust your treatment.',
            'Leg aching and tiredness: generalised aching is common after dialysis sessions as the body adjusts. Rest, gentle movement, and staying well-nourished (especially with adequate protein) can help.',
            'Numbness, tingling, or pins and needles: may be caused by peripheral neuropathy (nerve damage from kidney failure) or by poor circulation. Report these symptoms to your nephrologist.',
            'Foot and ankle swelling: often caused by excess fluid between sessions. This should be reported to your care team as it may mean your fluid allowance or dry weight needs adjusting.',
            'Shortness of breath or breathlessness: can be caused by fluid overload (too much fluid in the body) or anaemia. If severe or sudden, seek medical attention immediately. Report ongoing breathlessness to your dialysis team.',
            'Nausea, vomiting, or headache: common side effects of dialysis, particularly in newer patients or when large amounts of waste are cleared. Usually improve over time. Tell your nurse during your session.',
            'Low appetite and weight loss: dialysis patients sometimes lose appetite and lose muscle mass. A renal dietitian can help — getting enough protein at every meal is key.',
            'Low blood pressure (dizziness, faintness): a drop in blood pressure during or after dialysis can cause dizziness, light-headedness, or fainting. Tell your nurse immediately — they can slow the machine or give you a small saline flush.',
            'All of these symptoms should be reported to your dialysis team — many have simple adjustments that make a real difference.'
          ],
          disclaimer: 'If you experience sudden, severe, or worsening pain, severe breathlessness, chest pain, or any symptom that feels dangerous, seek emergency help immediately. For ongoing or persistent symptoms, always report them to your nephrologist or dialysis nurse at your next session — do not manage them alone.'
        }
      ]
    },

    // ── PERITONEAL DIALYSIS (source: data/pd-content.json) ────────────────
    pd: {
      topics: [
        {
          id: 'pd-what-is',
          title: 'What is Peritoneal Dialysis?',
          keywords: ['what is peritoneal dialysis','what is pd','how does pd work','explain peritoneal dialysis','pd explained'],
          tier: 'safe',
          content: 'Peritoneal dialysis (PD) is a home-based treatment that uses the lining of your own abdomen — called the peritoneum — as a natural filter to clean your blood. A special cleansing fluid (dialysate) is placed into your abdomen through a small soft tube (catheter), left for a set time, then drained out — taking waste and excess fluid with it.',
          key_points: [
            "The exchange of fluid in and out is called a 'dialysis exchange' or 'a bag change'.",
            'PD can be done at home, at work, or while travelling — giving you much more flexibility than in-centre HD.',
            'There are two main types: CAPD (manual exchanges during the day) and APD (automated exchanges overnight using a machine called a cycler).',
            'PD is a continuous treatment — small amounts of cleaning happen throughout the day, unlike HD which cleans intensively 3 times a week.'
          ],
          disclaimer: 'Whether PD is suitable for you depends on your clinical situation, home circumstances, and preferences. Your nephrologist and PD nurse will assess this with you.'
        },
        {
          id: 'pd-capd-vs-apd',
          title: 'CAPD vs APD — What is the Difference?',
          keywords: ['capd','apd','capd vs apd','continuous ambulatory peritoneal dialysis','automated peritoneal dialysis','cycler','difference between capd and apd'],
          tier: 'safe',
          content: 'There are two main methods of peritoneal dialysis. Your care team will help you decide which is most suitable for your lifestyle and clinical needs.',
          key_points: [
            'CAPD (Continuous Ambulatory Peritoneal Dialysis): You perform 3–5 manual bag exchanges throughout the day. Each exchange takes about 20–40 minutes. No machine is needed.',
            'APD (Automated Peritoneal Dialysis): A machine called a cycler performs the exchanges automatically while you sleep (usually over 8–10 hours). During the day you may or may not carry fluid in your abdomen.',
            'CAPD suits people who prefer not to use a machine and do not mind taking breaks during the day.',
            'APD suits people who prefer to keep their days free and are comfortable using a machine at night.',
            'Some patients do a combination of both methods.'
          ],
          disclaimer: 'The choice between CAPD and APD is made together with your dialysis team based on your clinical needs, residual kidney function, lifestyle, and home environment.'
        },
        {
          id: 'pd-catheter',
          title: 'The PD Catheter',
          keywords: ['pd catheter','peritoneal catheter','tenckhoff catheter','catheter insertion','catheter care pd','exit site'],
          tier: 'safe',
          content: 'A PD catheter is a small, soft, flexible tube that is surgically placed into your abdomen. It stays in permanently and is how dialysis fluid enters and leaves your body.',
          key_points: [
            "The catheter exits through a small opening in your skin called the 'exit site'. Keeping this site clean is critical to preventing infection.",
            'The catheter is usually inserted 2–4 weeks before you begin PD, to allow it to heal in place.',
            'Clean your exit site every day using the technique and products your PD nurse teaches you.',
            'Keep the exit site dry — no baths, swimming, or submerging in water unless your team specifically approves.',
            'Secure the catheter so it does not get pulled or snagged — a small piece of tape or a catheter belt can help.',
            'Never use scissors or sharp objects near the catheter.'
          ],
          disclaimer: "Exit site care technique is taught specifically by your PD nurse. Always follow your unit's protocol. Report any changes to your exit site immediately."
        },
        {
          id: 'pd-exchange-process',
          title: 'How to Do a PD Exchange — General Overview',
          keywords: ['how to do an exchange','pd exchange','bag change','exchange process','how does exchange work'],
          tier: 'safe',
          content: 'A PD exchange involves draining the used fluid from your abdomen and filling it with fresh dialysate. This is a general educational overview — your specific technique will be taught by your PD nurse.',
          key_points: [
            'Always wash your hands thoroughly for at least 30 seconds before touching anything connected to your catheter.',
            'Prepare a clean, flat surface. Some units provide a special tray or exchange trolley.',
            'Warm the dialysate bag to body temperature using a bag warmer (not a microwave).',
            'Check the bag: it should be clear, not cloudy. Check the expiry date. Do not use a damaged or cloudy bag.',
            'Connect the bag system to your catheter using the sterile technique you were taught.',
            'Drain out (drain phase), fill in (fill phase), dwell (fluid stays in abdomen for a set time), then drain again at the next exchange.',
            'Record each exchange in your PD diary or app as instructed.'
          ],
          disclaimer: 'This is a general overview only. Your exact procedure — including dwell times, bag strength, and connection system — is prescribed and taught by your PD care team. Never change your technique without their guidance.'
        },
        {
          id: 'pd-exit-site-care',
          title: 'Exit Site Care and Infection Prevention',
          keywords: ['exit site care','exit site infection','peritonitis prevention','catheter infection','exit site red','exit site discharge'],
          tier: 'caution',
          content: 'Keeping your exit site clean and healthy is one of the most important things you can do on PD. Exit site infections can lead to more serious infections if not treated early.',
          key_points: [
            'Clean your exit site every day — your PD nurse will show you the correct technique and which products to use.',
            'After cleaning, cover the site with a clean dry dressing.',
            'A healthy exit site looks: skin-coloured or slightly pink, no discharge, no odour, no pain.',
            'Warning signs to report to your PD team promptly: redness spreading around the exit site, pain or tenderness, discharge (pus or unusual fluid), crust or scab forming, or an unpleasant smell.',
            'Do not apply creams, lotions, or antiseptics to the exit site unless prescribed by your team.',
            'If you notice cloudy dialysate (drained fluid that looks milky or murky), this may indicate peritonitis — contact your PD unit immediately.'
          ],
          disclaimer: 'If you notice any signs of exit site infection or cloudy dialysate, contact your PD unit immediately — do not wait. Peritonitis is a serious complication that requires prompt medical treatment.'
        },
        {
          id: 'pd-peritonitis-awareness',
          title: 'Recognising Peritonitis — What to Watch For',
          keywords: ['peritonitis','cloudy bag','cloudy dialysate','signs of peritonitis','stomach pain pd','abdominal pain pd'],
          tier: 'caution',
          content: 'Peritonitis is an infection of the peritoneum (the lining of the abdomen). It is the most serious complication of PD. Early recognition and prompt action are critical.',
          key_points: [
            'The most common early sign is cloudy (milky or murky) dialysate when you drain.',
            'Other signs include: abdominal pain or tenderness, fever, nausea, vomiting, feeling generally unwell.',
            'If your drained fluid looks cloudy — even without pain — contact your PD unit immediately and keep the cloudy bag so the team can test it.',
            'Do not wait to see if it clears on its own.',
            'With prompt treatment (antibiotics given through the PD catheter), most peritonitis episodes are successfully treated at home.',
            'Repeated episodes of peritonitis can damage the peritoneum and may eventually mean you need to switch to hemodialysis.'
          ],
          disclaimer: 'Cloudy dialysate or abdominal pain on PD requires immediate contact with your PD unit — do not delay. This is a medical situation that needs prompt professional assessment.'
        },
        {
          id: 'pd-travelling',
          title: 'Travelling on Peritoneal Dialysis',
          keywords: ['travelling on pd','travel with dialysis','holiday on pd','flying with pd','pd abroad','dialysis travel'],
          tier: 'caution',
          content: 'Many PD patients travel successfully — for holidays, work, or family visits. Good planning well in advance makes travel much more manageable.',
          key_points: [
            'Contact your PD team and the PD unit at your destination at least 4–8 weeks before travel.',
            'Dialysis supply companies can often arrange delivery of supplies to your destination.',
            'Carry your catheter care kit, connection supplies, and a supply of bags as hand luggage — do not put critical supplies in checked baggage.',
            'Carry a letter from your nephrologist explaining your condition and treatment — especially useful at airport security.',
            'If travelling by air, speak to your PD nurse about whether to drain before flying.',
            'Know the location of the nearest dialysis unit or hospital at your destination.'
          ],
          disclaimer: 'Always plan travel in advance with your PD care team. They can help arrange supplies, provide letters, and advise on any adjustments to your prescription while away.'
        },
        {
          id: 'pd-caregiver',
          title: 'Information for Caregivers of PD Patients',
          keywords: ['caregiver pd','carer peritoneal','helping with pd','family pd','supporting pd patient'],
          tier: 'safe',
          content: 'Caregivers play a vital role in supporting people on peritoneal dialysis, particularly those who need assistance with exchanges.',
          key_points: [
            'Many caregivers are trained alongside the patient to assist with or perform exchanges — your PD unit offers this training.',
            'Strict hand hygiene and sterile technique are essential — your PD nurse will teach you the correct approach.',
            'Help monitor the exit site daily and keep a record of any changes.',
            'Assist with the PD diary — recording exchanges, drained volumes, and any issues.',
            'Watch for signs of peritonitis: cloudy fluid, abdominal pain, fever. Contact the PD unit immediately if these occur.',
            'Carer fatigue is real — ask about respite and support services through the dialysis social worker.'
          ],
          disclaimer: 'Caregiver training is provided by the PD unit. Never perform exchange procedures without completing the training given by your care team.'
        }
      ]
    },

    // ── NUTRITION (source: data/nutrition-rules.json) ──────────────────────
    nutrition: {
      nutrients: {
        potassium: {
          why_it_matters: 'Potassium is a mineral that helps nerves and muscles work. Damaged kidneys cannot remove excess potassium, and very high levels can cause dangerous heart rhythm problems.',
          general_guidance: 'Most dialysis patients need to limit high-potassium foods. Your individual limit is set by your dietitian based on your blood results.',
          cooking_tip: 'Leaching (peeling, cutting small, soaking in water for 2+ hours, then boiling in fresh water) reduces potassium in vegetables by 30–50%.'
        },
        phosphorus: {
          why_it_matters: 'Phosphorus is a mineral important for bone health. When kidneys fail, phosphorus builds up in the blood, weakening bones and damaging blood vessels.',
          general_guidance: 'Limit high-phosphorus foods, especially processed foods with phosphate additives. Phosphate binders may be prescribed by your doctor to be taken with meals — take them exactly as directed.',
          cooking_tip: 'Boiling foods reduces phosphorus more than other cooking methods. Avoid processed, packaged, and fast foods as they contain phosphate preservatives that absorb quickly.'
        },
        sodium: {
          why_it_matters: 'Too much sodium (salt) causes thirst and fluid retention, raising blood pressure and putting strain on your heart.',
          general_guidance: 'Limit added salt and salty foods. Read food labels — aim for products with less than 300mg sodium per serving.',
          cooking_tip: 'Use herbs, spices, lemon juice, and vinegar for flavour instead of salt. Avoid salt substitutes — most contain potassium chloride which is high in potassium.'
        },
        fluid: {
          why_it_matters: 'When kidneys fail, fluid builds up in the body, causing swelling, high blood pressure, and strain on the heart.',
          general_guidance: 'Your fluid limit is individual — it depends on your urine output, dialysis type, and other factors. All fluids count: water, tea, coffee, juice, soup, ice cream, jelly.',
          cooking_tip: 'Use small cups. Freeze allowed fluid portions as ice chips — sucking ice chips is more satisfying than drinking the same amount of water.'
        },
        protein: {
          why_it_matters: 'Dialysis removes some protein from the body. Dialysis patients generally need MORE protein than the average person to prevent muscle wasting.',
          general_guidance: 'Good protein sources for dialysis patients include: eggs, meat, fish, and poultry. Your dietitian will set your specific protein target.',
          cooking_tip: 'Include a protein source at every meal. Eggs are a versatile, affordable, high-quality protein that is lower in phosphorus than many dairy products.'
        }
      },
      foods: [
        { name: 'Apple',            potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good snack choice. Fresh is best.' },
        { name: 'Blueberries',      potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Excellent kidney-friendly fruit.' },
        { name: 'Cabbage',          potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Versatile vegetable, very kidney-friendly.' },
        { name: 'Cauliflower',      potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Great substitute for potato or rice.' },
        { name: 'Green beans',      potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good vegetable choice.' },
        { name: 'Cucumber',         potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good for snacking, high water content — count toward fluid.' },
        { name: 'White rice',       potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Better than brown rice for dialysis patients.' },
        { name: 'White bread',      potassium: 'low',    phosphorus: 'low',    sodium: 'medium', rating: 'green', note: 'Better choice than wholegrain. Watch sodium content.' },
        { name: 'Egg whites',       potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Excellent low-phosphorus protein.' },
        { name: 'Chicken breast',   potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'green', note: 'Good protein source. Fresh, unprocessed.' },
        { name: 'White fish',       potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'green', note: 'Good protein source. Avoid battered or breaded varieties.' },
        { name: 'Pineapple',        potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'One of the few tropical fruits that is low in potassium.' },
        { name: 'Grapes',           potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good snack in moderate portions.' },
        { name: 'Strawberries',     potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Kidney-friendly berry option.' },
        { name: 'Watermelon',       potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Low potassium — but counts toward fluid limit due to high water content.' },
        { name: 'Onion',            potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Great for flavouring without salt.' },
        { name: 'Garlic',           potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Use freely for flavour.' },
        { name: 'Broccoli',         potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Leach before cooking. Eat in moderate portions.' },
        { name: 'Carrot',           potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Boil rather than steam or roast.' },
        { name: 'Bell pepper',      potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Moderate portions. Red peppers higher than green.' },
        { name: 'Pasta (white)',    potassium: 'low',    phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Better than wholegrain pasta. Moderate portions.' },
        { name: 'Beef (lean)',      potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Good protein. Avoid processed/cured varieties.' },
        { name: 'Egg (whole)',      potassium: 'low',    phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Yolk has more phosphorus than white. Egg whites preferred.' },
        { name: 'Corn',             potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Moderate portion. Avoid canned corn — high sodium.' },
        { name: 'Peas',             potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Small portions. Fresh or frozen preferred over canned.' },
        { name: 'Mango',            potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Moderate portions — popular in many cultural diets.' },
        { name: 'Papaya',           potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Moderate portions.' },
        { name: "Milk (cow's)",     potassium: 'medium', phosphorus: 'high',   sodium: 'low',    rating: 'amber', note: 'Limit to small amounts (½ cup per day). High in phosphorus.' },
        { name: 'Rice cakes',       potassium: 'low',    phosphorus: 'medium', sodium: 'medium', rating: 'amber', note: 'Moderate portions. Check sodium on label.' },
        { name: 'Banana',           potassium: 'high',   phosphorus: 'low',    sodium: 'low',    rating: 'red',   note: 'Very high in potassium. Speak to your dietitian before eating.' },
        { name: 'Orange',           potassium: 'high',   phosphorus: 'low',    sodium: 'low',    rating: 'red',   note: 'High potassium and high fluid content.' },
        { name: 'Potato',           potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'Very high potassium. Leach by peeling, cubing, soaking 2+ hrs, then boil in fresh water.' },
        { name: 'Tomato',           potassium: 'high',   phosphorus: 'low',    sodium: 'low',    rating: 'red',   note: 'High potassium, especially tomato sauce and paste. Small fresh portions may be tolerated.' },
        { name: 'Avocado',          potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'Very high potassium. Limit or avoid.' },
        { name: 'Spinach',          potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'Very high potassium even after cooking.' },
        { name: 'Kale',             potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'High potassium.' },
        { name: 'Sweet potato',     potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'Very high potassium. Leaching helps but does not fully reduce.' },
        { name: 'Chocolate',        potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High in both potassium and phosphorus.' },
        { name: 'Cola / dark soda', potassium: 'medium', phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'Contains phosphoric acid — absorbs very quickly. Avoid.' },
        { name: 'Nuts and seeds',   potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High in both minerals. Small amounts only if approved by dietitian.' },
        { name: 'Dried fruit',      potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'red',   note: 'Very concentrated potassium. Avoid raisins, apricots, prunes, dates.' },
        { name: 'Whole grain bread',potassium: 'medium', phosphorus: 'high',   sodium: 'medium', rating: 'red',   note: 'High phosphorus. White bread is a better choice.' },
        { name: 'Bran cereal',      potassium: 'high',   phosphorus: 'high',   sodium: 'medium', rating: 'red',   note: 'Very high in both. Avoid.' },
        { name: 'Canned soup',      potassium: 'medium', phosphorus: 'medium', sodium: 'high',   rating: 'red',   note: 'Extremely high sodium. Avoid or choose very low sodium versions.' },
        { name: 'Processed meat',   potassium: 'medium', phosphorus: 'high',   sodium: 'high',   rating: 'red',   note: 'Bacon, sausages, ham, deli meats — high in sodium and phosphate additives.' },
        { name: 'Salt substitutes', potassium: 'high',   phosphorus: 'low',    sodium: 'low',    rating: 'red',   note: 'Contain potassium chloride — extremely high potassium. Do NOT use.' },
        { name: 'Tomato sauce',     potassium: 'high',   phosphorus: 'low',    sodium: 'high',   rating: 'red',   note: 'Very high potassium and sodium. Use fresh tomato (small amount) instead.' },
        { name: 'Tomato paste',     potassium: 'high',   phosphorus: 'low',    sodium: 'high',   note: 'Extremely concentrated — very high potassium. Avoid.', rating: 'red' },
        { name: 'Lentils',          potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High in both potassium and phosphorus. Small portions only — consult dietitian.' },
        { name: 'Kidney beans',     potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High potassium and phosphorus. Rinse canned beans thoroughly — reduces potassium by ~30%.' },
        { name: 'Chickpeas',        potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High in both minerals. Very small amounts only.' },
        { name: 'Black beans',      potassium: 'high',   phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High potassium and phosphorus. Rinse thoroughly if canned.' },
        { name: 'Yoghurt',          potassium: 'medium', phosphorus: 'high',   sodium: 'low',    rating: 'red',   note: 'High phosphorus. Very small portions (2–3 tbsp) only.' },
        { name: 'Cheese',           potassium: 'low',    phosphorus: 'high',   sodium: 'high',   rating: 'red',   note: 'High phosphorus and sodium. Small amounts of soft cheese (brie, cream cheese) preferred.' },
        { name: 'Milk (plant-based)',potassium: 'low',   phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Rice milk or oat milk (without phosphate additives) can be a good lower-phosphorus alternative. Check labels.' },
        { name: 'Cream cheese',     potassium: 'low',    phosphorus: 'medium', sodium: 'medium', rating: 'amber', note: 'Lower phosphorus than hard cheese. Use in small amounts.' },
        { name: 'Tofu',             potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Moderate protein choice. Firm tofu is higher in phosphorus than silken.' },
        { name: 'Pear',             potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good kidney-friendly fruit choice.' },
        { name: 'Cherries',         potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good low-potassium fruit.' },
        { name: 'Peach',            potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Fresh peach in moderate portions. Avoid canned in syrup.' },
        { name: 'Plum',             potassium: 'medium', phosphorus: 'low',    sodium: 'low',    rating: 'amber', note: 'Fresh plum in small portions. Prunes (dried) are very high potassium — avoid.' },
        { name: 'Lamb',             potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'green', note: 'Good protein source. Fresh, unprocessed.' },
        { name: 'Turkey',           potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'green', note: 'Good lean protein. Avoid deli/processed turkey — high sodium.' },
        { name: 'Tuna (canned)',    potassium: 'medium', phosphorus: 'medium', sodium: 'high',   rating: 'amber', note: 'Good protein but high sodium. Choose tuna in water and rinse before use.' },
        { name: 'Salmon',           potassium: 'high',   phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'High potassium. Rich in omega-3. Moderate portions — discuss with dietitian.' },
        { name: 'Oats',             potassium: 'medium', phosphorus: 'medium', sodium: 'low',    rating: 'amber', note: 'Moderate portions (small bowl). Better than bran cereals.' },
        { name: 'Cornflakes',       potassium: 'low',    phosphorus: 'low',    sodium: 'medium', rating: 'amber', note: 'Lower-potassium cereal option. Avoid adding dried fruit or milk in large amounts.' },
        { name: 'Butter',           potassium: 'low',    phosphorus: 'low',    sodium: 'medium', rating: 'green', note: 'Small amounts are fine. Unsalted butter preferred.' },
        { name: 'Olive oil',        potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Healthy fat. Use in cooking instead of butter or high-sodium sauces.' },
        { name: 'Honey',            potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Good natural sweetener in small amounts.' },
        { name: 'Jam',              potassium: 'low',    phosphorus: 'low',    sodium: 'low',    rating: 'green', note: 'Small amounts are fine. Good on white toast.' }
      ],
      cultural_notes: {
        'south-asian': {
          common_high_risk: ['spinach (saag)','potato (aloo)','tomato-heavy curries','lentils (dal)','whole wheat chapati'],
          kidney_friendly_swaps: [
            'Use cauliflower instead of potato in curries (gobi dishes naturally kidney-friendly).',
            'Use white rice or white bread (naan) instead of whole wheat chapati.',
            'Use small amounts of thoroughly leached potato rather than avoiding all South Asian dishes.',
            'Use fresh ginger and cumin for flavour instead of salt.',
            'Lentils (dal) are high in potassium and phosphorus — use small portions and consult dietitian.',
            'Paneer (fresh cheese) is higher in phosphorus — limit portion size.'
          ]
        },
        'east-asian': {
          common_high_risk: ['soy sauce (very high sodium)','miso soup (very high sodium)','seaweed (high potassium)','edamame (high potassium/phosphorus)','whole grain rice'],
          kidney_friendly_swaps: [
            'Use low-sodium soy sauce in very small amounts (1 tsp max).',
            'Limit or avoid miso soup — extremely high sodium.',
            'Use white rice instead of brown or mixed grain rice.',
            'Tofu is a moderate phosphorus protein — small portions are acceptable.',
            'Bok choy and white cabbage are good low-potassium vegetable choices.',
            'Steam or boil fish rather than frying to reduce sodium.'
          ]
        },
        'west-african': {
          common_high_risk: ['plantain (high potassium)','cassava (moderate potassium)','groundnut (peanut — high phosphorus)','palm nut soup','canned tomato puree (high sodium)'],
          kidney_friendly_swaps: [
            'Use small amounts of leached yam instead of large portions of plantain.',
            'White rice and garri (cassava flour) are reasonable carbohydrate staples.',
            'Use fresh tomatoes in small amounts rather than canned tomato puree.',
            'Season with fresh herbs, ginger, and minimal salt rather than stock cubes (very high sodium).',
            'Egusi (melon seed) is moderate in potassium — small portions with dietitian advice.',
            'Boil or steam rather than frying to reduce unhealthy fats.'
          ]
        },
        'caribbean': {
          common_high_risk: ['plantain (high potassium)','sweet potato (high potassium)','ackee (moderate potassium)','scotch bonnet pepper','salt fish (very high sodium)'],
          kidney_friendly_swaps: [
            'Use white rice or white bread as your main starch.',
            'Leach plantain and sweet potato: peel, cube, soak 2+ hours, boil in fresh water.',
            'Salt fish must be desalted thoroughly — soak overnight and boil in fresh water multiple times before use.',
            'Use fresh fish (snapper, tilapia) rather than salted or smoked fish.',
            'Season with fresh thyme, allspice, and scotch bonnet (small amount) instead of salt.',
            'Callaloo is high in potassium — use in small amounts and leach before cooking.'
          ]
        },
        'latin-american': {
          common_high_risk: ['black beans/refried beans (high potassium/phosphorus)','avocado/guacamole (high potassium)','tomato salsa','corn tortillas in large amounts'],
          kidney_friendly_swaps: [
            'Use small portions of well-rinsed canned beans (rinsing reduces potassium by ~30%).',
            'Corn tortillas in small amounts (1–2) are acceptable — better than flour tortillas.',
            'Use small amounts of fresh tomato rather than salsa or tomato sauce.',
            'Avoid avocado or guacamole — very high potassium.',
            'Rice and lean chicken dishes adapt well to kidney-friendly cooking.',
            'Use lime juice, cumin, and chilli for flavour instead of salt.'
          ]
        },
        'middle-eastern': {
          common_high_risk: ['hummus (high potassium/phosphorus from chickpeas)','tahini (high phosphorus)','dried fruits in desserts','heavily salted olives'],
          kidney_friendly_swaps: [
            'Limit hummus to a very small amount (1 tbsp) — chickpeas are high in potassium.',
            'Use white pita bread rather than wholemeal.',
            'Fresh cucumber and tomato (small amount) salads can be adapted with less tomato.',
            'Grilled chicken or lamb kebabs with herbs are a good protein choice.',
            'Use lemon juice, sumac, and cumin for flavour instead of salt.',
            'Avoid dates, figs, and dried apricots — very high potassium.'
          ]
        },
        'east-african': {
          common_high_risk: ['injera (fermented teff — moderate potassium/phosphorus)','lentils (high potassium)','collard greens/gomen (high potassium)','spiced butter (niter kibbeh) — high sodium'],
          kidney_friendly_swaps: [
            'Use smaller portions of injera with white rice as an alternative starch.',
            'Use well-rinsed split red lentils in small amounts — lower potassium than whole lentils.',
            'Leach collard greens thoroughly before cooking.',
            'Use fresh herbs and spices (turmeric, cumin, fenugreek) without added salt.',
            'Chicken tibs (lean chicken stew) adapted with less salt is a good kidney-friendly dish.',
            'Avoid large amounts of berbere spice mix — contains salt.'
          ]
        },
        'european': {
          common_high_risk: ['roast potato (very high potassium)','baked beans (high potassium/sodium)','cheese (high phosphorus)','cured meats — ham/bacon (high sodium/phosphorus)','full cream milk in large amounts'],
          kidney_friendly_swaps: [
            'Leach potatoes thoroughly or use cauliflower mash as a substitute.',
            'Avoid baked beans — use fresh or frozen green beans instead.',
            'Use small amounts of low-phosphorus cheese (e.g. brie, camembert) rather than hard cheeses.',
            'Avoid cured meats — use fresh lean meat instead.',
            'Use skimmed milk in small amounts (½ cup per day) rather than full cream.',
            'Season with herbs (rosemary, thyme, parsley) and lemon juice instead of salt.'
          ]
        },
        'general': {
          common_high_risk: ['processed foods with phosphate additives','salt substitutes','large portions of high-potassium vegetables','dark sodas'],
          kidney_friendly_swaps: [
            'Choose fresh over processed foods whenever possible.',
            "Read food labels — avoid ingredients ending in '-phosphate'.",
            'Use herbs, spices, lemon, and vinegar for flavour instead of salt.',
            'Never use salt substitutes — they contain potassium chloride.',
            'Leach high-potassium vegetables before cooking.'
          ]
        }
      },
      cooking_tips: [
        { tip: 'Leaching Vegetables', detail: 'Peel and cut vegetables into small pieces. Soak in a large volume of water for at least 2 hours (or overnight for potatoes). Drain and rinse. Then boil in fresh water (not the soaking water). This can reduce potassium by 30–50%.' },
        { tip: 'Avoid Phosphate Additives', detail: "Check food labels for ingredients ending in '-phosphate' (e.g. sodium phosphate, calcium phosphate). These are used as preservatives in processed foods and are absorbed much more quickly by the body than naturally occurring phosphorus." },
        { tip: 'No Salt Substitutes', detail: "Products labelled 'Lo-Salt', 'Nu-Salt', or 'lite salt' contain potassium chloride. For dialysis patients, these can raise blood potassium to dangerous levels. Use herbs, spices, and lemon juice for flavour instead." },
        { tip: 'Boiling Reduces More Than Steaming', detail: 'Boiling vegetables in plenty of water leaches out potassium and phosphorus more effectively than steaming or microwaving. Always drain and discard the cooking water.' },
        { tip: 'Rinse Canned Foods', detail: 'If using canned vegetables or beans (not ideal, but sometimes necessary), rinse them thoroughly under running water for 1–2 minutes to reduce sodium by up to 40%.' }
      ]
    },

    // ── MEALS (inline stub — full plans are in data/meal-plans.json)
    // MealPlanner.js reads _data.meals — we provide a minimal stub so
    // getMealPlan() returns null gracefully and MealPlanner falls back.
    // The full meal-plans.json is still the source for the meal planner.
    meals: null
  };

  // Mark as loaded immediately — no async needed
  var _loaded = true;

  // ─────────────────────────────────────────────────────────────────────────
  // PUBLIC init() — kept for API compatibility, calls callback synchronously
  // ─────────────────────────────────────────────────────────────────────────
  function init(callback) {
    console.log(
      '%c KnowledgeBase ready (inline data) ',
      'background:#16a34a;color:#fff;font-weight:bold;padding:3px 7px;border-radius:3px;'
    );
    if (typeof callback === 'function') callback(null);
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SEARCH
  // ─────────────────────────────────────────────────────────────────────────
  // Synonym map — common patient phrasings mapped to KB keyword terms
  var _synonyms = {
    'needle':         'fistula',
    'needles':        'fistula',
    'buzzing':        'fistula',
    'thrill':         'fistula',
    'arm access':     'fistula',
    'dialysis tube':  'catheter',
    'neck tube':      'catheter',
    'neck line':      'catheter',
    'central line':   'catheter',
    'peritonitis':    'peritonitis',
    'cloudy bag':     'cloudy bag',
    'cloudy fluid':   'cloudy bag',
    'milky fluid':    'cloudy bag',
    'bag change':     'exchange process',
    'exchange':       'exchange process',
    'cycler':         'apd cycler',
    'cycler machine': 'apd cycler',
    'overnight machine': 'apd cycler',
    'apd':            'capd apd',
    'capd':           'capd apd',
    'cramps':         'cramps',
    'muscle cramps':  'cramps',
    'itch':           'itching',
    'itchy':          'itching',
    'pruritus':       'itching',
    'uraemic itch':   'itching',
    'uremic itch':    'itching',
    'restless leg':   'restless legs',
    'restless legs':  'restless legs',
    'rlss':           'restless legs',
    'tired':          'fatigue',
    'tiredness':      'fatigue',
    'exhausted':      'fatigue',
    'fatigue':        'fatigue',
    'low bp':         'low blood pressure',
    'blood pressure drop': 'low blood pressure',
    'hypotension':    'low blood pressure',
    'dizzy':          'low blood pressure',
    'dizziness':      'low blood pressure',
    'nausea':         'nausea dialysis',
    'vomiting':       'nausea dialysis',
    'feel sick':      'nausea dialysis',
    'headache':       'headache dialysis',
    'head pain':      'headache dialysis',
    'weight':         'dry weight',
    'dry weight':     'dry weight',
    'fluid weight':   'dry weight',
    'fluid gain':     'fluid restriction',
    'swollen':        'fluid restriction',
    'swelling':       'fluid restriction',
    'oedema':         'fluid restriction',
    'edema':          'fluid restriction',
    'exercise':       'exercise',
    'walking':        'exercise',
    'gym':            'exercise',
    'workout':        'exercise',
    'physical activity': 'exercise',
    'anxiety':        'mental health',
    'depression':     'mental health',
    'low mood':       'mental health',
    'stress':         'mental health',
    'emotional':      'mental health',
    'transplant':     'transplant',
    'kidney transplant': 'transplant',
    'waiting list':   'transplant',
    'binder':         'phosphate binder',
    'phosphate binder': 'phosphate binder',
    'renagel':        'phosphate binder',
    'sevelamer':      'phosphate binder',
    'calcitriol':     'vitamin d dialysis',
    'vitamin d':      'vitamin d dialysis',
    'epo':            'epo anaemia',
    'erythropoietin': 'epo anaemia',
    'anaemia':        'epo anaemia',
    'anemia':         'epo anaemia',
    'blood results':  'blood tests',
    'blood test':     'blood tests',
    'lab results':    'blood tests',
    'urt':            'blood tests',
    'kt/v':           'blood tests',
    'urr':            'blood tests',
    'urea':           'blood tests',
    'creatinine':     'blood tests',
    'sleep':          'sleep',
    'insomnia':       'sleep',
    'cant sleep':     'sleep',
    "can't sleep":    'sleep',
    'trouble sleeping': 'sleep',
    'travel':         'travelling',
    'holiday':        'travelling',
    'flying':         'travelling',
    'vacation':       'travelling',
    'home dialysis':  'home hemodialysis',
    'home hd':        'home hemodialysis',
    'nocturnal':      'home hemodialysis',
    'pain':           'pain dialysis cramps side effects',
    'paining':        'pain dialysis cramps side effects',
    'hurts':          'pain dialysis cramps side effects',
    'hurting':        'pain dialysis cramps side effects',
    'aching':         'pain dialysis cramps side effects',
    'sore':           'pain dialysis cramps side effects',
    'leg pain':       'leg pain cramps side effects',
    'leg is paining': 'leg pain cramps side effects',
    'leg hurts':      'leg pain cramps side effects',
    'leg ache':       'leg pain cramps side effects',
    'legs hurt':      'leg pain cramps side effects',
    'legs ache':      'leg pain cramps side effects',
    'legs are sore':  'leg pain cramps side effects',
    'legs are painful':'leg pain cramps side effects',
    'calf pain':      'leg pain cramps side effects',
    'calf cramp':     'cramps',
    'foot pain':      'leg pain cramps side effects',
    'feet hurt':      'leg pain cramps side effects',
    'arm pain':       'fistula access side effects',
    'arm ache':       'fistula access side effects',
    'muscle pain':    'cramps muscle side effects',
    'muscle ache':    'cramps muscle side effects',
    'muscle weakness':'fatigue side effects',
    'body ache':      'pain side effects dialysis',
    'body pain':      'pain side effects dialysis',
    'numb':           'numb numbness side effects',
    'numbness':       'numb numbness side effects',
    'tingling':       'numb numbness side effects',
    'pins and needles':'numb numbness side effects',
    'breathless':     'shortness breath side effects',
    'shortness of breath': 'shortness breath side effects',
    'hard to breathe':'shortness breath side effects',
    'feel faint':     'low blood pressure side effects',
    'lightheaded':    'low blood pressure side effects',
    'no appetite':    'appetite nutrition side effects',
    'not hungry':     'appetite nutrition side effects',
    'lost appetite':  'appetite nutrition side effects',
    'weight loss':    'weight nutrition side effects',
    'losing weight':  'weight nutrition side effects',
    'nauseous':       'nausea dialysis side effects',
    'feeling sick':   'nausea dialysis side effects',
    'vomit':          'nausea dialysis side effects'
  };

  function _applysynonyms(text) {
    var result = text;
    Object.keys(_synonyms).forEach(function(phrase) {
      if (result.includes(phrase)) result += ' ' + _synonyms[phrase];
    });
    return result;
  }

  function search(query) {
    var lower      = query.toLowerCase();
    var expanded   = _applysynonyms(lower);   // synonym-expanded query
    var results    = [];
    // Build a list of words from the query (length > 2) for content scoring
    var queryWords = expanded.split(/\s+/).filter(function(w) { return w.length > 2; });

    function scoreTopics(topics) {
      if (!Array.isArray(topics)) return;
      topics.forEach(function(topic) {
        var score = 0;

        // Exact keyword matches — highest weight (keyword list is curated)
        if (Array.isArray(topic.keywords)) {
          topic.keywords.forEach(function(kw) {
            // Use whole-phrase or word-boundary check for short keywords
            if (kw.length > 4 ? expanded.includes(kw) : new RegExp('\\b' + kw + '\\b').test(expanded)) score += 5;
          });
        }

        // Exact title match
        if (topic.title && expanded.includes(topic.title.toLowerCase())) score += 5;

        // Individual title words (4+ chars)
        (topic.title || '').toLowerCase().split(/\s+/).forEach(function(w) {
          if (w.length > 3 && expanded.includes(w)) score += 2;
        });

        // Content full-text — counts how many query words appear in content
        var contentText = [
          topic.content || '',
          (topic.key_points || []).join(' ')
        ].join(' ').toLowerCase();
        queryWords.forEach(function(w) {
          if (contentText.includes(w)) score += 1;
        });

        // Require a minimum score to avoid low-confidence noise matches
        if (score >= 3) results.push({ score: score, topic: topic });
      });
    }

    if (_data.hd && _data.hd.topics) scoreTopics(_data.hd.topics);
    if (_data.pd && _data.pd.topics) scoreTopics(_data.pd.topics);
    results.sort(function(a, b) { return b.score - a.score; });
    return results.slice(0, 3).map(function(r) { return r.topic; });
  }

  function getTopic(id) {
    var all = [];
    if (_data.hd && _data.hd.topics) all = all.concat(_data.hd.topics);
    if (_data.pd && _data.pd.topics) all = all.concat(_data.pd.topics);
    for (var i = 0; i < all.length; i++) { if (all[i].id === id) return all[i]; }
    return null;
  }

  function buildTopicHTML(topic) {
    var tierLabel = { safe: '', caution: '⚠️ Caution', urgent: '🚨 Important' }[topic.tier] || '';
    var html = '<h4>' + _esc(topic.title) +
      (tierLabel ? ' <span style="font-size:0.78rem;font-weight:600;color:#d97706;margin-left:6px;">' + tierLabel + '</span>' : '') +
      '</h4>';
    html += '<p>' + _esc(topic.content) + '</p>';
    if (Array.isArray(topic.key_points) && topic.key_points.length) {
      html += '<ul>' + topic.key_points.map(function(pt) { return '<li>' + _esc(pt) + '</li>'; }).join('') + '</ul>';
    }
    if (topic.disclaimer) {
      html += '<p style="margin-top:0.75rem;padding:8px 12px;background:#fefce8;border-left:3px solid #d97706;border-radius:4px;font-size:0.85rem;color:#92400e;">' +
        '📋 ' + _esc(topic.disclaimer) + '</p>';
    }
    return html;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // NUTRITION
  // ─────────────────────────────────────────────────────────────────────────
  function findFoods(query) {
    if (!_data.nutrition || !_data.nutrition.foods) return [];
    var lower = query.toLowerCase();
    return _data.nutrition.foods.filter(function(f) { return f.name.toLowerCase().includes(lower); });
  }

  function getNutrientInfo(nutrient) {
    if (!_data.nutrition) return null;
    return _data.nutrition.nutrients[nutrient.toLowerCase()] || null;
  }

  function getCulturalNotes(culture) {
    if (!_data.nutrition) return null;
    return _data.nutrition.cultural_notes[culture] || _data.nutrition.cultural_notes['general'] || null;
  }

  function getCookingTips() {
    return (_data.nutrition && _data.nutrition.cooking_tips) ? _data.nutrition.cooking_tips : [];
  }

  // ─────────────────────────────────────────────────────────────────────────
  // MEAL PLAN — tries inline meals first, falls back gracefully
  // ─────────────────────────────────────────────────────────────────────────
  function getMealPlan(culture, dialysisType) {
    if (!_data.meals || !_data.meals.plans) return null;
    var plans = _data.meals.plans;
    for (var i = 0; i < plans.length; i++) {
      if (plans[i].culture === culture && plans[i].dialysis_type === dialysisType) return plans[i];
    }
    for (var j = 0; j < plans.length; j++) {
      if (plans[j].culture === 'general' && plans[j].dialysis_type === dialysisType) return plans[j];
    }
    return null;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // UTILITY
  // ─────────────────────────────────────────────────────────────────────────
  function _esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  function isLoaded() { return _loaded; }

  return {
    init: init, isLoaded: isLoaded,
    search: search, getTopic: getTopic, buildTopicHTML: buildTopicHTML,
    findFoods: findFoods, getNutrientInfo: getNutrientInfo,
    getCulturalNotes: getCulturalNotes, getCookingTips: getCookingTips,
    getMealPlan: getMealPlan
  };

}());
