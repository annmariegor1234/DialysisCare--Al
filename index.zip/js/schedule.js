/**
 * DialysisCare AI Assistant — js/schedule.js
 * ===========================================
 * "Schedule & Reminders" feature.
 *
 * WHAT THIS MODULE DOES
 * ─────────────────────
 * 1. Lets users create events (appointments / tasks) with:
 *    title, date, time, category, repeat option, reminder offset, notes.
 * 2. Stores events in localStorage. Renders an "Upcoming" list sorted by date.
 * 3. Schedules in-browser reminders using setTimeout.
 *    Honestly discloses that reminders only fire while the tab is open.
 * 4. Requests Web Notifications permission when the user opts in.
 * 5. Saves clinic and transport contacts. Provides one-tap Call / Text buttons
 *    that build tel:/sms: links — but always shows a confirmation modal first
 *    so the user knows exactly what will happen, and the app never claims the
 *    call or ride was arranged.
 *
 * HONESTY PRINCIPLES
 * ──────────────────
 * • Reminders are setTimeout-based: they only fire while the page is open.
 *   We say this explicitly in the UI and in every reminder permission dialog.
 * • tel:/sms: links open the OS dialler/messaging app. We always confirm
 *   first and state clearly that this app cannot make calls or send messages.
 * • We never say a taxi/ride was booked — we only open the contact.
 * • Nothing is sent to any server. All data is localStorage-only.
 */

var Schedule = (function () {
  'use strict';

  var EVENTS_KEY   = 'dialysiscare_schedule_events';
  var CONTACTS_KEY = 'dialysiscare_schedule_contacts';

  // Active setTimeout handles so we can cancel them on re-init
  var _reminderHandles = [];

  // ── SUGGESTED EVENT TEMPLATES ─────────────────────────────────────────────
  var _SUGGESTIONS = {
    dialysis:   { title: 'Dialysis appointment',          category: 'dialysis',   reminder: '60' },
    lab:        { title: 'Lab blood test',                category: 'lab',        reminder: '60' },
    access:     { title: 'Vein-access clinic appointment',category: 'access',     reminder: '60' },
    taxi:       { title: 'Arrange taxi for dialysis',     category: 'transport',  reminder: '1440' },
    clean:      { title: 'Clean dialysis equipment',      category: 'equipment',  reminder: '30' },
    fluid:      { title: 'Check fluid allowance log',     category: 'other',      reminder: '15' },
    medication: { title: 'Collect medications',           category: 'medication', reminder: '1440' },
    dietitian:  { title: 'Dietitian appointment',         category: 'nutrition',  reminder: '60' }
  };

  // Category icon map
  var _CAT_ICON = {
    dialysis:  '💉',
    lab:       '🔬',
    access:    '🩺',
    transport: '🚖',
    medication:'💊',
    nutrition: '🥗',
    equipment: '🧼',
    other:     '📌'
  };

  var _CONTACT_ICON = {
    clinic:    '🏥',
    dialysis:  '💉',
    taxi:      '🚖',
    dietitian: '🥗',
    pharmacy:  '💊',
    other:     '📌'
  };

  // ── STORAGE ───────────────────────────────────────────────────────────────

  function _loadEvents() {
    try { return JSON.parse(localStorage.getItem(EVENTS_KEY) || '[]'); }
    catch (e) { return []; }
  }

  function _saveEvents(events) {
    try { localStorage.setItem(EVENTS_KEY, JSON.stringify(events)); }
    catch (e) { console.warn('Schedule: could not save events', e); }
  }

  function _loadContacts() {
    try { return JSON.parse(localStorage.getItem(CONTACTS_KEY) || '[]'); }
    catch (e) { return []; }
  }

  function _saveContacts(contacts) {
    try { localStorage.setItem(CONTACTS_KEY, JSON.stringify(contacts)); }
    catch (e) { console.warn('Schedule: could not save contacts', e); }
  }

  // ── ID GENERATION ─────────────────────────────────────────────────────────

  function _uid() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
  }

  // ── ESCAPE HTML ───────────────────────────────────────────────────────────

  function _esc(s) {
    return String(s || '')
      .replace(/&/g, '&amp;').replace(/</g, '&lt;')
      .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  // ── DATE HELPERS ──────────────────────────────────────────────────────────

  function _eventDateTime(event) {
    // Returns a Date or null
    if (!event.date) return null;
    var d = event.time ? new Date(event.date + 'T' + event.time) : new Date(event.date + 'T00:00:00');
    return isNaN(d.getTime()) ? null : d;
  }

  function _formatDate(dateStr) {
    if (!dateStr) return '';
    try {
      var d = new Date(dateStr + 'T00:00:00');
      return d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
    } catch (e) { return dateStr; }
  }

  function _formatTime(timeStr) {
    if (!timeStr) return '';
    try {
      var d = new Date('2000-01-01T' + timeStr);
      return d.toLocaleTimeString(undefined, { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return timeStr; }
  }

  function _isPast(event) {
    var dt = _eventDateTime(event);
    if (!dt) return false;
    return dt < new Date();
  }

  function _daysFromNow(event) {
    var dt = _eventDateTime(event);
    if (!dt) return Infinity;
    var now = new Date();
    var diff = dt - now;
    return diff / (1000 * 60 * 60 * 24);
  }

  // ── REPEAT EXPANSION ──────────────────────────────────────────────────────
  // For display only: generate the next N occurrences of a repeating event

  function _nextOccurrences(event, count) {
    if (!event.repeat || event.repeat === 'none') return [event];
    var base = _eventDateTime(event);
    if (!base) return [event];

    var results = [];
    var cursor = new Date(base);
    var now = new Date();
    var iterations = 0;
    var maxIter = 200; // safety cap

    while (results.length < count && iterations < maxIter) {
      iterations++;
      if (cursor >= now) {
        results.push(Object.assign({}, event, {
          date: cursor.toISOString().slice(0, 10),
          time: event.time || '',
          _generated: true
        }));
      }
      // Advance cursor
      var next = new Date(cursor);
      if (event.repeat === 'daily')       next.setDate(next.getDate() + 1);
      else if (event.repeat === 'weekly') next.setDate(next.getDate() + 7);
      else if (event.repeat === 'fortnightly') next.setDate(next.getDate() + 14);
      else if (event.repeat === 'monthly') next.setMonth(next.getMonth() + 1);
      else break;
      cursor = next;
    }
    return results;
  }

  // ── RENDER UPCOMING LIST ──────────────────────────────────────────────────

  function _renderUpcoming() {
    var container = document.getElementById('sc-upcoming-list');
    if (!container) return;

    var events = _loadEvents();
    var now = new Date();

    // Expand repeating events and collect all future occurrences
    var allItems = [];
    events.forEach(function (ev) {
      if (ev.repeat && ev.repeat !== 'none') {
        var occ = _nextOccurrences(ev, 6);
        occ.forEach(function (o) { allItems.push(o); });
      } else {
        allItems.push(ev);
      }
    });

    // Split into upcoming and past
    var upcoming = allItems.filter(function (e) { return !_isPast(e); });
    var past = events.filter(function (e) { return !e.repeat || e.repeat === 'none'; })
                     .filter(function (e) { return _isPast(e); });

    upcoming.sort(function (a, b) {
      var da = _eventDateTime(a), db = _eventDateTime(b);
      if (!da) return 1; if (!db) return -1;
      return da - db;
    });

    if (!upcoming.length && !past.length) {
      container.innerHTML =
        '<div class="sc-empty">' +
        '<span class="sc-empty-icon">📅</span>' +
        '<p>No events yet.</p>' +
        '<p class="text-muted text-sm">Use the <strong>Add event</strong> tab to schedule your first appointment or task.</p>' +
        '</div>';
      return;
    }

    var html = '';

    if (upcoming.length) {
      html += '<div class="sc-section-title">Upcoming (' + upcoming.length + ')</div>';
      html += upcoming.map(function (ev) { return _renderEventCard(ev, false); }).join('');
    }

    if (past.length) {
      var showPast = past.slice(0, 5); // show last 5 past events
      html += '<details class="sc-past-details">';
      html += '<summary class="sc-past-summary">Past events (' + past.length + ')</summary>';
      html += showPast.map(function (ev) { return _renderEventCard(ev, true); }).join('');
      html += '</details>';
    }

    container.innerHTML = html;

    // Wire edit/delete buttons
    container.querySelectorAll('[data-sc-edit]').forEach(function (btn) {
      btn.addEventListener('click', function () { _editEvent(btn.dataset.scEdit); });
    });
    container.querySelectorAll('[data-sc-delete]').forEach(function (btn) {
      btn.addEventListener('click', function () { _deleteEvent(btn.dataset.scDelete); });
    });
    container.querySelectorAll('[data-sc-done]').forEach(function (btn) {
      btn.addEventListener('click', function () { _markDone(btn.dataset.scDone); });
    });
  }

  function _renderEventCard(ev, isPast) {
    var icon = _CAT_ICON[ev.category] || '📌';
    var days = _daysFromNow(ev);
    var urgency = '';
    if (!isPast) {
      if (days <= 0.5)       urgency = 'sc-urgent';
      else if (days <= 1)    urgency = 'sc-today';
      else if (days <= 3)    urgency = 'sc-soon';
    }

    var dateLabel = _formatDate(ev.date) + (ev.time ? ' at ' + _formatTime(ev.time) : '');
    var repeatLabel = ev.repeat && ev.repeat !== 'none'
      ? '<span class="sc-repeat-badge">🔁 ' + _repeatLabel(ev.repeat) + '</span>'
      : '';

    var reminderLabel = ev.reminder && ev.reminder !== 'none'
      ? '<span class="sc-reminder-badge">🔔 ' + _reminderLabel(ev.reminder) + '</span>'
      : '';

    var actions = isPast
      ? ''
      : '<div class="sc-card-actions">' +
          (ev._generated ? '' : '<button class="sc-action-btn sc-action-done"  data-sc-done="'   + _esc(ev.id) + '" title="Mark done">✓ Done</button>') +
          (ev._generated ? '' : '<button class="sc-action-btn sc-action-edit"  data-sc-edit="'   + _esc(ev.id) + '" title="Edit">✏️</button>') +
          (ev._generated ? '' : '<button class="sc-action-btn sc-action-delete" data-sc-delete="'+ _esc(ev.id) + '" title="Delete">🗑</button>') +
        '</div>';

    return '<div class="sc-event-card ' + (isPast ? 'sc-past' : urgency) + '">' +
      '<div class="sc-event-icon">' + icon + '</div>' +
      '<div class="sc-event-body">' +
        '<div class="sc-event-title">' + _esc(ev.title) + '</div>' +
        '<div class="sc-event-meta">' +
          '<span class="sc-event-date">' + _esc(dateLabel) + '</span>' +
          repeatLabel + reminderLabel +
        '</div>' +
        (ev.notes ? '<div class="sc-event-notes">' + _esc(ev.notes) + '</div>' : '') +
      '</div>' +
      actions +
    '</div>';
  }

  function _repeatLabel(r) {
    var map = { daily: 'Daily', weekly: 'Weekly', fortnightly: 'Every 2 weeks', monthly: 'Monthly' };
    return map[r] || r;
  }

  function _reminderLabel(r) {
    var map = { '5':'5 min before', '15':'15 min before', '30':'30 min before',
                '60':'1 hr before', '120':'2 hrs before', '1440':'1 day before' };
    return map[String(r)] || r + ' min before';
  }

  // ── FORM HANDLING ─────────────────────────────────────────────────────────

  function _clearForm() {
    var ids = ['sc-title','sc-date','sc-time','sc-notes','sc-edit-id'];
    ids.forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ''; });
    var cat = document.getElementById('sc-category');
    if (cat) cat.value = 'dialysis';
    var rep = document.getElementById('sc-repeat');
    if (rep) rep.value = 'none';
    var rem = document.getElementById('sc-reminder');
    if (rem) rem.value = 'none';
    var cancelBtn = document.getElementById('sc-btn-cancel-edit');
    if (cancelBtn) cancelBtn.style.display = 'none';
  }

  function _fillForm(ev) {
    var set = function (id, val) { var el = document.getElementById(id); if (el) el.value = val || ''; };
    set('sc-edit-id', ev.id);
    set('sc-title',    ev.title);
    set('sc-date',     ev.date);
    set('sc-time',     ev.time);
    set('sc-category', ev.category);
    set('sc-repeat',   ev.repeat || 'none');
    set('sc-reminder', ev.reminder || 'none');
    set('sc-notes',    ev.notes);
    var cancelBtn = document.getElementById('sc-btn-cancel-edit');
    if (cancelBtn) cancelBtn.style.display = '';
    // Switch to add tab
    _switchTab('add');
    var title = document.getElementById('sc-title');
    if (title) setTimeout(function () { title.focus(); }, 50);
  }

  function _saveEvent() {
    var title = (document.getElementById('sc-title') || {}).value.trim();
    var date  = (document.getElementById('sc-date')  || {}).value;
    if (!title) { _showFormError('Please enter an event title.'); return; }
    if (!date)  { _showFormError('Please choose a date.'); return; }

    var editId = (document.getElementById('sc-edit-id') || {}).value;
    var events = _loadEvents();

    var ev = {
      id:       editId || _uid(),
      title:    title,
      date:     date,
      time:     (document.getElementById('sc-time')     || {}).value || '',
      category: (document.getElementById('sc-category') || {}).value || 'other',
      repeat:   (document.getElementById('sc-repeat')   || {}).value || 'none',
      reminder: (document.getElementById('sc-reminder') || {}).value || 'none',
      notes:    (document.getElementById('sc-notes')    || {}).value.trim() || '',
      done:     false,
      created:  new Date().toISOString()
    };

    if (editId) {
      var idx = events.findIndex(function (e) { return e.id === editId; });
      if (idx !== -1) events[idx] = ev; else events.push(ev);
    } else {
      events.push(ev);
    }

    _saveEvents(events);
    _clearForm();
    _scheduleReminders();
    _switchTab('upcoming');
    _renderUpcoming();
    _showToast(editId ? 'Event updated.' : 'Event saved.');
  }

  function _editEvent(id) {
    var events = _loadEvents();
    var ev = events.find(function (e) { return e.id === id; });
    if (ev) _fillForm(ev);
  }

  function _deleteEvent(id) {
    if (!window.confirm('Delete this event?')) return;
    var events = _loadEvents().filter(function (e) { return e.id !== id; });
    _saveEvents(events);
    _scheduleReminders();
    _renderUpcoming();
    _showToast('Event deleted.');
  }

  function _markDone(id) {
    var events = _loadEvents();
    var ev = events.find(function (e) { return e.id === id; });
    if (ev) {
      ev.done = true;
      ev.doneAt = new Date().toISOString();
      // Move date to past so it falls into past section
      ev.date = new Date().toISOString().slice(0, 10);
    }
    _saveEvents(events);
    _renderUpcoming();
    _showToast('Marked as done.');
  }

  function _showFormError(msg) {
    var existing = document.getElementById('sc-form-error');
    if (existing) existing.remove();
    var div = document.createElement('div');
    div.id = 'sc-form-error';
    div.className = 'sc-form-error';
    div.textContent = msg;
    var form = document.getElementById('sc-event-form');
    if (form) form.insertBefore(div, form.firstChild);
    setTimeout(function () { var e = document.getElementById('sc-form-error'); if (e) e.remove(); }, 4000);
  }

  // ── SUGGESTION CHIPS ──────────────────────────────────────────────────────

  function _applySuggestion(key) {
    var s = _SUGGESTIONS[key];
    if (!s) return;
    var title = document.getElementById('sc-title');
    if (title) title.value = s.title;
    var cat = document.getElementById('sc-category');
    if (cat) cat.value = s.category;
    var rem = document.getElementById('sc-reminder');
    if (rem) rem.value = s.reminder;
    // Set tomorrow as the default date if not already filled
    var dateIn = document.getElementById('sc-date');
    if (dateIn && !dateIn.value) {
      var d = new Date(); d.setDate(d.getDate() + 1);
      dateIn.value = d.toISOString().slice(0, 10);
    }
    if (title) title.focus();
  }

  // ── CONTACTS ──────────────────────────────────────────────────────────────

  function _renderContacts() {
    var container = document.getElementById('sc-contacts-list');
    if (!container) return;

    var contacts = _loadContacts();
    if (!contacts.length) {
      container.innerHTML = '<p class="text-muted text-sm" style="margin-bottom:var(--space-md);">No contacts saved yet. Use the form below to add your clinic, dialysis unit, or taxi service.</p>';
      return;
    }

    var html = '<div class="sc-contacts-grid">';
    contacts.forEach(function (c) {
      var icon = _CONTACT_ICON[c.type] || '📌';
      var callBtn = c.phone
        ? '<button class="sc-contact-action sc-contact-call" data-phone="' + _esc(c.phone) + '" data-name="' + _esc(c.name) + '" aria-label="Call ' + _esc(c.name) + '">📞 Call</button>'
        : '';
      var textBtn = c.phone
        ? '<button class="sc-contact-action sc-contact-text" data-phone="' + _esc(c.phone) + '" data-name="' + _esc(c.name) + '" aria-label="Text ' + _esc(c.name) + '">💬 Text</button>'
        : '';
      html += '<div class="sc-contact-card">' +
        '<div class="sc-contact-icon">' + icon + '</div>' +
        '<div class="sc-contact-body">' +
          '<div class="sc-contact-name">' + _esc(c.name) + '</div>' +
          (c.phone ? '<div class="sc-contact-phone">' + _esc(c.phone) + '</div>' : '<div class="sc-contact-phone text-muted">No number saved</div>') +
        '</div>' +
        '<div class="sc-contact-actions">' +
          callBtn + textBtn +
          '<button class="sc-contact-action sc-contact-edit" data-cid="' + _esc(c.id) + '" aria-label="Edit">✏️</button>' +
          '<button class="sc-contact-action sc-contact-delete" data-cid="' + _esc(c.id) + '" aria-label="Delete">🗑</button>' +
        '</div>' +
      '</div>';
    });
    html += '</div>';
    container.innerHTML = html;

    // Wire actions
    container.querySelectorAll('.sc-contact-call').forEach(function (btn) {
      btn.addEventListener('click', function () { _confirmPhone('call', btn.dataset.phone, btn.dataset.name); });
    });
    container.querySelectorAll('.sc-contact-text').forEach(function (btn) {
      btn.addEventListener('click', function () { _confirmPhone('text', btn.dataset.phone, btn.dataset.name); });
    });
    container.querySelectorAll('.sc-contact-edit').forEach(function (btn) {
      btn.addEventListener('click', function () { _editContact(btn.dataset.cid); });
    });
    container.querySelectorAll('.sc-contact-delete').forEach(function (btn) {
      btn.addEventListener('click', function () { _deleteContact(btn.dataset.cid); });
    });
  }

  function _saveContact() {
    var name  = (document.getElementById('sc-contact-name')  || {}).value.trim();
    var phone = (document.getElementById('sc-contact-phone') || {}).value.trim();
    var type  = (document.getElementById('sc-contact-type')  || {}).value || 'other';
    var editId = (document.getElementById('sc-contact-edit-id') || {}).value;

    if (!name) { alert('Please enter a name or label for this contact.'); return; }

    var contacts = _loadContacts();
    var contact = { id: editId || _uid(), name: name, phone: phone, type: type };

    if (editId) {
      var idx = contacts.findIndex(function (c) { return c.id === editId; });
      if (idx !== -1) contacts[idx] = contact; else contacts.push(contact);
    } else {
      contacts.push(contact);
    }

    _saveContacts(contacts);
    _clearContactForm();
    _renderContacts();
    _showToast(editId ? 'Contact updated.' : 'Contact saved.');
  }

  function _editContact(id) {
    var contacts = _loadContacts();
    var c = contacts.find(function (x) { return x.id === id; });
    if (!c) return;
    var set = function (elId, val) { var el = document.getElementById(elId); if (el) el.value = val || ''; };
    set('sc-contact-edit-id', c.id);
    set('sc-contact-name',  c.name);
    set('sc-contact-phone', c.phone);
    set('sc-contact-type',  c.type);
    var cancelBtn = document.getElementById('sc-btn-cancel-contact');
    if (cancelBtn) cancelBtn.style.display = '';
    var nameEl = document.getElementById('sc-contact-name');
    if (nameEl) nameEl.focus();
  }

  function _deleteContact(id) {
    if (!window.confirm('Delete this contact?')) return;
    var contacts = _loadContacts().filter(function (c) { return c.id !== id; });
    _saveContacts(contacts);
    _renderContacts();
    _showToast('Contact deleted.');
  }

  function _clearContactForm() {
    ['sc-contact-name','sc-contact-phone','sc-contact-edit-id'].forEach(function (id) {
      var el = document.getElementById(id); if (el) el.value = '';
    });
    var t = document.getElementById('sc-contact-type'); if (t) t.value = 'clinic';
    var cancelBtn = document.getElementById('sc-btn-cancel-contact');
    if (cancelBtn) cancelBtn.style.display = 'none';
  }

  // ── CALL / TEXT CONFIRM MODAL ─────────────────────────────────────────────

  function _confirmPhone(action, phone, name) {
    var modal = document.getElementById('sc-call-modal');
    var body  = document.getElementById('sc-modal-body');
    var link  = document.getElementById('sc-modal-action-link');
    var title = document.getElementById('sc-modal-title');
    if (!modal || !body || !link) return;

    // Sanitise phone: keep digits, spaces, +, -, (, )
    var safePh = phone.replace(/[^0-9\s+\-().]/g, '');

    if (action === 'call') {
      title.textContent = 'Open phone dialler?';
      body.textContent  = 'This will ask your device to call ' + name + ' (' + phone + '). ' +
        'This app cannot make the call itself — your phone\'s dialler will open. ' +
        'The app will not know whether the call was made or completed.';
      link.href = 'tel:' + safePh.replace(/\s/g, '');
      link.textContent = 'Open dialler';
    } else {
      title.textContent = 'Open messaging app?';
      body.textContent  = 'This will open your messaging app to contact ' + name + ' (' + phone + '). ' +
        'This app cannot send the message itself — your phone\'s messaging app will open. ' +
        'The app will not know whether the message was sent or whether transport was arranged.';
      link.href = 'sms:' + safePh.replace(/\s/g, '');
      link.textContent = 'Open messaging app';
    }

    modal.classList.add('open');
    modal.setAttribute('aria-hidden', 'false');
    link.focus();
  }

  function _closeCallModal() {
    var modal = document.getElementById('sc-call-modal');
    if (modal) { modal.classList.remove('open'); modal.setAttribute('aria-hidden', 'true'); }
  }

  // ── NOTIFICATIONS & REMINDERS ─────────────────────────────────────────────

  function _notifyStatus() {
    if (!('Notification' in window)) return 'unsupported';
    return Notification.permission; // 'default' | 'granted' | 'denied'
  }

  function _updateNotifyStatusUI() {
    var statusEl = document.getElementById('sc-notify-status');
    var btn      = document.getElementById('sc-btn-request-notify');
    if (!statusEl) return;
    var perm = _notifyStatus();
    if (perm === 'unsupported') {
      statusEl.textContent = 'Browser notifications are not supported on this device.';
      statusEl.className = 'sc-notify-status sc-notify-unsupported';
      if (btn) btn.style.display = 'none';
    } else if (perm === 'granted') {
      statusEl.textContent = '✅ Notifications enabled — reminders will show as browser alerts while this tab is open.';
      statusEl.className = 'sc-notify-status sc-notify-granted';
      if (btn) btn.style.display = 'none';
    } else if (perm === 'denied') {
      statusEl.textContent = '🚫 Notifications blocked. To enable, go to your browser\'s site settings and allow notifications for this page.';
      statusEl.className = 'sc-notify-status sc-notify-denied';
      if (btn) btn.style.display = 'none';
    } else {
      statusEl.textContent = '';
      if (btn) btn.style.display = '';
    }
  }

  function _requestNotifyPermission() {
    if (!('Notification' in window)) return;
    Notification.requestPermission().then(function () {
      _updateNotifyStatusUI();
      _scheduleReminders();
    });
  }

  // Clear all pending reminder timeouts, then reschedule from current event list
  function _scheduleReminders() {
    _reminderHandles.forEach(clearTimeout);
    _reminderHandles = [];

    if (_notifyStatus() !== 'granted') return;

    var events = _loadEvents();
    var now = new Date();

    events.forEach(function (ev) {
      if (!ev.reminder || ev.reminder === 'none') return;
      var dt = _eventDateTime(ev);
      if (!dt) return;

      var offsetMs  = parseInt(ev.reminder, 10) * 60 * 1000;
      var fireAt    = new Date(dt.getTime() - offsetMs);
      var delay     = fireAt.getTime() - now.getTime();

      if (delay < 0) return; // already past

      // setTimeout is limited to ~24.8 days (2^31 ms); skip events further away
      if (delay > 2147483647) return;

      var handle = setTimeout(function () {
        try {
          new Notification('DialysisCare Reminder', {
            body: ev.title + ' — ' + _formatDate(ev.date) + (ev.time ? ' at ' + _formatTime(ev.time) : ''),
            icon: 'assets/kidney-icon.svg',
            tag:  'dialysiscare-' + ev.id
          });
        } catch (e) { console.warn('Notification failed', e); }
      }, delay);

      _reminderHandles.push(handle);
    });
  }

  // ── TAB SWITCHING ─────────────────────────────────────────────────────────

  function _switchTab(tabKey) {
    document.querySelectorAll('.sc-tab').forEach(function (t) {
      var active = t.dataset.scTab === tabKey;
      t.classList.toggle('active', active);
      t.setAttribute('aria-selected', String(active));
    });
    document.querySelectorAll('.sc-panel').forEach(function (p) {
      p.classList.remove('active');
    });
    var panel = document.getElementById('sc-panel-' + tabKey);
    if (panel) panel.classList.add('active');

    // Refresh data when switching to relevant panels
    if (tabKey === 'upcoming')  _renderUpcoming();
    if (tabKey === 'contacts')  _renderContacts();
  }

  // ── TOAST ─────────────────────────────────────────────────────────────────

  function _showToast(msg) {
    var existing = document.getElementById('sc-toast');
    if (existing) existing.remove();
    var toast = document.createElement('div');
    toast.id = 'sc-toast';
    toast.className = 'sc-toast';
    toast.textContent = msg;
    document.body.appendChild(toast);
    requestAnimationFrame(function () { toast.classList.add('sc-toast-show'); });
    setTimeout(function () {
      toast.classList.remove('sc-toast-show');
      setTimeout(function () { if (toast.parentNode) toast.parentNode.removeChild(toast); }, 350);
    }, 2500);
  }

  // ── PUBLIC init() ─────────────────────────────────────────────────────────

  function init() {
    // Initial render
    _renderUpcoming();
    _updateNotifyStatusUI();

    // ── Tab switching ─────────────────────────────────────────────────────
    document.querySelectorAll('.sc-tab[data-sc-tab]').forEach(function (tab) {
      tab.addEventListener('click', function () { _switchTab(tab.dataset.scTab); });
    });

    // ── Notification permission button ────────────────────────────────────
    var notifyBtn = document.getElementById('sc-btn-request-notify');
    if (notifyBtn) {
      notifyBtn.addEventListener('click', _requestNotifyPermission);
    }

    // ── Suggestion chips ──────────────────────────────────────────────────
    document.querySelectorAll('.sc-chip[data-suggest]').forEach(function (chip) {
      chip.addEventListener('click', function () {
        _applySuggestion(chip.dataset.suggest);
        _switchTab('add');
      });
    });

    // ── Event form ────────────────────────────────────────────────────────
    var form = document.getElementById('sc-event-form');
    if (form) {
      form.addEventListener('submit', function (e) { e.preventDefault(); _saveEvent(); });
    }

    var cancelEditBtn = document.getElementById('sc-btn-cancel-edit');
    if (cancelEditBtn) {
      cancelEditBtn.addEventListener('click', function () { _clearForm(); _switchTab('upcoming'); });
    }

    var clearFormBtn = document.getElementById('sc-btn-clear-form');
    if (clearFormBtn) {
      clearFormBtn.addEventListener('click', _clearForm);
    }

    // ── Contact form ──────────────────────────────────────────────────────
    var saveContactBtn = document.getElementById('sc-btn-save-contact');
    if (saveContactBtn) {
      saveContactBtn.addEventListener('click', _saveContact);
    }

    var cancelContactBtn = document.getElementById('sc-btn-cancel-contact');
    if (cancelContactBtn) {
      cancelContactBtn.addEventListener('click', function () { _clearContactForm(); _renderContacts(); });
    }

    // ── Call/text modal ───────────────────────────────────────────────────
    var cancelModalBtn = document.getElementById('sc-modal-cancel');
    if (cancelModalBtn) {
      cancelModalBtn.addEventListener('click', _closeCallModal);
    }
    var modal = document.getElementById('sc-call-modal');
    if (modal) {
      modal.addEventListener('click', function (e) { if (e.target === modal) _closeCallModal(); });
      // Also close modal after the action link is clicked (user has tapped Continue)
      var actionLink = document.getElementById('sc-modal-action-link');
      if (actionLink) {
        actionLink.addEventListener('click', function () {
          setTimeout(_closeCallModal, 300);
        });
      }
    }
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') _closeCallModal();
    });

    // ── Schedule reminders for any events that are already saved ─────────
    _scheduleReminders();
  }

  // ── PUBLIC API ────────────────────────────────────────────────────────────
  return { init: init };

}());
