/**
 * DialysisCare AI Assistant — js/nutritionGuide.js
 * ==================================================
 * Food lookup, traffic-light rating, and cultural food swap display.
 * Uses KnowledgeBase to access nutrition-rules.json data.
 */

var NutritionGuide = (function () {

  // ── FOOD SEARCH ──────────────────────────────────────────────────────────

  /**
   * lookupFood(query) → HTML string showing traffic-light results
   */
  function lookupFood(query) {
    var foods = KnowledgeBase.findFoods(query);
    if (!foods || foods.length === 0) {
      return '<p>No food matching "<strong>' + _esc(query) + '</strong>" found in the database. ' +
             'Try a simpler search term (e.g. "banana" instead of "ripe banana"). ' +
             'Ask your renal dietitian about foods not listed here.</p>';
    }
    return _buildFoodTable(foods);
  }

  function _buildFoodTable(foods) {
    var rows = foods.map(function(f) {
      var badge = _ratingBadge(f.rating);
      var pk = _mineralBadge(f.potassium);
      var ph = _mineralBadge(f.phosphorus);
      var na = _mineralBadge(f.sodium);
      return '<tr>' +
        '<td><strong>' + _esc(f.name) + '</strong></td>' +
        '<td style="text-align:center;">' + badge + '</td>' +
        '<td style="text-align:center;">' + pk + '</td>' +
        '<td style="text-align:center;">' + ph + '</td>' +
        '<td style="text-align:center;">' + na + '</td>' +
        '<td class="text-sm text-muted">' + _esc(f.note || '') + '</td>' +
        '</tr>';
    }).join('');

    return '<div style="overflow-x:auto;">' +
      '<table class="food-table">' +
      '<thead><tr>' +
      '<th>Food</th><th>Overall</th><th>Potassium</th><th>Phosphorus</th><th>Sodium</th><th>Notes</th>' +
      '</tr></thead>' +
      '<tbody>' + rows + '</tbody>' +
      '</table></div>';
  }

  function _ratingBadge(rating) {
    var map = {
      green: '<span class="tl-badge tl-badge-green">🟢 OK</span>',
      amber: '<span class="tl-badge tl-badge-amber">🟡 Moderate</span>',
      red:   '<span class="tl-badge tl-badge-red">🔴 Caution</span>'
    };
    return map[rating] || rating;
  }

  function _mineralBadge(level) {
    var map = {
      low:    '<span class="tl-badge tl-badge-green">Low</span>',
      medium: '<span class="tl-badge tl-badge-amber">Medium</span>',
      high:   '<span class="tl-badge tl-badge-red">High</span>'
    };
    return map[level] || level;
  }

  // ── NUTRIENT INFO ─────────────────────────────────────────────────────────

  /**
   * buildNutrientHTML(nutrientName) → HTML string
   */
  function buildNutrientHTML(nutrientName) {
    var info = KnowledgeBase.getNutrientInfo(nutrientName);
    if (!info) return '<p>Nutrient information not found.</p>';
    return '<h4>' + _esc(nutrientName.charAt(0).toUpperCase() + nutrientName.slice(1)) + '</h4>' +
      '<p>' + _esc(info.why_it_matters) + '</p>' +
      '<p><strong>General Guidance:</strong> ' + _esc(info.general_guidance) + '</p>' +
      '<p><strong>Cooking Tip:</strong> ' + _esc(info.cooking_tip) + '</p>';
  }

  // ── CULTURAL FOOD NOTES ───────────────────────────────────────────────────

  /**
   * buildCulturalHTML(culture) → HTML string with high-risk foods + swaps
   */
  function buildCulturalHTML(culture) {
    var notes = KnowledgeBase.getCulturalNotes(culture);
    if (!notes) return '<p>No cultural food notes available for this selection.</p>';

    var html = '';

    if (Array.isArray(notes.common_high_risk) && notes.common_high_risk.length) {
      html += '<div class="notice notice-warning" style="margin-bottom:1rem;">' +
        '<span class="notice-icon">⚠️</span>' +
        '<div class="notice-body"><strong>Common High-Risk Foods in This Cuisine</strong><ul>' +
        notes.common_high_risk.map(function(f) { return '<li>' + _esc(f) + '</li>'; }).join('') +
        '</ul></div></div>';
    }

    if (Array.isArray(notes.kidney_friendly_swaps) && notes.kidney_friendly_swaps.length) {
      html += '<div class="notice notice-success" style="margin-bottom:1rem;">' +
        '<span class="notice-icon">✅</span>' +
        '<div class="notice-body"><strong>Kidney-Friendly Swaps & Tips</strong><ul>' +
        notes.kidney_friendly_swaps.map(function(s) { return '<li>' + _esc(s) + '</li>'; }).join('') +
        '</ul></div></div>';
    }

    return html || '<p>No cultural notes found.</p>';
  }

  // ── COOKING TIPS ──────────────────────────────────────────────────────────

  /**
   * buildCookingTipsHTML() → HTML string of all cooking tips
   */
  function buildCookingTipsHTML() {
    var tips = KnowledgeBase.getCookingTips();
    if (!tips.length) return '<p>Cooking tips not available.</p>';
    return tips.map(function(t) {
      return '<div class="content-block" style="margin-bottom:1rem;">' +
        '<h4>🍳 ' + _esc(t.tip) + '</h4>' +
        '<p class="text-muted">' + _esc(t.detail) + '</p>' +
        '</div>';
    }).join('');
  }

  // ── TRAFFIC LIGHT SUMMARY PANEL ───────────────────────────────────────────

  /**
   * buildTrafficLightSummaryHTML() → HTML for the overview traffic-light panel
   */
  function buildTrafficLightSummaryHTML() {
    var data = KnowledgeBase.isLoaded() ? KnowledgeBase.findFoods('') : [];
    // If findFoods('') returns nothing, build a static overview
    return '<div class="food-traffic-light">' +
      '<div class="tl-item tl-green">' +
      '  <span class="tl-emoji">🟢</span>' +
      '  <strong>Generally OK</strong>' +
      '  <p>Low potassium &amp; low phosphorus. Examples: apple, cabbage, cauliflower, white rice, egg whites, white fish.</p>' +
      '</div>' +
      '<div class="tl-item tl-amber">' +
      '  <span class="tl-emoji">🟡</span>' +
      '  <strong>Eat in Moderation</strong>' +
      '  <p>Medium levels. Watch portions. Examples: broccoli, carrot, whole egg, corn, milk (½ cup).</p>' +
      '</div>' +
      '<div class="tl-item tl-red">' +
      '  <span class="tl-emoji">🔴</span>' +
      '  <strong>Use Caution / Limit</strong>' +
      '  <p>High potassium or phosphorus. Examples: banana, potato, tomato, spinach, chocolate, salt substitutes.</p>' +
      '</div>' +
      '</div>';
  }

  // ── MEAL SUGGESTION (constraint-based) ───────────────────────────────────

  /**
   * buildMealSuggestionHTML(constraints)
   *
   * constraints: object with optional keys potassium, phosphorus, protein
   *   values: 'low' | 'medium' | 'high'  (the user's stated preference)
   *   e.g. { potassium: 'low', phosphorus: 'low', protein: 'high' }
   *
   * Uses the general/hd dinner options from meal-plans.json as concrete
   * examples, cross-checks main ingredients against nutrition-rules.json.
   * Only makes claims that are directly supported by those sources.
   */
  function buildMealSuggestionHTML(constraints) {
    var c = constraints || {};

    // Pull dinner options from the general HD plan (most conservative targets).
    // MealPlanner has the full inline data; KnowledgeBase.getMealPlan is a stub.
    var plan = (typeof MealPlanner !== 'undefined' && MealPlanner.findPlan)
      ? MealPlanner.findPlan('general', 'hd')
      : KnowledgeBase.getMealPlan('general', 'hd');

    var dinners = [];
    if (plan && Array.isArray(plan.days)) {
      plan.days.forEach(function(d) {
        if (d.dinner) dinners.push({ day: d.day, meal: d.dinner.meal, notes: d.dinner.notes });
      });
    }

    // Score each dinner against the constraints using food DB data.
    // A known ingredient that violates a "low" constraint disqualifies the meal.
    function scoreDinner(mealText) {
      var lower = mealText.toLowerCase();
      var score = 0;
      var allFoods = KnowledgeBase.findFoods('');
      allFoods.forEach(function(f) {
        if (!lower.includes(f.name.toLowerCase())) return;
        if (c.potassium === 'low') {
          if (f.potassium === 'low')   score += 2;
          if (f.potassium === 'high')  score -= 10;
        }
        if (c.phosphorus === 'low') {
          if (f.phosphorus === 'low')  score += 2;
          if (f.phosphorus === 'high') score -= 10;
        }
        if (c.protein === 'high') {
          if (f.note && /protein/i.test(f.note)) score += 3;
        }
      });
      return score;
    }

    var scored = dinners.map(function(d) {
      return { score: scoreDinner(d.meal), dinner: d };
    });
    scored.sort(function(a, b) { return b.score - a.score; });

    var best = scored.length > 0 ? scored[0].dinner : null;

    // Build a small food table for the protein sources found in the chosen meal.
    function ingredientTable(mealText) {
      var lower = mealText.toLowerCase();
      var allFoods = KnowledgeBase.findFoods('');
      var hits = allFoods.filter(function(f) {
        return lower.includes(f.name.toLowerCase()) && f.note && /protein/i.test(f.note);
      });
      if (!hits.length) {
        hits = allFoods.filter(function(f) {
          return lower.includes(f.name.toLowerCase());
        }).slice(0, 3);
      }
      return hits.length ? _buildFoodTable(hits) : '';
    }

    var html = '';

    if (!best) {
      // Meal plans not embedded in this session — honest fallback using food DB alone.
      html += '<p>Based on the nutrition guidelines in this assistant, a kidney-friendly dinner ' +
        'with <strong>low potassium</strong>, <strong>low phosphorus</strong>, and ' +
        '<strong>high protein</strong> would typically include:</p>' +
        '<ul>' +
        '<li><strong>Protein:</strong> Egg whites, grilled chicken breast, or white fish — ' +
        'listed in the food database as good protein sources with low or medium potassium and phosphorus.</li>' +
        '<li><strong>Carbohydrate:</strong> White rice or white bread — both rated low potassium and low phosphorus.</li>' +
        '<li><strong>Vegetable:</strong> Cauliflower, cabbage, or green beans — all rated low potassium and low phosphorus.</li>' +
        '</ul>' +
        '<p class="text-muted" style="font-size:0.85rem;">Confirm portion sizes with your renal dietitian.</p>';
      return html;
    }

    // Best-matched dinner from the sample plan.
    html += '<div class="notice notice-success" style="margin-bottom:1rem;">' +
      '<span class="notice-icon">🍽️</span>' +
      '<div class="notice-body">' +
      '<strong>Dinner idea from the sample meal plan</strong>' +
      '<p style="margin:0.4rem 0 0;">' + _esc(best.meal) + '</p>' +
      (best.notes ? '<p class="text-muted" style="margin:0.3rem 0 0;font-size:0.9rem;">' + _esc(best.notes) + '</p>' : '') +
      '</div></div>';

    // Food DB evidence for the main protein ingredients.
    var table = ingredientTable(best.meal);
    if (table) {
      html += '<p><strong>Nutrient profile of the main protein source(s), from the food database:</strong></p>' + table;
    }

    // Explain which constraints are met, citing the DB directly.
    html += '<p style="margin-top:0.75rem;"><strong>How this meal addresses your constraints:</strong></p><ul>';
    var allFoods2 = KnowledgeBase.findFoods('');
    var mealLower = best.meal.toLowerCase();
    var proteinFoods = allFoods2.filter(function(f) {
      return mealLower.includes(f.name.toLowerCase()) && f.note && /protein/i.test(f.note);
    });
    if (proteinFoods.length) {
      var pf = proteinFoods[0];
      html += '<li><strong>Protein:</strong> ' + _esc(pf.name) + ' — "' + _esc(pf.note) + '" (food database).</li>';
      if (c.potassium === 'low') {
        html += '<li><strong>Potassium:</strong> ' + _esc(pf.name) + ' is rated <em>' + _esc(pf.potassium) + '</em> in the food database.</li>';
      }
      if (c.phosphorus === 'low') {
        html += '<li><strong>Phosphorus:</strong> ' + _esc(pf.name) + ' is rated <em>' + _esc(pf.phosphorus) + '</em> in the food database.</li>';
      }
    } else {
      html += '<li>The food database does not contain a detailed entry for the exact protein source in this meal. Confirm suitability with your renal dietitian.</li>';
    }
    html += '</ul>';

    // Source attribution + safety disclaimer.
    html += '<p class="text-muted" style="font-size:0.85rem;margin-top:0.75rem;">' +
      '📂 <strong>Source:</strong> meal-plans.json (' + _esc(plan.label) + ') and nutrition-rules.json (food database). ' +
      'This is a sample educational meal. Individual limits for potassium, phosphorus, sodium, fluid, and protein ' +
      'must be confirmed with your renal dietitian.</p>';

    return html;
  }

  // ── LIBRARY CARDS (for Educational Library view) ─────────────────────────

  /**
   * buildLibraryCards() → HTML string of nutrient summary cards for the Library
   */
  function buildLibraryCards() {
    var nutrients = ['potassium', 'phosphorus', 'sodium', 'fluid', 'protein'];
    var icons = { potassium: '🍌', phosphorus: '🦴', sodium: '🧂', fluid: '💧', protein: '🥩' };
    return nutrients.map(function(n) {
      var info = KnowledgeBase.getNutrientInfo(n);
      if (!info) return '';
      return '<div class="lib-card">' +
        '<div class="lib-card-icon">' + (icons[n] || '🥗') + '</div>' +
        '<div class="lib-card-body">' +
        '<h3 class="lib-card-title">' + n.charAt(0).toUpperCase() + n.slice(1) + '</h3>' +
        '<p class="lib-card-desc">' + _esc(info.why_it_matters.substring(0, 160)) + (info.why_it_matters.length > 160 ? '…' : '') + '</p>' +
        '<p class="lib-card-desc" style="margin-top:0.4rem;"><strong>Tip:</strong> ' + _esc(info.cooking_tip.substring(0, 120)) + (info.cooking_tip.length > 120 ? '…' : '') + '</p>' +
        '</div>' +
        '</div>';
    }).join('');
  }

  // ── UTILITY ───────────────────────────────────────────────────────────────

  function _esc(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── PUBLIC API ────────────────────────────────────────────────────────────
  return {
    lookupFood:                   lookupFood,
    buildNutrientHTML:            buildNutrientHTML,
    buildCulturalHTML:            buildCulturalHTML,
    buildCookingTipsHTML:         buildCookingTipsHTML,
    buildTrafficLightSummaryHTML: buildTrafficLightSummaryHTML,
    buildMealSuggestionHTML:      buildMealSuggestionHTML,
    buildLibraryCards:            buildLibraryCards
  };

}());
