/**
 * DialysisCare AI Assistant — js/safetyGuard.js
 * ================================================
 * The patient safety layer. Loaded before any other logic.
 *
 * RESPONSIBILITIES:
 *  1. classify(message) → 'emergency' | 'high_risk' | 'caution' | 'safe'
 *  2. buildResponse(riskLevel, message) → structured response object
 *  3. Manage the human review queue (stored in localStorage — no patient data)
 *  4. Expose queue read/update API for the Safety Review dashboard
 *
 * SAFETY POLICY (per user specification):
 *  emergency  → Show 911/emergency services message IMMEDIATELY. Nothing else first.
 *  high_risk  → General safety guidance only + refer to nephrologist + flag for review.
 *  caution    → Educational answer + prominent warning + care-team referral.
 *  safe       → Full educational answer + standard disclaimer.
 *
 * NO PATIENT DATA is collected, stored, or transmitted at any point.
 * Queue items store only: a sanitised topic label, risk level, and timestamp.
 */

// ─────────────────────────────────────────────────────────────────────────────
// KEYWORD DATA — loaded once from safety-keywords.json
// Fallback inline copy guards against file-load failures.
// ─────────────────────────────────────────────────────────────────────────────

var SafetyGuard = (function () {

  // Will be populated by loadKeywords()
  var _keywords = null;

  // localStorage key for the review queue
  var QUEUE_KEY = 'dialysiscare_review_queue';

  // ── 1. LOAD KEYWORDS ──────────────────────────────────────────────────────

  function loadKeywords(callback) {
    if (_keywords) { callback(_keywords); return; }

    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'data/safety-keywords.json', true);
    xhr.onload = function () {
      if (xhr.status === 200) {
        try {
          _keywords = JSON.parse(xhr.responseText);
        } catch (e) {
          console.error('SafetyGuard: Failed to parse keywords JSON', e);
          _keywords = _fallbackKeywords();
        }
      } else {
        console.warn('SafetyGuard: Could not load safety-keywords.json — using fallback.');
        _keywords = _fallbackKeywords();
      }
      callback(_keywords);
    };
    xhr.onerror = function () {
      console.warn('SafetyGuard: XHR error loading keywords — using fallback.');
      _keywords = _fallbackKeywords();
      callback(_keywords);
    };
    xhr.send();
  }

  // Minimal fallback so the guard is never completely disabled
  function _fallbackKeywords() {
    return {
      emergency:  { triggers: ['chest pain','can\'t breathe','seizure','unconscious','catheter fell out','cloudy dialysate','severe bleeding'] },
      high_risk:  { medications: ['medication','dose','drug','pill'], lab_values: ['my potassium','my lab results'], diagnosis_requests: ['do i have','diagnose'], clinical_decisions: ['skip dialysis','stop dialysis'], acute_symptoms: ['fever','severe vomiting'] },
      caution:    { high_nutrient_foods: ['banana','potato','dairy'], fluid_questions: ['fluid limit','how much can i drink'], mild_symptoms: ['tired','itching','cramp'], lifestyle_sensitive: ['exercise','travel','pregnant'] },
      safe:       { topics: ['what is dialysis','how does dialysis work','kidney friendly','low potassium','meal ideas'] }
    };
  }

  // ── 2. CLASSIFY ───────────────────────────────────────────────────────────

  /**
   * classify(message) → 'emergency' | 'high_risk' | 'caution' | 'safe'
   * Checks from most to least severe. First match wins.
   */
  function classify(message) {
    if (!_keywords) {
      console.warn('SafetyGuard.classify called before keywords loaded — defaulting to high_risk.');
      return 'high_risk';
    }

    var lower = message.toLowerCase();

    // ── EMERGENCY (highest priority — check first) ────────────────────────
    var emergencyTriggers = _keywords.emergency ? _keywords.emergency.triggers || [] : [];
    for (var i = 0; i < emergencyTriggers.length; i++) {
      if (lower.includes(emergencyTriggers[i])) {
        return 'emergency';
      }
    }

    // ── HIGH RISK ─────────────────────────────────────────────────────────
    var hrGroups = _keywords.high_risk || {};
    var hrKeys   = Object.keys(hrGroups).filter(function(k){ return k !== '_description'; });
    for (var g = 0; g < hrKeys.length; g++) {
      var group = hrGroups[hrKeys[g]];
      if (!Array.isArray(group)) continue;
      for (var j = 0; j < group.length; j++) {
        if (lower.includes(group[j])) {
          return 'high_risk';
        }
      }
    }

    // ── CAUTION ───────────────────────────────────────────────────────────
    var cautionGroups = _keywords.caution || {};
    var cKeys = Object.keys(cautionGroups).filter(function(k){ return k !== '_description'; });
    for (var cg = 0; cg < cKeys.length; cg++) {
      var cGroup = cautionGroups[cKeys[cg]];
      if (!Array.isArray(cGroup)) continue;
      for (var ck = 0; ck < cGroup.length; ck++) {
        if (lower.includes(cGroup[ck])) {
          return 'caution';
        }
      }
    }

    // ── SAFE (default) ────────────────────────────────────────────────────
    return 'safe';
  }

  // ── 3. RESPONSE BUILDER ───────────────────────────────────────────────────

  /**
   * buildResponse(riskLevel, userMessage)
   * Returns: { riskLevel, html, requiresReview, queueItem }
   *
   * The caller (assistant.js in Stage 3) will inject educationalContent
   * for 'safe' and 'caution' levels. This function provides the
   * safety wrapper — headers, warnings, referral footers.
   */
  function buildResponse(riskLevel, userMessage) {

    // ── EMERGENCY ─────────────────────────────────────────────────────────
    if (riskLevel === 'emergency') {
      _addToQueue('Emergency situation reported', 'emergency');
      return {
        riskLevel: 'emergency',
        requiresReview: true,
        html: _emergencyResponse(),
        queueItem: _peekLastQueueItem()
      };
    }

    // ── HIGH RISK ─────────────────────────────────────────────────────────
    if (riskLevel === 'high_risk') {
      var topic = _extractSafeTopic(userMessage);
      _addToQueue(topic, 'high_risk');
      return {
        riskLevel: 'high_risk',
        requiresReview: true,
        html: _highRiskResponse(topic),
        queueItem: _peekLastQueueItem()
      };
    }

    // ── CAUTION ───────────────────────────────────────────────────────────
    if (riskLevel === 'caution') {
      return {
        riskLevel: 'caution',
        requiresReview: false,
        html: _cautionWrapper(),   // caller fills in educational body
        queueItem: null
      };
    }

    // ── SAFE ──────────────────────────────────────────────────────────────
    return {
      riskLevel: 'safe',
      requiresReview: false,
      html: _safeWrapper(),       // caller fills in educational body
      queueItem: null
    };
  }

  // ── 4. RESPONSE HTML TEMPLATES ────────────────────────────────────────────

  function _emergencyResponse() {
    return [
      '<div class="safety-response emergency-response">',
      '  <div class="sr-header sr-header-emergency">',
      '    <span class="sr-icon">🚨</span>',
      '    <div>',
      '      <strong>This sounds like a medical emergency.</strong>',
      '    </div>',
      '  </div>',
      '  <div class="sr-body">',
      '    <p class="sr-emergency-call">',
      '      <strong>Call 911 (USA) or your local emergency services immediately.</strong><br>',
      '      Do not wait for a response from this assistant.',
      '    </p>',
      '    <ul class="sr-emergency-list">',
      '      <li>🇺🇸 United States: <strong>911</strong></li>',
      '      <li>🇬🇧 United Kingdom: <strong>999</strong></li>',
      '      <li>🇨🇦 Canada: <strong>911</strong></li>',
      '      <li>🇦🇺 Australia: <strong>000</strong></li>',
      '      <li>🌍 Most of Europe: <strong>112</strong></li>',
      '      <li>🌍 Other countries: <strong>call your local emergency number</strong></li>',
      '    </ul>',
      '    <p class="sr-also-call">',
      '      Also contact your <strong>dialysis unit</strong> or <strong>nephrologist</strong> as soon as it is safe to do so.',
      '    </p>',
      '  </div>',
      '  <div class="sr-footer sr-footer-emergency">',
      '    ⚠️ This question has been flagged and added to the clinical review queue.',
      '  </div>',
      '</div>'
    ].join('\n');
  }

  function _highRiskResponse(topic) {
    return [
      '<div class="safety-response high-risk-response">',
      '  <div class="sr-header sr-header-high-risk">',
      '    <span class="sr-icon">⚠️</span>',
      '    <div>',
      '      <strong>This question requires personalised medical guidance.</strong>',
      '    </div>',
      '  </div>',
      '  <div class="sr-body">',
      '    <p>',
      '      I can share some <strong>general safety information</strong>, but I cannot give you',
      '      individualised medical instructions for topics like medications, lab results,',
      '      symptoms, or clinical decisions — because the right answer depends entirely on',
      '      <em>your</em> situation, which only your care team knows.',
      '    </p>',
      '    <div class="sr-general-guidance">',
      '      <h4>General Safety Guidance</h4>',
      '      <ul>',
      '        <li>Never change, stop, or skip medications or dialysis treatments without first speaking to your <strong>nephrologist or dialysis nurse</strong>.</li>',
      '        <li>If you are unsure whether a symptom is serious, <strong>always contact your dialysis unit or nephrologist</strong> — it is always better to check.</li>',
      '        <li>Keep a written list of your medications, lab results, and care instructions from your last clinic visit — your care team can walk you through what they mean for you specifically.</li>',
      '        <li>Do not rely on internet searches or AI tools for decisions about your individual treatment.</li>',
      '      </ul>',
      '    </div>',
      '    <div class="sr-referral">',
      '      <strong>Please contact:</strong>',
      '      <ul>',
      '        <li>Your <strong>nephrologist</strong> or <strong>dialysis unit</strong> for any treatment-related questions.</li>',
      '        <li>Your <strong>renal dietitian</strong> for nutrition and diet questions specific to your lab values.</li>',
      '        <li><strong>Emergency services (911 / 999 / 112)</strong> if you feel this is urgent or life-threatening.</li>',
      '      </ul>',
      '    </div>',
      '  </div>',
      '  <div class="sr-footer sr-footer-high-risk">',
      '    🛡️ This question has been flagged for qualified clinician review. A healthcare professional will review it. No personal information was recorded.',
      '  </div>',
      '</div>'
    ].join('\n');
  }

  function _cautionWrapper() {
    return [
      '<div class="safety-response caution-response">',
      '  <div class="sr-header sr-header-caution">',
      '    <span class="sr-icon">⚠️</span>',
      '    <div>',
      '      <strong>General educational information — individual needs vary.</strong>',
      '    </div>',
      '  </div>',
      '  <div class="sr-body">',
      '    <!-- EDUCATIONAL CONTENT INJECTED HERE BY assistant.js -->',
      '    {{EDUCATIONAL_CONTENT}}',
      '  </div>',
      '  <div class="sr-footer sr-footer-caution">',
      '    👩‍⚕️ <strong>Important:</strong> The information above is general education only.',
      '    Your individual limits for potassium, phosphorus, sodium, fluid, and protein',
      '    are set by your nephrologist and renal dietitian — they may differ from general guidelines.',
      '    Always follow your personal care plan.',
      '  </div>',
      '</div>'
    ].join('\n');
  }

  function _safeWrapper() {
    return [
      '<div class="safety-response safe-response">',
      '  <div class="sr-body">',
      '    <!-- EDUCATIONAL CONTENT INJECTED HERE BY assistant.js -->',
      '    {{EDUCATIONAL_CONTENT}}',
      '  </div>',
      '  <div class="sr-footer sr-footer-safe">',
      '    ⚕️ This is general educational information. It does not replace advice from',
      '    your nephrologist, dialysis nurse, or renal dietitian.',
      '  </div>',
      '</div>'
    ].join('\n');
  }

  // ── 5. REVIEW QUEUE (localStorage — no patient data) ─────────────────────

  /**
   * Queue item shape:
   * {
   *   id:        string  (timestamp-based, unique)
   *   topic:     string  (sanitised label — NO user message text stored)
   *   riskLevel: string  ('emergency' | 'high_risk')
   *   timestamp: string  (ISO string)
   *   status:    string  ('pending' | 'reviewed' | 'referred')
   *   reviewedBy: string (clinician name — set on review)
   *   reviewNote: string (clinician note — set on review)
   * }
   */

  function _getQueue() {
    try {
      var raw = localStorage.getItem(QUEUE_KEY);
      return raw ? JSON.parse(raw) : [];
    } catch (e) {
      return [];
    }
  }

  function _saveQueue(queue) {
    try {
      localStorage.setItem(QUEUE_KEY, JSON.stringify(queue));
    } catch (e) {
      console.warn('SafetyGuard: Could not save queue to localStorage.');
    }
  }

  function _addToQueue(topic, riskLevel) {
    var queue = _getQueue();
    var item = {
      id:         Date.now().toString(36) + Math.random().toString(36).slice(2, 6),
      topic:      topic,
      riskLevel:  riskLevel,
      timestamp:  new Date().toISOString(),
      status:     'pending',
      reviewedBy: '',
      reviewNote: ''
    };
    queue.unshift(item);          // newest first
    if (queue.length > 100) queue = queue.slice(0, 100);  // cap at 100 items
    _saveQueue(queue);
    return item;
  }

  function _peekLastQueueItem() {
    var q = _getQueue();
    return q.length > 0 ? q[0] : null;
  }

  /**
   * _extractSafeTopic(message)
   * Returns a SHORT, sanitised topic label (max 60 chars).
   * NEVER stores the raw user message — only a generic category label.
   */
  function _extractSafeTopic(message) {
    var lower = message.toLowerCase();
    if (lower.includes('medication') || lower.includes('drug') || lower.includes('dose') || lower.includes('pill')) {
      return 'Question about medication or dosage';
    }
    if (lower.includes('lab') || lower.includes('result') || lower.includes('level') || lower.includes('potassium') || lower.includes('phosphorus')) {
      return 'Question about lab values or test results';
    }
    if (lower.includes('symptom') || lower.includes('fever') || lower.includes('pain') || lower.includes('swollen') || lower.includes('infection')) {
      return 'Question about symptoms or possible infection';
    }
    if (lower.includes('skip') || lower.includes('miss') || lower.includes('stop dialysis') || lower.includes('hospital')) {
      return 'Question about clinical decision or treatment change';
    }
    if (lower.includes('diagnos') || lower.includes('do i have')) {
      return 'Request for diagnosis';
    }
    return 'High-risk topic — category unclassified';
  }

  // ── 6. PUBLIC QUEUE API (used by Safety Review dashboard) ─────────────────

  /**
   * getQueue() → array of queue items (newest first)
   */
  function getQueue() {
    return _getQueue();
  }

  /**
   * getQueueStats() → { pending, reviewed, referred, total }
   */
  function getQueueStats() {
    var queue = _getQueue();
    var stats = { pending: 0, reviewed: 0, referred: 0, total: queue.length };
    queue.forEach(function(item) {
      if (item.status === 'pending')  stats.pending++;
      if (item.status === 'reviewed') stats.reviewed++;
      if (item.status === 'referred') stats.referred++;
    });
    return stats;
  }

  /**
   * resolveItem(id, status, reviewedBy, reviewNote)
   * Called by the Safety Review dashboard when a clinician acts on an item.
   * status: 'reviewed' (approved + educational response released) | 'referred' (directed to care team)
   */
  function resolveItem(id, status, reviewedBy, reviewNote) {
    var queue = _getQueue();
    var found = false;
    queue = queue.map(function(item) {
      if (item.id === id) {
        found = true;
        return Object.assign({}, item, {
          status:     status,
          reviewedBy: reviewedBy || 'Clinician',
          reviewNote: reviewNote || '',
          resolvedAt: new Date().toISOString()
        });
      }
      return item;
    });
    if (found) _saveQueue(queue);
    return found;
  }

  /**
   * clearResolvedItems() — maintenance utility for the dashboard
   */
  function clearResolvedItems() {
    var queue = _getQueue().filter(function(item) { return item.status === 'pending'; });
    _saveQueue(queue);
  }

  // ── 7. INIT ───────────────────────────────────────────────────────────────

  /**
   * init(callback) — must be called once at app startup.
   * Loads keywords, then calls callback when ready.
   */
  function init(callback) {
    loadKeywords(function(kw) {
      _keywords = kw;
      console.log(
        '%c SafetyGuard ready ',
        'background:#dc2626;color:#fff;font-weight:bold;padding:3px 7px;border-radius:3px;'
      );
      console.log('SafetyGuard: 4-tier safety classification active (emergency / high_risk / caution / safe).');
      if (typeof callback === 'function') callback();
    });
  }

  // ── PUBLIC API ────────────────────────────────────────────────────────────
  return {
    init:             init,
    classify:         classify,
    buildResponse:    buildResponse,
    getQueue:         getQueue,
    getQueueStats:    getQueueStats,
    resolveItem:      resolveItem,
    clearResolvedItems: clearResolvedItems
  };

}());
